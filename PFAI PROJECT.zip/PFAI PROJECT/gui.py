"""
gui.py — MoodMap PyQt5 GUI Application

The main GUI module implementing:
    - MoodMapApp (QMainWindow): Main window with 6 pages
    - WelcomePage: Landing screen with branding
    - QuestionnairePage: 6-question input collector
    - LoadingPage: Custom-painted spinner animation
    - ResultsPage: Dashboard with charts + recommendations
    - HistoryPage: Session history + trend chart
    - ComparePage: Side-by-side prediction comparison
    - OnboardingTooltipManager: First-launch tooltips
    - Theme system: Dark/Light QSS toggle

SRS Coverage: FR-06–FR-10, FR-16, FR-25–FR-26, FR-29–FR-33
"""

import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QStackedWidget, QLabel, QPushButton, QComboBox,
    QSpinBox, QSlider, QProgressBar, QScrollArea, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QFrame, QSizePolicy,
    QToolTip, QGraphicsOpacityEffect, QSpacerItem
)
from PyQt5.QtCore import (
    Qt, QTimer, QPropertyAnimation, QEasingCurve, QSize, pyqtSignal,
    QPoint, QRect
)
from PyQt5.QtGui import (
    QPainter, QColor, QPen, QFont, QConicalGradient, QIcon,
    QPalette, QBrush
)

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure

from data_loader import DataLoader
from domain import Respondent, GenreProfile, MentalHealthMetric
from engine import (
    AgeGroupAnalyzer, CorrelationEngine, predict_mental_health
)
from recommender import RecommendationEngine
from history import HistoryManager
from dashboard import (
    ReportGenerator, create_trend_chart, create_correlation_heatmap
)
from pdf_export import PDFExporter


# ═══════════════════════════════════════════════════════════════════
# STYLESHEETS
# ═══════════════════════════════════════════════════════════════════

DARK_QSS = """
QMainWindow {
    background-color: #121212;
}
QWidget {
    background-color: transparent;
    color: #FFFFFF;
    font-family: "Segoe UI";
}
QLabel {
    color: #FFFFFF;
    font-family: "Segoe UI";
    background: transparent;
}
QLabel#secondary {
    color: #B3B3B3;
}
QLabel#muted {
    color: #727272;
}
QLabel#title {
    font-size: 36px;
    font-weight: bold;
    color: #1DB954;
}
QLabel#subtitle {
    font-size: 18px;
    color: #B3B3B3;
}
QLabel#heading {
    font-size: 24px;
    font-weight: bold;
    color: #FFFFFF;
}
QLabel#section_heading {
    font-size: 18px;
    font-weight: 600;
    color: #FFFFFF;
}
QLabel#score_number {
    font-size: 42px;
    font-weight: bold;
}
QPushButton#primary {
    background-color: #1DB954;
    color: #000000;
    border: none;
    border-radius: 24px;
    padding: 12px 32px;
    font-size: 14px;
    font-weight: 600;
    font-family: "Segoe UI";
    min-height: 28px;
}
QPushButton#primary:hover {
    background-color: #1ED760;
}
QPushButton#primary:pressed {
    background-color: #18A449;
}
QPushButton#secondary {
    background-color: transparent;
    color: #FFFFFF;
    border: 1px solid #535353;
    border-radius: 24px;
    padding: 12px 32px;
    font-size: 14px;
    font-family: "Segoe UI";
    min-height: 28px;
}
QPushButton#secondary:hover {
    background-color: #333333;
}
QPushButton#toggle_active {
    background-color: #1DB954;
    color: #000000;
    border: none;
    border-radius: 20px;
    padding: 10px 24px;
    font-size: 14px;
    font-weight: 600;
    font-family: "Segoe UI";
}
QPushButton#toggle_inactive {
    background-color: #282828;
    color: #B3B3B3;
    border: 1px solid #535353;
    border-radius: 20px;
    padding: 10px 24px;
    font-size: 14px;
    font-family: "Segoe UI";
}
QPushButton#toggle_inactive:hover {
    background-color: #333333;
    color: #FFFFFF;
}
QPushButton#theme_toggle {
    background-color: #282828;
    color: #FFFFFF;
    border: 1px solid #535353;
    border-radius: 16px;
    padding: 6px 14px;
    font-size: 12px;
    font-family: "Segoe UI";
}
QPushButton#theme_toggle:hover {
    background-color: #333333;
}
QComboBox {
    background-color: #282828;
    color: #FFFFFF;
    border: 1px solid #535353;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 14px;
    font-family: "Segoe UI";
    min-height: 20px;
}
QComboBox::drop-down {
    border: none;
    width: 30px;
}
QComboBox::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #B3B3B3;
    margin-right: 10px;
}
QComboBox QAbstractItemView {
    background-color: #282828;
    color: #FFFFFF;
    selection-background-color: #1DB954;
    selection-color: #000000;
    border: 1px solid #535353;
}
QSpinBox {
    background-color: #282828;
    color: #FFFFFF;
    border: 1px solid #535353;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 14px;
    font-family: "Segoe UI";
    min-height: 20px;
}
QSlider::groove:horizontal {
    height: 6px;
    background: #535353;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #1DB954;
    width: 18px;
    height: 18px;
    border-radius: 9px;
    margin: -6px 0;
}
QSlider::sub-page:horizontal {
    background: #1DB954;
    border-radius: 3px;
}
QProgressBar {
    background-color: #535353;
    border: none;
    border-radius: 4px;
    height: 6px;
    text-align: center;
    max-height: 8px;
}
QProgressBar::chunk {
    background-color: #1DB954;
    border-radius: 4px;
}
QScrollArea {
    background-color: #121212;
    border: none;
}
QScrollBar:vertical {
    background: #181818;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #535353;
    border-radius: 4px;
    min-height: 30px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QTableWidget {
    background-color: #181818;
    color: #FFFFFF;
    gridline-color: #535353;
    border: none;
    font-family: "Segoe UI";
    font-size: 12px;
}
QTableWidget::item {
    padding: 8px;
}
QTableWidget::item:selected {
    background-color: #1DB954;
    color: #000000;
}
QHeaderView::section {
    background-color: #282828;
    color: #FFFFFF;
    padding: 8px;
    border: none;
    border-bottom: 1px solid #535353;
    font-weight: bold;
    font-family: "Segoe UI";
}
QFrame#card {
    background-color: #181818;
    border-radius: 16px;
    padding: 24px;
}
QFrame#score_card {
    background-color: #181818;
    border-radius: 16px;
}
QFrame#chart_container {
    background-color: #181818;
    border-radius: 12px;
}
QLabel#chart_desc {
    background-color: #282828;
    color: #B3B3B3;
    border: 1px solid #535353;
    border-radius: 8px;
    padding: 10px;
    font-size: 11px;
}
QPushButton#desc_btn {
    background-color: #282828;
    color: #B3B3B3;
    border: 1px solid #535353;
    border-radius: 8px;
    padding: 6px 12px;
    font-size: 12px;
    font-family: "Segoe UI";
    min-height: 24px;
}
QPushButton#desc_btn:hover {
    background-color: #333333;
    color: #FFFFFF;
}
"""

LIGHT_QSS = """
QMainWindow {
    background-color: #F5F5F5;
}
QWidget {
    background-color: transparent;
    color: #191414;
    font-family: "Segoe UI";
}
QLabel {
    color: #191414;
    font-family: "Segoe UI";
    background: transparent;
}
QLabel#secondary {
    color: #535353;
}
QLabel#muted {
    color: #999999;
}
QLabel#title {
    font-size: 36px;
    font-weight: bold;
    color: #1DB954;
}
QLabel#subtitle {
    font-size: 18px;
    color: #535353;
}
QLabel#heading {
    font-size: 24px;
    font-weight: bold;
    color: #191414;
}
QLabel#section_heading {
    font-size: 18px;
    font-weight: 600;
    color: #191414;
}
QLabel#score_number {
    font-size: 42px;
    font-weight: bold;
}
QPushButton#primary {
    background-color: #1DB954;
    color: #FFFFFF;
    border: none;
    border-radius: 24px;
    padding: 12px 32px;
    font-size: 14px;
    font-weight: 600;
    font-family: "Segoe UI";
    min-height: 28px;
}
QPushButton#primary:hover {
    background-color: #1ED760;
}
QPushButton#primary:pressed {
    background-color: #18A449;
}
QPushButton#secondary {
    background-color: transparent;
    color: #191414;
    border: 1px solid #CCCCCC;
    border-radius: 24px;
    padding: 12px 32px;
    font-size: 14px;
    font-family: "Segoe UI";
    min-height: 28px;
}
QPushButton#secondary:hover {
    background-color: #E8E8E8;
}
QPushButton#toggle_active {
    background-color: #1DB954;
    color: #FFFFFF;
    border: none;
    border-radius: 20px;
    padding: 10px 24px;
    font-size: 14px;
    font-weight: 600;
    font-family: "Segoe UI";
}
QPushButton#toggle_inactive {
    background-color: #FFFFFF;
    color: #535353;
    border: 1px solid #CCCCCC;
    border-radius: 20px;
    padding: 10px 24px;
    font-size: 14px;
    font-family: "Segoe UI";
}
QPushButton#toggle_inactive:hover {
    background-color: #E8E8E8;
    color: #191414;
}
QPushButton#theme_toggle {
    background-color: #FFFFFF;
    color: #191414;
    border: 1px solid #CCCCCC;
    border-radius: 16px;
    padding: 6px 14px;
    font-size: 12px;
    font-family: "Segoe UI";
}
QPushButton#theme_toggle:hover {
    background-color: #E8E8E8;
}
QComboBox {
    background-color: #FFFFFF;
    color: #191414;
    border: 1px solid #CCCCCC;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 14px;
    font-family: "Segoe UI";
    min-height: 20px;
}
QComboBox::drop-down {
    border: none;
    width: 30px;
}
QComboBox::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #535353;
    margin-right: 10px;
}
QComboBox QAbstractItemView {
    background-color: #FFFFFF;
    color: #191414;
    selection-background-color: #1DB954;
    selection-color: #FFFFFF;
    border: 1px solid #CCCCCC;
}
QSpinBox {
    background-color: #FFFFFF;
    color: #191414;
    border: 1px solid #CCCCCC;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 14px;
    font-family: "Segoe UI";
    min-height: 20px;
}
QSlider::groove:horizontal {
    height: 6px;
    background: #CCCCCC;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #1DB954;
    width: 18px;
    height: 18px;
    border-radius: 9px;
    margin: -6px 0;
}
QSlider::sub-page:horizontal {
    background: #1DB954;
    border-radius: 3px;
}
QProgressBar {
    background-color: #CCCCCC;
    border: none;
    border-radius: 4px;
    height: 6px;
    text-align: center;
    max-height: 8px;
}
QProgressBar::chunk {
    background-color: #1DB954;
    border-radius: 4px;
}
QScrollArea {
    background-color: #F5F5F5;
    border: none;
}
QScrollBar:vertical {
    background: #F5F5F5;
    width: 8px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #CCCCCC;
    border-radius: 4px;
    min-height: 30px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QTableWidget {
    background-color: #FFFFFF;
    color: #191414;
    gridline-color: #CCCCCC;
    border: none;
    font-family: "Segoe UI";
    font-size: 12px;
}
QTableWidget::item {
    padding: 8px;
}
QTableWidget::item:selected {
    background-color: #1DB954;
    color: #FFFFFF;
}
QHeaderView::section {
    background-color: #F0F0F0;
    color: #191414;
    padding: 8px;
    border: none;
    border-bottom: 1px solid #CCCCCC;
    font-weight: bold;
    font-family: "Segoe UI";
}
QFrame#card {
    background-color: #FFFFFF;
    border-radius: 16px;
    padding: 24px;
    border: 1px solid #E8E8E8;
}
QFrame#score_card {
    background-color: #FFFFFF;
    border-radius: 16px;
    border: 1px solid #E8E8E8;
}
QFrame#chart_container {
    background-color: #FFFFFF;
    border-radius: 12px;
    border: 1px solid #E8E8E8;
}
QLabel#chart_desc {
    background-color: #FFFFFF;
    color: #535353;
    border: 1px solid #CCCCCC;
    border-radius: 8px;
    padding: 10px;
    font-size: 11px;
}
QPushButton#desc_btn {
    background-color: #FFFFFF;
    color: #535353;
    border: 1px solid #CCCCCC;
    border-radius: 8px;
    padding: 6px 12px;
    font-size: 12px;
    font-family: "Segoe UI";
    min-height: 24px;
}
QPushButton#desc_btn:hover {
    background-color: #E8E8E8;
    color: #191414;
}
"""


# ═══════════════════════════════════════════════════════════════════
# CUSTOM SPINNER WIDGET
# ═══════════════════════════════════════════════════════════════════

class SpinnerWidget(QWidget):
    """Custom-painted rotating arc spinner for the loading page."""

    def __init__(self, parent=None, size: int = 64) -> None:
        """Initialize spinner with size and rotation angle."""
        super().__init__(parent)
        self._angle = 0
        self._size = size
        self.setFixedSize(size, size)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._rotate)

    def start(self) -> None:
        """Start the spinner animation."""
        self._timer.start(16)  # ~60fps

    def stop(self) -> None:
        """Stop the spinner animation."""
        self._timer.stop()

    def _rotate(self) -> None:
        """Increment rotation angle and trigger repaint."""
        self._angle = (self._angle + 5) % 360
        self.update()

    def paintEvent(self, event) -> None:
        """Paint the rotating arc spinner."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        self._draw_background_circle(painter)
        self._draw_rotating_arc(painter)
        painter.end()

    def _draw_background_circle(self, painter: QPainter) -> None:
        """Draw the faint background ring."""
        pen = QPen(QColor('#535353'), 4)
        pen.setCapStyle(Qt.RoundCap)
        painter.setPen(pen)
        margin = 6
        rect = QRect(margin, margin,
                      self._size - 2 * margin, self._size - 2 * margin)
        painter.drawArc(rect, 0, 360 * 16)

    def _draw_rotating_arc(self, painter: QPainter) -> None:
        """Draw the rotating green arc segment."""
        pen = QPen(QColor('#1DB954'), 4)
        pen.setCapStyle(Qt.RoundCap)
        painter.setPen(pen)
        margin = 6
        rect = QRect(margin, margin,
                      self._size - 2 * margin, self._size - 2 * margin)
        start_angle = self._angle * 16
        span_angle = 90 * 16
        painter.drawArc(rect, start_angle, span_angle)


# ═══════════════════════════════════════════════════════════════════
# WELCOME PAGE
# ═══════════════════════════════════════════════════════════════════

class WelcomePage(QWidget):
    """Landing screen with branding and Get Started button."""

    start_clicked = pyqtSignal()

    def __init__(self, parent=None) -> None:
        """Build the welcome layout with centered branding."""
        super().__init__(parent)
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Create and arrange all welcome page widgets."""
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(16)

        layout.addStretch(2)
        self._add_branding(layout)
        layout.addSpacing(40)
        self._add_start_button(layout)
        layout.addStretch(2)
        self._add_footer(layout)

    def _add_branding(self, layout: QVBoxLayout) -> None:
        """Add title, subtitle, and tagline labels."""
        title = QLabel("🎵  MoodMap")
        title.setObjectName("title")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("Music & Mental Health Profiler")
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(subtitle)

        tagline = QLabel("Discover how your music shapes your mind")
        tagline.setObjectName("secondary")
        tagline.setAlignment(Qt.AlignCenter)
        tagline.setFont(QFont("Segoe UI", 13))
        layout.addWidget(tagline)

    def _add_start_button(self, layout: QVBoxLayout) -> None:
        """Add the Get Started button."""
        btn = QPushButton("Get Started  →")
        btn.setObjectName("primary")
        btn.setFixedSize(220, 52)
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(self.start_clicked.emit)
        layout.addWidget(btn, alignment=Qt.AlignCenter)

    def _add_footer(self, layout: QVBoxLayout) -> None:
        """Add version/project footer."""
        footer = QLabel("v1.0  ·  PFAI Project  ·  UMT 2026")
        footer.setObjectName("muted")
        footer.setAlignment(Qt.AlignCenter)
        footer.setFont(QFont("Segoe UI", 10))
        layout.addWidget(footer)


# ═══════════════════════════════════════════════════════════════════
# QUESTIONNAIRE PAGE
# ═══════════════════════════════════════════════════════════════════

class QuestionnairePage(QWidget):
    """Collects user inputs one question at a time with navigation."""

    questionnaire_complete = pyqtSignal(object)  # emits Respondent

    TOOLTIP_TEXTS = {
        'age': "Used to group you with respondents in the same life stage.",
        'fav_genre': "Your primary music genre. Affects cohort composition most strongly.",
        'hours_per_day': "Self-reported average daily listening time.",
        'while_working': "Whether you play music during focused work or study.",
        'instrumentalist': "Whether you play a musical instrument regularly.",
        'streaming_service': "Your primary platform — used as a behavioural modifier.",
    }

    def __init__(self, genres: list, services: list,
                 show_tooltips: bool = False, parent=None) -> None:
        """Build all question sub-pages and navigation."""
        super().__init__(parent)
        self.genres = genres
        self.services = services
        self.show_tooltips = show_tooltips
        self.current_index = 0
        self.answers = {}
        self._toggle_buttons = {}
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Create the overall questionnaire layout."""
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        layout.setContentsMargins(60, 30, 60, 30)

        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setMaximum(100)
        layout.addWidget(self.progress_bar)

        self.question_stack = QStackedWidget()
        self._build_all_questions()
        layout.addWidget(self.question_stack, 1)

        self._add_navigation(layout)
        self.show_question(0)

    def _build_all_questions(self) -> None:
        """Build all 7 sub-pages (6 questions + summary)."""
        self._build_age_question()
        self._build_genre_question()
        self._build_hours_question()
        self._build_toggle_question('while_working',
                                    "Do you listen to music while working?")
        self._build_toggle_question('instrumentalist',
                                    "Do you play a musical instrument?")
        self._build_service_question()
        self._build_summary_page()

    def _build_age_question(self) -> None:
        """Build the age input question page."""
        page = self._create_question_page(
            "How old are you?", 'age'
        )
        self.age_spin = QSpinBox()
        self.age_spin.setRange(10, 89)
        self.age_spin.setValue(20)
        self.age_spin.setFixedWidth(200)
        self.age_spin.setFont(QFont("Segoe UI", 16))
        page.layout().addWidget(self.age_spin, alignment=Qt.AlignCenter)
        page.layout().addStretch()

    def _build_genre_question(self) -> None:
        """Build the favorite genre dropdown question."""
        page = self._create_question_page(
            "What's your favorite music genre?", 'fav_genre'
        )
        self.genre_combo = QComboBox()
        self.genre_combo.addItems(self.genres)
        self.genre_combo.setFixedWidth(300)
        self.genre_combo.setFont(QFont("Segoe UI", 14))
        page.layout().addWidget(self.genre_combo, alignment=Qt.AlignCenter)
        page.layout().addStretch()

    def _build_hours_question(self) -> None:
        """Build the hours per day slider question."""
        page = self._create_question_page(
            "How many hours per day do you listen to music?",
            'hours_per_day'
        )
        self.hours_label = QLabel("3.0 hours")
        self.hours_label.setFont(QFont("Segoe UI", 20, QFont.Bold))
        self.hours_label.setAlignment(Qt.AlignCenter)
        page.layout().addWidget(self.hours_label)

        self.hours_slider = QSlider(Qt.Horizontal)
        self.hours_slider.setRange(0, 48)  # 0-24 in 0.5 steps
        self.hours_slider.setValue(6)  # 3.0 default
        self.hours_slider.setFixedWidth(400)
        self.hours_slider.valueChanged.connect(self._update_hours_label)
        page.layout().addWidget(self.hours_slider, alignment=Qt.AlignCenter)
        page.layout().addStretch()

    def _build_toggle_question(self, field: str, question: str) -> None:
        """Build a Yes/No toggle button question.

        Args:
            field: Answer key name.
            question: Question text to display.
        """
        page = self._create_question_page(question, field)

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(20)
        btn_layout.setAlignment(Qt.AlignCenter)

        yes_btn = QPushButton("Yes")
        no_btn = QPushButton("No")

        for btn in [yes_btn, no_btn]:
            btn.setFixedSize(120, 48)
            btn.setObjectName("toggle_inactive")
            btn.setCursor(Qt.PointingHandCursor)

        self._toggle_buttons[field] = (yes_btn, no_btn)

        yes_btn.clicked.connect(
            lambda: self._set_toggle(field, "Yes")
        )
        no_btn.clicked.connect(
            lambda: self._set_toggle(field, "No")
        )

        btn_layout.addWidget(yes_btn)
        btn_layout.addWidget(no_btn)
        page.layout().addLayout(btn_layout)
        page.layout().addStretch()

    def _build_service_question(self) -> None:
        """Build the streaming service dropdown question."""
        page = self._create_question_page(
            "What is your primary streaming service?",
            'streaming_service'
        )
        self.service_combo = QComboBox()
        self.service_combo.addItems(self.services)
        self.service_combo.setFixedWidth(350)
        self.service_combo.setFont(QFont("Segoe UI", 14))
        page.layout().addWidget(self.service_combo, alignment=Qt.AlignCenter)
        page.layout().addStretch()

    def _build_summary_page(self) -> None:
        """Build the confirmation summary page."""
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(16)

        heading = QLabel("📋  Confirm Your Answers")
        heading.setObjectName("heading")
        heading.setAlignment(Qt.AlignCenter)
        layout.addWidget(heading)

        self.summary_label = QLabel("")
        self.summary_label.setFont(QFont("Segoe UI", 14))
        self.summary_label.setAlignment(Qt.AlignCenter)
        self.summary_label.setWordWrap(True)
        layout.addWidget(self.summary_label)
        layout.addStretch()

        self.question_stack.addWidget(page)

    def _create_question_page(self, question_text: str,
                              field: str) -> QWidget:
        """Create a standard question page with heading and optional tooltip.

        Args:
            question_text: The question to display.
            field: Answer field key.

        Returns:
            QWidget: The question page widget.
        """
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(24)

        heading = QLabel(question_text)
        heading.setObjectName("heading")
        heading.setAlignment(Qt.AlignCenter)
        heading.setWordWrap(True)
        layout.addWidget(heading)

        if self.show_tooltips and field in self.TOOLTIP_TEXTS:
            tooltip = QLabel(f"ℹ️  {self.TOOLTIP_TEXTS[field]}")
            tooltip.setObjectName("secondary")
            tooltip.setAlignment(Qt.AlignCenter)
            tooltip.setFont(QFont("Segoe UI", 11))
            layout.addWidget(tooltip)

        self.question_stack.addWidget(page)
        return page

    def _add_navigation(self, layout: QVBoxLayout) -> None:
        """Add Back and Next/Submit navigation buttons."""
        nav = QHBoxLayout()

        self.back_btn = QPushButton("←  Back")
        self.back_btn.setObjectName("secondary")
        self.back_btn.setCursor(Qt.PointingHandCursor)
        self.back_btn.clicked.connect(self.go_back)
        nav.addWidget(self.back_btn)

        nav.addStretch()

        self.next_btn = QPushButton("Next  →")
        self.next_btn.setObjectName("primary")
        self.next_btn.setCursor(Qt.PointingHandCursor)
        self.next_btn.clicked.connect(self.go_next)
        nav.addWidget(self.next_btn)

        layout.addLayout(nav)

    def show_question(self, index: int) -> None:
        """Display the question at the given index.

        Args:
            index: Question index (0-6).
        """
        self.current_index = index
        self.question_stack.setCurrentIndex(index)
        total = self.question_stack.count()
        progress = int((index / (total - 1)) * 100)
        self.progress_bar.setValue(progress)
        self.back_btn.setEnabled(index > 0)
        is_summary = index == total - 1
        self.next_btn.setText("✓  Submit" if is_summary else "Next  →")

    def go_next(self) -> None:
        """Save current answer and advance to next question."""
        if not self._save_current_answer():
            return
        total = self.question_stack.count()
        if self.current_index == total - 2:
            self._update_summary()
            self.show_question(self.current_index + 1)
        elif self.current_index == total - 1:
            self.questionnaire_complete.emit(self.collect_respondent())
        else:
            self.show_question(self.current_index + 1)

    def go_back(self) -> None:
        """Return to the previous question."""
        if self.current_index > 0:
            self.show_question(self.current_index - 1)

    def _save_current_answer(self) -> bool:
        """Save the current question's answer. Returns True if valid."""
        idx = self.current_index
        if idx == 0:
            self.answers['age'] = self.age_spin.value()
        elif idx == 1:
            self.answers['fav_genre'] = self.genre_combo.currentText()
        elif idx == 2:
            self.answers['hours_per_day'] = self.hours_slider.value() / 2.0
        elif idx == 3:
            return self._validate_toggle('while_working')
        elif idx == 4:
            return self._validate_toggle('instrumentalist')
        elif idx == 5:
            self.answers['streaming_service'] = \
                self.service_combo.currentText()
        return True

    def _validate_toggle(self, field: str) -> bool:
        """Validate that a toggle question has been answered."""
        if field not in self.answers:
            QMessageBox.warning(self, "Selection Required",
                                "Please select Yes or No.")
            return False
        return True

    def _set_toggle(self, field: str, value: str) -> None:
        """Set toggle button state and record answer."""
        self.answers[field] = value
        yes_btn, no_btn = self._toggle_buttons[field]
        if value == "Yes":
            yes_btn.setObjectName("toggle_active")
            no_btn.setObjectName("toggle_inactive")
        else:
            yes_btn.setObjectName("toggle_inactive")
            no_btn.setObjectName("toggle_active")
        # Force style refresh
        yes_btn.style().unpolish(yes_btn)
        yes_btn.style().polish(yes_btn)
        no_btn.style().unpolish(no_btn)
        no_btn.style().polish(no_btn)

    def _update_hours_label(self, value: int) -> None:
        """Update the hours display label from slider value."""
        hours = value / 2.0
        self.hours_label.setText(f"{hours:.1f} hours")

    def _update_summary(self) -> None:
        """Update the summary page with all collected answers."""
        respondent = self.collect_respondent()
        self.summary_label.setText(respondent.display_summary())

    def collect_respondent(self) -> Respondent:
        """Build Respondent from collected answers.

        Returns:
            Respondent: Completed user profile.
        """
        return Respondent(
            age=self.answers.get('age', 20),
            fav_genre=self.answers.get('fav_genre', 'Pop'),
            hours_per_day=self.answers.get('hours_per_day', 3.0),
            while_working=self.answers.get('while_working', 'No'),
            instrumentalist=self.answers.get('instrumentalist', 'No'),
            streaming_service=self.answers.get('streaming_service', 'Spotify')
        )

    def reset(self) -> None:
        """Reset the questionnaire to initial state."""
        self.current_index = 0
        self.answers = {}
        self.age_spin.setValue(20)
        self.genre_combo.setCurrentIndex(0)
        self.hours_slider.setValue(6)
        self.service_combo.setCurrentIndex(0)
        for field in self._toggle_buttons:
            yes_btn, no_btn = self._toggle_buttons[field]
            yes_btn.setObjectName("toggle_inactive")
            no_btn.setObjectName("toggle_inactive")
            yes_btn.style().unpolish(yes_btn)
            yes_btn.style().polish(yes_btn)
            no_btn.style().unpolish(no_btn)
            no_btn.style().polish(no_btn)
        self.show_question(0)


# ═══════════════════════════════════════════════════════════════════
# LOADING PAGE
# ═══════════════════════════════════════════════════════════════════

class LoadingPage(QWidget):
    """Animated loading screen with custom spinner and status messages."""

    MESSAGES = [
        "Loading your music profile...",
        "Analyzing your genre cohort...",
        "Computing correlations...",
        "Crunching the numbers...",
        "Building your mental health profile...",
        "Almost there...",
    ]

    def __init__(self, parent=None) -> None:
        """Build loading page with spinner and status label."""
        super().__init__(parent)
        self._msg_index = 0
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Create loading page layout."""
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(24)

        layout.addStretch()

        self.spinner = SpinnerWidget(self, size=80)
        layout.addWidget(self.spinner, alignment=Qt.AlignCenter)

        self.status_label = QLabel(self.MESSAGES[0])
        self.status_label.setObjectName("subtitle")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setFont(QFont("Segoe UI", 14))
        layout.addWidget(self.status_label)

        self.loading_bar = QProgressBar()
        self.loading_bar.setTextVisible(False)
        self.loading_bar.setMaximum(100)
        self.loading_bar.setFixedWidth(300)
        layout.addWidget(self.loading_bar, alignment=Qt.AlignCenter)

        layout.addStretch()

        self._msg_timer = QTimer(self)
        self._msg_timer.timeout.connect(self._cycle_message)

    def start_loading(self) -> None:
        """Start the loading animation and message cycling."""
        self._msg_index = 0
        self.loading_bar.setValue(0)
        self.spinner.start()
        self._msg_timer.start(600)

    def stop_loading(self) -> None:
        """Stop the loading animation."""
        self.spinner.stop()
        self._msg_timer.stop()
        self.loading_bar.setValue(100)

    def _cycle_message(self) -> None:
        """Rotate to the next status message."""
        self._msg_index = (self._msg_index + 1) % len(self.MESSAGES)
        self.status_label.setText(self.MESSAGES[self._msg_index])
        progress = min(
            int((self._msg_index / len(self.MESSAGES)) * 100) + 15, 95
        )
        self.loading_bar.setValue(progress)


# ═══════════════════════════════════════════════════════════════════
# RESULTS PAGE
# ═══════════════════════════════════════════════════════════════════

class ResultsPage(QWidget):
    """Main results dashboard with scores, charts, and recommendations."""

    export_png_clicked = pyqtSignal()
    export_pdf_clicked = pyqtSignal()
    compare_clicked = pyqtSignal()
    history_clicked = pyqtSignal()
    start_over_clicked = pyqtSignal()

    def __init__(self, parent=None) -> None:
        """Build the scrollable results layout."""
        super().__init__(parent)
        self._figures = []
        self._canvases = []
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Create the scrollable results container."""
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.content = QWidget()
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setSpacing(24)
        self.content_layout.setContentsMargins(40, 30, 40, 30)

        self.scroll.setWidget(self.content)
        outer.addWidget(self.scroll)

    def display_results(self, report: dict, figures: list,
                        recommendations: list,
                        genre_rec: dict) -> None:
        """Populate the results dashboard with analysis data.

        Args:
            report: Full report dict from ReportGenerator.
            figures: List of matplotlib Figure objects.
            recommendations: Behaviour recommendation strings.
            genre_rec: Genre recommendation dict.
        """
        self._clear_content()
        self._add_header()
        self._add_score_cards(report)
        self._add_cohort_comparison(report)
        self._add_recommendations(recommendations, genre_rec)
        self._add_insights(report)
        self._add_charts(figures)
        self._add_action_buttons()
        self.content_layout.addStretch()

    def _clear_content(self) -> None:
        """Remove all widgets from the content layout."""
        for canvas in self._canvases:
            canvas.setParent(None)
        self._canvases = []
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.setParent(None)

    def _add_header(self) -> None:
        """Add the results page title."""
        header = QLabel("🎵  Your MoodMap Profile")
        header.setObjectName("heading")
        header.setFont(QFont("Segoe UI", 24, QFont.Bold))
        self.content_layout.addWidget(header)

    def _add_score_cards(self, report: dict) -> None:
        """Add the 4 metric score cards in a horizontal row."""
        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(16)

        metrics = ['Anxiety', 'Depression', 'Insomnia', 'OCD']
        for metric in metrics:
            card = self._create_score_card(
                metric,
                report['predicted_scores'][metric],
                report['severity_labels'][metric],
                report['percentiles'][metric]
            )
            cards_layout.addWidget(card)

        self.content_layout.addLayout(cards_layout)

    def _create_score_card(self, name: str, score: float,
                           severity: str, percentile: float) -> QFrame:
        """Create a single score card widget."""
        card = QFrame()
        card.setObjectName("score_card")
        card.setMinimumHeight(160)
        layout = QVBoxLayout(card)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(8)
        layout.setContentsMargins(16, 20, 16, 20)

        name_label = QLabel(name)
        name_label.setFont(QFont("Segoe UI", 12))
        name_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(name_label)

        score_label = QLabel(f"{score:.1f}")
        score_label.setObjectName("score_number")
        score_label.setAlignment(Qt.AlignCenter)
        color = self._severity_color(severity)
        score_label.setStyleSheet(f"color: {color};")
        layout.addWidget(score_label)

        sev_label = QLabel(severity.upper())
        sev_label.setAlignment(Qt.AlignCenter)
        sev_label.setFont(QFont("Segoe UI", 11, QFont.Bold))
        sev_label.setStyleSheet(f"color: {color};")
        layout.addWidget(sev_label)

        pct_label = QLabel(f"{percentile:.0f}th percentile")
        pct_label.setObjectName("secondary")
        pct_label.setAlignment(Qt.AlignCenter)
        pct_label.setFont(QFont("Segoe UI", 10))
        layout.addWidget(pct_label)

        return card

    def _severity_color(self, severity: str) -> str:
        """Return hex color for severity level."""
        colors = {"Low": "#1DB954", "Moderate": "#F39C12", "High": "#E74C3C"}
        return colors.get(severity, "#FFFFFF")

    def _add_cohort_comparison(self, report: dict) -> None:
        """Add the cohort comparison table section."""
        section = QLabel(
            f"📊  Cohort Comparison  "
            f"(Based on {report['genre_cohort_size']} respondents)"
        )
        section.setObjectName("section_heading")
        self.content_layout.addWidget(section)

        table = QTableWidget(4, 4)
        table.setHorizontalHeaderLabels(
            ['Metric', 'Your Score', 'Genre Avg', 'Difference']
        )
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.verticalHeader().setVisible(False)
        table.setFixedHeight(200)
        table.setEditTriggers(QTableWidget.NoEditTriggers)

        comparison = report['cohort_comparison']
        for row, metric in enumerate(['Anxiety', 'Depression',
                                      'Insomnia', 'OCD']):
            data = comparison[metric]
            table.setItem(row, 0, QTableWidgetItem(metric))
            table.setItem(row, 1, QTableWidgetItem(f"{data['user']:.1f}"))
            table.setItem(row, 2,
                          QTableWidgetItem(f"{data['cohort_avg']:.1f}"))
            diff = data['difference']
            arrow = "↑" if diff > 0 else "↓" if diff < 0 else "–"
            diff_item = QTableWidgetItem(f"{arrow} {abs(diff):.1f}")
            table.setItem(row, 3, diff_item)

        self.content_layout.addWidget(table)

    def _add_recommendations(self, recommendations: list,
                             genre_rec: dict) -> None:
        """Add the recommendations section."""
        section = QLabel("💡  Recommendations")
        section.setObjectName("section_heading")
        self.content_layout.addWidget(section)

        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(10)

        if recommendations:
            for rec in recommendations:
                lbl = QLabel(f"•  {rec}")
                lbl.setWordWrap(True)
                lbl.setFont(QFont("Segoe UI", 12))
                card_layout.addWidget(lbl)
        else:
            lbl = QLabel("•  Your listening patterns are within typical "
                         "ranges for your cohort. Keep it up!")
            lbl.setFont(QFont("Segoe UI", 12))
            card_layout.addWidget(lbl)

        if genre_rec and genre_rec['delta'] > 0.2:
            rec_text = (
                f"•  Genre suggestion: {genre_rec['recommended_genre']} "
                f"listeners report a composite score of "
                f"{genre_rec['recommended_composite']:.1f} vs your "
                f"{genre_rec['user_composite']:.1f} "
                f"(Δ {genre_rec['delta']:.1f})"
            )
            lbl = QLabel(rec_text)
            lbl.setWordWrap(True)
            lbl.setFont(QFont("Segoe UI", 12))
            card_layout.addWidget(lbl)

        self.content_layout.addWidget(card)

    def _add_insights(self, report: dict) -> None:
        """Add hours and BPM correlation insights."""
        section = QLabel("🔗  Insights")
        section.setObjectName("section_heading")
        self.content_layout.addWidget(section)

        card = QFrame()
        card.setObjectName("card")
        card_layout = QVBoxLayout(card)

        strongest = report['strongest_correlation']
        hrs_text = (
            f"Hours/Day ↔ {strongest[0]}   "
            f"r = {strongest[1]:.3f}  (strongest hours correlation)"
        )
        lbl1 = QLabel(hrs_text)
        lbl1.setFont(QFont("Segoe UI", 12))
        card_layout.addWidget(lbl1)

        bpm_strongest = report['strongest_bpm_correlation']
        bpm_text = (
            f"BPM ↔ {bpm_strongest[0]}   "
            f"r = {bpm_strongest[1]:.3f}  (strongest BPM correlation)"
        )
        lbl2 = QLabel(bpm_text)
        lbl2.setFont(QFont("Segoe UI", 12))
        card_layout.addWidget(lbl2)

        self.content_layout.addWidget(card)

    def _add_charts(self, figures: list) -> None:
        """Embed matplotlib figures as chart canvases with collapsible descriptions."""
        section = QLabel("📈  Visualizations")
        section.setObjectName("section_heading")
        self.content_layout.addWidget(section)

        grid = QGridLayout()
        grid.setSpacing(16)
        descriptions = self._get_chart_descriptions()

        for i, fig in enumerate(figures):
            container = QFrame()
            container.setObjectName("chart_container")
            container_layout = QVBoxLayout(container)
            container_layout.setContentsMargins(12, 12, 12, 12)

            canvas = FigureCanvasQTAgg(fig)
            canvas.setMinimumHeight(380)
            self._canvases.append(canvas)
            container_layout.addWidget(canvas)

            desc_text = descriptions.get(i, "")
            if desc_text:
                desc_widget = self._create_description_dropdown(desc_text)
                container_layout.addWidget(desc_widget)

            row = i // 2
            col = i % 2
            grid.addWidget(container, row, col)

        self.content_layout.addLayout(grid)

    def _get_chart_descriptions(self) -> dict:
        """Return detailed HTML descriptions for each result chart."""
        return {
            0: (
                "<b>📊  Genre Bar Chart Analysis</b><br><br>"
                "<b>• Variables:</b> The X-axis displays the favorite music genres (16 total). The Y-axis shows the average mental health score (0-10) for Anxiety, Depression, Insomnia, and OCD.<br>"
                "<b>• Legend:</b> Anxiety (<font color='#1DB954'>Green</font>), Depression (<font color='#1E90FF'>Blue</font>), Insomnia (<font color='#9B59B6'>Purple</font>), and OCD (<font color='#E74C3C'>Red</font>).<br>"
                "<b>• Statistical Significance:</b> This chart groups the entire dataset of 736 respondents by favorite genre to compute cohort-level mean averages. It reveals which musical preferences statistically correlate with higher or lower self-reported mental health scores. For example, Rock and Metal listener cohorts report higher average anxiety and depression, while Classical and Easy Listening report lower averages.<br>"
                "<b>• Practical Takeaway:</b> Compare your favorite genre to others to see if your listening preferences align with historically higher-risk or lower-risk cohorts."
            ),
            1: (
                "<b>📈  Age & Listening Intensity Trends</b><br><br>"
                "<b>• Variables:</b> X-axis represents six age groups (10-17, 18-24, 25-34, 35-49, 50-64, 65-89).<br>"
                "<b>• Dual Axes:</b> The left Y-axis (solid green line) measures average Anxiety levels (0-10). The right Y-axis (dashed blue line) measures average listening duration in Hours per Day.<br>"
                "<b>• Statistical Significance:</b> Demonstrates age-based trends. In the MxMH survey, younger cohorts (10-24) tend to have both higher daily music consumption and higher anxiety scores. Both metrics show a steady decline as age increases, indicating a demographic shifting pattern where younger individuals rely more on music, potentially as a coping mechanism.<br>"
                "<b>• Practical Takeaway:</b> Locate your age bracket on the chart to see if your own hours/day and anxiety levels align with your age group's average in the dataset."
            ),
            2: (
                "<b>📊  Anxiety Distribution Chart</b><br><br>"
                "<b>• Variables:</b> X-axis represents Anxiety scores from 0 to 10 (binned in increments of 1). Y-axis represents the count of survey respondents within each bin.<br>"
                "<b>• Reference Markers:</b> The vertical dashed red line represents your predicted Anxiety score, annotated with your exact percentile rank in the dataset.<br>"
                "<b>• Statistical Significance:</b> Visualizes the overall distribution of anxiety in the population. The shape of the histogram shows whether the dataset is skewed towards lower scores (right-skewed) or higher scores (left-skewed). The percentile rank indicates the percentage of the survey population that scored at or below your score.<br>"
                "<b>• Practical Takeaway:</b> If your dashed line sits to the right of the peak, your scores are above the population median. A 75th percentile means you score higher than 75% of the survey respondents."
            ),
            3: (
                "<b>📉  Hours vs. Depression Scatter & Trend</b><br><br>"
                "<b>• Variables:</b> X-axis represents daily listening hours (0 to 24). Y-axis represents Depression scores (0 to 10).<br>"
                "<b>• Elements:</b> Semi-transparent white dots represent individual respondents. The orange dashed line represents the linear regression trend line ($y = mx + b$). The green star highlights your specific coordinates.<br>"
                "<b>• Statistical Significance:</b> Visualizes the correlation between active listening time and depression. The upward slope of the trend line represents a positive correlation (higher listening hours correlate with higher depression levels). This suggests that high-frequency listeners may use music to cope with depressive symptoms.<br>"
                "<b>• Practical Takeaway:</b> Check if your green star is above or below the trend line. Being below the line means you report lower depression levels than typical for your hours/day."
            ),
            4: (
                "<b>🌡️  Pearson Correlation Heatmap Matrix</b><br><br>"
                "<b>• Variables:</b> Rows and columns represent Listening Hours, BPM, Anxiety, Depression, Insomnia, and OCD.<br>"
                "<b>• Color & Values:</b> Cells display the Pearson correlation coefficient ($r$), ranging from -1.0 (perfect negative) to +1.0 (perfect positive). Green represents negative, yellow neutral, and red positive correlation.<br>"
                "<b>• Statistical Significance:</b> The heatmap shows how metrics interact. For example, Anxiety and Depression show a strong positive correlation ($r \\approx 0.52$). BPM shows very weak correlation with mental health metrics ($r \\approx 0.05$), indicating tempo alone has minimal impact compared to hours per day.<br>"
                "<b>• Practical Takeaway:</b> Identify red intersections (like Hours vs Insomnia) to see which listening habits are most strongly associated with higher distress."
            )
        }

    def _create_description_dropdown(self, text: str) -> QWidget:
        """Create a collapsible details section for a chart."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 4, 0, 4)
        layout.setSpacing(6)

        btn = QPushButton("▼  Show Chart Description")
        btn.setObjectName("desc_btn")
        btn.setCursor(Qt.PointingHandCursor)

        lbl = QLabel(text)
        lbl.setObjectName("chart_desc")
        lbl.setWordWrap(True)
        lbl.setVisible(False)

        def toggle():
            if lbl.isVisible():
                lbl.setVisible(False)
                btn.setText("▼  Show Chart Description")
            else:
                lbl.setVisible(True)
                btn.setText("▲  Hide Chart Description")

        btn.clicked.connect(toggle)
        layout.addWidget(btn)
        layout.addWidget(lbl)
        return widget

    def _add_action_buttons(self) -> None:
        """Add export, compare, history, and start-over buttons."""
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)

        buttons = [
            ("📥  Export PNG", self.export_png_clicked),
            ("📄  Export PDF", self.export_pdf_clicked),
            ("🔀  Compare", self.compare_clicked),
            ("📈  View History", self.history_clicked),
            ("🔄  Start Over", self.start_over_clicked),
        ]

        for text, signal in buttons:
            btn = QPushButton(text)
            btn.setObjectName("secondary")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(signal.emit)
            btn_layout.addWidget(btn)

        self.content_layout.addLayout(btn_layout)


# ═══════════════════════════════════════════════════════════════════
# HISTORY PAGE
# ═══════════════════════════════════════════════════════════════════

class HistoryPage(QWidget):
    """Displays session history table and trend chart."""

    back_clicked = pyqtSignal()

    def __init__(self, parent=None) -> None:
        """Build the history page layout."""
        super().__init__(parent)
        self._canvas = None
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Create history page with table and chart placeholder."""
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.content = QWidget()
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setSpacing(24)
        self.content_layout.setContentsMargins(40, 30, 40, 30)

        self._add_header()
        self._add_table_placeholder()
        self._add_chart_placeholder()
        self._add_buttons()
        self.content_layout.addStretch()

        self.scroll.setWidget(self.content)
        outer.addWidget(self.scroll)

    def _add_header(self) -> None:
        """Add history page title."""
        header = QLabel("📈  Session History")
        header.setObjectName("heading")
        header.setFont(QFont("Segoe UI", 24, QFont.Bold))
        self.content_layout.addWidget(header)

    def _add_table_placeholder(self) -> None:
        """Add placeholder for the session table."""
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels([
            'Session', 'Date', 'Genre', 'Hours',
            'Anxiety', 'Depression', 'Insomnia', 'OCD'
        ])
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setMinimumHeight(200)
        self.content_layout.addWidget(self.table)

    def _add_chart_placeholder(self) -> None:
        """Add placeholder for the trend chart."""
        self.chart_container = QFrame()
        self.chart_container.setObjectName("chart_container")
        self.chart_layout = QVBoxLayout(self.chart_container)
        self.chart_layout.setContentsMargins(8, 8, 8, 8)

        self.chart_placeholder = QLabel(
            "Run 2+ sessions to see your score trend chart"
        )
        self.chart_placeholder.setObjectName("secondary")
        self.chart_placeholder.setAlignment(Qt.AlignCenter)
        self.chart_placeholder.setFont(QFont("Segoe UI", 14))
        self.chart_placeholder.setMinimumHeight(300)
        self.chart_layout.addWidget(self.chart_placeholder)

        self.content_layout.addWidget(self.chart_container)

    def _add_buttons(self) -> None:
        """Add back and clear history buttons."""
        btn_layout = QHBoxLayout()

        back_btn = QPushButton("←  Back to Results")
        back_btn.setObjectName("secondary")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(self.back_clicked.emit)
        btn_layout.addWidget(back_btn)

        btn_layout.addStretch()

        self.clear_btn = QPushButton("🗑  Clear History")
        self.clear_btn.setObjectName("secondary")
        self.clear_btn.setCursor(Qt.PointingHandCursor)
        btn_layout.addWidget(self.clear_btn)

        self.content_layout.addLayout(btn_layout)

    def refresh(self, history_manager: HistoryManager) -> None:
        """Refresh the history table and trend chart.

        Args:
            history_manager: HistoryManager instance.
        """
        sessions = history_manager.get_all_sessions()
        self._populate_table(sessions)
        self._update_trend_chart(history_manager)

    def _populate_table(self, sessions: list) -> None:
        """Fill the table with session data."""
        self.table.setRowCount(len(sessions))
        for row, session in enumerate(sessions):
            self.table.setItem(row, 0,
                               QTableWidgetItem(str(session.get('id', ''))))
            ts = session.get('timestamp', '')
            date_str = ts[:10] if len(ts) >= 10 else ts
            self.table.setItem(row, 1, QTableWidgetItem(date_str))
            self.table.setItem(row, 2,
                               QTableWidgetItem(session.get('genre', '')))
            self.table.setItem(row, 3,
                               QTableWidgetItem(str(session.get('hours', ''))))
            self.table.setItem(row, 4,
                               QTableWidgetItem(str(session.get('anxiety', ''))))
            self.table.setItem(row, 5,
                               QTableWidgetItem(str(session.get('depression', ''))))
            self.table.setItem(row, 6,
                               QTableWidgetItem(str(session.get('insomnia', ''))))
            self.table.setItem(row, 7,
                               QTableWidgetItem(str(session.get('ocd', ''))))

    def _update_trend_chart(self, history_manager: HistoryManager) -> None:
        """Update the trend chart if enough sessions exist."""
        count = history_manager.get_session_count()
        trend_data = history_manager.get_trend_data()
        fig = create_trend_chart(trend_data, count)

        # Remove old canvas
        if self._canvas:
            self.chart_layout.removeWidget(self._canvas)
            self._canvas.setParent(None)
            self._canvas = None

        # Remove old description widget if present
        if hasattr(self, 'chart_desc_widget') and self.chart_desc_widget:
            self.chart_layout.removeWidget(self.chart_desc_widget)
            self.chart_desc_widget.setParent(None)
            self.chart_desc_widget = None

        if fig:
            self.chart_placeholder.hide()
            self._canvas = FigureCanvasQTAgg(fig)
            self._canvas.setMinimumHeight(380)
            self.chart_layout.addWidget(self._canvas)

            desc_text = (
                "<b>📈  Longitudinal Score Trend Tracker</b><br><br>"
                "<b>• Variables:</b> X-axis shows your saved session numbers chronologically. Y-axis represents your predicted scores (0-10).<br>"
                "<b>• Legend:</b> Tracks Anxiety (<font color='#1DB954'>Green</font>), Depression (<font color='#1E90FF'>Blue</font>), Insomnia (<font color='#9B59B6'>Purple</font>), and OCD (<font color='#E74C3C'>Red</font>). The horizontal dashed grey line marks the midpoint score of 5.0.<br>"
                "<b>• Statistical Significance:</b> Plots your personal progress over time. By looking at successive runs, you can evaluate whether modifying your listening habits (e.g. reducing listening hours or changing favorite genres) is associated with a decrease in predicted scores.<br>"
                "<b>• Practical Takeaway:</b> Look for downward slopes across sessions, which represent positive progress and improvements in predicted mental health profiles."
            )
            self.chart_desc_widget = self._create_description_dropdown(desc_text)
            self.chart_layout.addWidget(self.chart_desc_widget)
        else:
            self.chart_placeholder.show()

    def _create_description_dropdown(self, text: str) -> QWidget:
        """Create a collapsible details section for a chart."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 4, 0, 4)
        layout.setSpacing(6)

        btn = QPushButton("▼  Show Chart Description")
        btn.setObjectName("desc_btn")
        btn.setCursor(Qt.PointingHandCursor)

        lbl = QLabel(text)
        lbl.setObjectName("chart_desc")
        lbl.setWordWrap(True)
        lbl.setVisible(False)

        def toggle():
            if lbl.isVisible():
                lbl.setVisible(False)
                btn.setText("▼  Show Chart Description")
            else:
                lbl.setVisible(True)
                btn.setText("▲  Hide Chart Description")

        btn.clicked.connect(toggle)
        layout.addWidget(btn)
        layout.addWidget(lbl)
        return widget


# ═══════════════════════════════════════════════════════════════════
# COMPARE PAGE
# ═══════════════════════════════════════════════════════════════════

class ComparePage(QWidget):
    """Side-by-side comparison of original vs modified prediction."""

    back_clicked = pyqtSignal()

    def __init__(self, genres: list, services: list,
                 parent=None) -> None:
        """Build the comparison page layout."""
        super().__init__(parent)
        self.genres = genres
        self.services = services
        self._original_report = None
        self._respondent = None
        self._df = None
        self._setup_ui()

    def _setup_ui(self) -> None:
        """Create the compare page layout."""
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.content = QWidget()
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setSpacing(20)
        self.content_layout.setContentsMargins(40, 30, 40, 30)

        self._add_header()
        self._add_input_section()
        self._add_comparison_display()
        self._add_buttons()
        self.content_layout.addStretch()

        self.scroll.setWidget(self.content)
        outer.addWidget(self.scroll)

    def _add_header(self) -> None:
        """Add compare page title."""
        header = QLabel("🔀  Comparative Mode")
        header.setObjectName("heading")
        header.setFont(QFont("Segoe UI", 24, QFont.Bold))
        self.content_layout.addWidget(header)

        subtitle = QLabel("Change one input to see how it affects your prediction")
        subtitle.setObjectName("secondary")
        self.content_layout.addWidget(subtitle)

    def _add_input_section(self) -> None:
        """Add the editable input fields."""
        card = QFrame()
        card.setObjectName("card")
        grid = QGridLayout(card)
        grid.setSpacing(16)

        # Age
        grid.addWidget(QLabel("Age:"), 0, 0)
        self.cmp_age = QSpinBox()
        self.cmp_age.setRange(10, 89)
        grid.addWidget(self.cmp_age, 0, 1)

        # Genre
        grid.addWidget(QLabel("Genre:"), 1, 0)
        self.cmp_genre = QComboBox()
        self.cmp_genre.addItems(self.genres)
        grid.addWidget(self.cmp_genre, 1, 1)

        # Hours
        grid.addWidget(QLabel("Hours/Day:"), 2, 0)
        self.cmp_hours = QSpinBox()
        self.cmp_hours.setRange(0, 48)
        self.cmp_hours.setSuffix(" × 0.5 hrs")
        grid.addWidget(self.cmp_hours, 2, 1)

        # While working
        grid.addWidget(QLabel("While Working:"), 3, 0)
        self.cmp_working = QComboBox()
        self.cmp_working.addItems(["Yes", "No"])
        grid.addWidget(self.cmp_working, 3, 1)

        # Instrumentalist
        grid.addWidget(QLabel("Instrumentalist:"), 4, 0)
        self.cmp_instrument = QComboBox()
        self.cmp_instrument.addItems(["Yes", "No"])
        grid.addWidget(self.cmp_instrument, 4, 1)

        # Streaming
        grid.addWidget(QLabel("Streaming:"), 5, 0)
        self.cmp_streaming = QComboBox()
        self.cmp_streaming.addItems(self.services)
        grid.addWidget(self.cmp_streaming, 5, 1)

        # Compare button
        compare_btn = QPushButton("⚡  Run Comparison")
        compare_btn.setObjectName("primary")
        compare_btn.setCursor(Qt.PointingHandCursor)
        compare_btn.clicked.connect(self._run_comparison)
        grid.addWidget(compare_btn, 6, 0, 1, 2)

        self.content_layout.addWidget(card)

    def _add_comparison_display(self) -> None:
        """Add the comparison results display area."""
        self.comparison_frame = QFrame()
        self.comparison_frame.setObjectName("card")
        self.comparison_layout = QVBoxLayout(self.comparison_frame)
        self.comparison_frame.hide()
        self.content_layout.addWidget(self.comparison_frame)

    def _add_buttons(self) -> None:
        """Add back button."""
        btn_layout = QHBoxLayout()
        back_btn = QPushButton("←  Back to Results")
        back_btn.setObjectName("secondary")
        back_btn.setCursor(Qt.PointingHandCursor)
        back_btn.clicked.connect(self.back_clicked.emit)
        btn_layout.addWidget(back_btn)
        btn_layout.addStretch()
        self.content_layout.addLayout(btn_layout)

    def setup_comparison(self, respondent: Respondent,
                         original_report: dict,
                         df: pd.DataFrame) -> None:
        """Pre-fill with the current respondent's answers.

        Args:
            respondent: Current respondent.
            original_report: Original analysis report.
            df: Full dataset.
        """
        self._respondent = respondent
        self._original_report = original_report
        self._df = df

        self.cmp_age.setValue(respondent.age)
        self.cmp_genre.setCurrentText(respondent.fav_genre)
        self.cmp_hours.setValue(int(respondent.hours_per_day * 2))
        self.cmp_working.setCurrentText(respondent.while_working)
        self.cmp_instrument.setCurrentText(respondent.instrumentalist)
        self.cmp_streaming.setCurrentText(respondent.streaming_service)
        self.comparison_frame.hide()

    def _run_comparison(self) -> None:
        """Run prediction with modified inputs and show comparison."""
        if self._df is None:
            return

        new_respondent = Respondent(
            age=self.cmp_age.value(),
            fav_genre=self.cmp_genre.currentText(),
            hours_per_day=self.cmp_hours.value() / 2.0,
            while_working=self.cmp_working.currentText(),
            instrumentalist=self.cmp_instrument.currentText(),
            streaming_service=self.cmp_streaming.currentText()
        )

        new_scores = predict_mental_health(new_respondent, self._df)
        self._show_comparison(new_scores)

    def _show_comparison(self, new_scores: dict) -> None:
        """Display side-by-side comparison of original vs new scores."""
        # Clear previous comparison
        while self.comparison_layout.count():
            item = self.comparison_layout.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)

        header = QLabel("Results Comparison")
        header.setObjectName("section_heading")
        self.comparison_layout.addWidget(header)

        table = QTableWidget(4, 4)
        table.setHorizontalHeaderLabels(
            ['Metric', 'Original', 'New', 'Change']
        )
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.verticalHeader().setVisible(False)
        table.setFixedHeight(200)
        table.setEditTriggers(QTableWidget.NoEditTriggers)

        original = self._original_report['predicted_scores']
        for row, metric in enumerate(['Anxiety', 'Depression',
                                      'Insomnia', 'OCD']):
            table.setItem(row, 0, QTableWidgetItem(metric))
            table.setItem(row, 1,
                          QTableWidgetItem(f"{original[metric]:.1f}"))
            table.setItem(row, 2,
                          QTableWidgetItem(f"{new_scores[metric]:.1f}"))
            delta = new_scores[metric] - original[metric]
            arrow = "↑" if delta > 0 else "↓" if delta < 0 else "–"
            color = "#E74C3C" if delta > 0 else "#1DB954" if delta < 0 else "#B3B3B3"
            item = QTableWidgetItem(f"{arrow} {abs(delta):.2f}")
            table.setItem(row, 3, item)

        self.comparison_layout.addWidget(table)
        self.comparison_frame.show()


# ═══════════════════════════════════════════════════════════════════
# MAIN APPLICATION WINDOW
# ═══════════════════════════════════════════════════════════════════

class MoodMapApp(QMainWindow):
    """Main application window with 6 pages and theme toggle.

    Pages:
        0: WelcomePage
        1: QuestionnairePage
        2: LoadingPage
        3: ResultsPage
        4: HistoryPage
        5: ComparePage
    """

    def __init__(self) -> None:
        """Initialize the main window, load data, create all pages."""
        super().__init__()
        self.setWindowTitle("MoodMap — Music & Mental Health Profiler")
        self.resize(1200, 800)
        self.is_dark_theme = True

        self._init_data()
        self._init_pages()
        self._init_theme_toggle()
        self._connect_signals()
        self._apply_theme()

        # State
        self._current_respondent = None
        self._current_report = None
        self._report_generator = None

    def _init_data(self) -> None:
        """Load dataset and initialize history manager."""
        try:
            self.data_loader = DataLoader('mxmh_survey_results.csv')
            self.df = self.data_loader.get_data()
        except (FileNotFoundError, ValueError) as e:
            QMessageBox.critical(None, "Data Error", str(e))
            sys.exit(1)

        self.history_manager = HistoryManager()
        self._genres = self.data_loader.get_unique_genres()
        self._services = self.data_loader.get_unique_services()

    def _init_pages(self) -> None:
        """Create all 6 pages and add to stacked widget."""
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Top bar layout to hold the theme toggle button in the top-right corner
        self.top_bar = QWidget()
        self.top_bar.setFixedHeight(50)
        top_layout = QHBoxLayout(self.top_bar)
        top_layout.setContentsMargins(20, 10, 20, 10)
        top_layout.addStretch()

        self.theme_btn = QPushButton()
        self.theme_btn.setObjectName("theme_toggle")
        self.theme_btn.setCursor(Qt.PointingHandCursor)
        top_layout.addWidget(self.theme_btn)

        main_layout.addWidget(self.top_bar)

        self.stacked = QStackedWidget()
        main_layout.addWidget(self.stacked)

        # Check onboarding
        show_tips = self.history_manager.get_setting('onboarding_shown') != '1'

        self.welcome_page = WelcomePage()
        self.questionnaire_page = QuestionnairePage(
            self._genres, self._services, show_tooltips=show_tips
        )
        self.loading_page = LoadingPage()
        self.results_page = ResultsPage()
        self.history_page = HistoryPage()
        self.compare_page = ComparePage(self._genres, self._services)

        self.stacked.addWidget(self.welcome_page)      # 0
        self.stacked.addWidget(self.questionnaire_page)  # 1
        self.stacked.addWidget(self.loading_page)        # 2
        self.stacked.addWidget(self.results_page)        # 3
        self.stacked.addWidget(self.history_page)        # 4
        self.stacked.addWidget(self.compare_page)        # 5

        # Mark onboarding shown
        if show_tips:
            self.history_manager.set_setting('onboarding_shown', '1')

    def _init_theme_toggle(self) -> None:
        """Connect the theme toggle button click signal."""
        self.theme_btn.clicked.connect(self.toggle_theme)

    def _connect_signals(self) -> None:
        """Connect all page navigation signals."""
        self.welcome_page.start_clicked.connect(
            lambda: self.stacked.setCurrentIndex(1)
        )
        self.questionnaire_page.questionnaire_complete.connect(
            self.run_analysis
        )
        self.results_page.export_png_clicked.connect(self._export_png)
        self.results_page.export_pdf_clicked.connect(self._export_pdf)
        self.results_page.compare_clicked.connect(self._show_compare)
        self.results_page.history_clicked.connect(self._show_history)
        self.results_page.start_over_clicked.connect(self._start_over)
        self.history_page.back_clicked.connect(
            lambda: self.stacked.setCurrentIndex(3)
        )
        self.history_page.clear_btn.clicked.connect(self._clear_history)
        self.compare_page.back_clicked.connect(
            lambda: self.stacked.setCurrentIndex(3)
        )

    def _apply_theme(self) -> None:
        """Apply the current theme stylesheet."""
        if self.is_dark_theme:
            self.setStyleSheet(DARK_QSS)
            self.theme_btn.setText("☀️  Light")
        else:
            self.setStyleSheet(LIGHT_QSS)
            self.theme_btn.setText("🌙  Dark")

    def toggle_theme(self) -> None:
        """Switch between dark and light themes."""
        self.is_dark_theme = not self.is_dark_theme
        self._apply_theme()

    def run_analysis(self, respondent: Respondent) -> None:
        """Run the full analysis pipeline after questionnaire completion.

        Args:
            respondent: Completed Respondent object.
        """
        self._current_respondent = respondent
        self.stacked.setCurrentIndex(2)
        self.loading_page.start_loading()

        # Use QTimer to allow UI to render loading page first
        QTimer.singleShot(800, lambda: self._execute_analysis(respondent))

    def _execute_analysis(self, respondent: Respondent) -> None:
        """Execute the analysis pipeline and display results."""
        try:
            report, figures, recs, genre_rec = self._build_analysis(
                respondent
            )
            self._save_session(respondent, report)
            self.loading_page.stop_loading()
            self.results_page.display_results(report, figures, recs, genre_rec)
            self.stacked.setCurrentIndex(3)
        except Exception as e:
            self.loading_page.stop_loading()
            QMessageBox.critical(self, "Analysis Error", str(e))
            self.stacked.setCurrentIndex(1)

    def _build_analysis(self, respondent: Respondent) -> tuple:
        """Build the full analysis pipeline.

        Returns:
            tuple: (report, figures, recommendations, genre_rec)
        """
        genre_profile = GenreProfile(respondent, self.df)
        scores = predict_mental_health(respondent, self.df)

        metrics = [
            MentalHealthMetric(m, scores[m], self.df[m].values)
            for m in ['Anxiety', 'Depression', 'Insomnia', 'OCD']
        ]

        age_analyzer = AgeGroupAnalyzer(self.df)
        corr_engine = CorrelationEngine(self.df)

        self._report_generator = ReportGenerator(
            respondent, genre_profile, metrics, age_analyzer,
            corr_engine, self.df
        )

        report = self._report_generator.generate_report()
        self._current_report = report
        figures = self._report_generator.create_all_figures()

        rec_engine = RecommendationEngine(respondent, scores, self.df)
        recs = rec_engine.get_behaviour_recommendations()
        genre_rec = rec_engine.get_genre_recommendation()

        return report, figures, recs, genre_rec

    def _save_session(self, respondent: Respondent,
                      report: dict) -> None:
        """Save the current session to history."""
        self.history_manager.save_session(
            respondent, report['predicted_scores'], report['percentiles']
        )

    def _export_png(self) -> None:
        """Export all charts as PNGs."""
        if self._report_generator:
            paths = self._report_generator.export_visualizations('output')
            QMessageBox.information(
                self, "Export Complete",
                f"Saved {len(paths)} charts to output/ directory."
            )

    def _export_pdf(self) -> None:
        """Export full PDF report."""
        if self._report_generator and self._current_report:
            try:
                chart_paths = self._report_generator.export_visualizations(
                    'output'
                )
                rec_engine = RecommendationEngine(
                    self._current_respondent,
                    self._current_report['predicted_scores'],
                    self.df
                )
                recs = rec_engine.get_behaviour_recommendations()
                genre_rec = rec_engine.get_genre_recommendation()

                exporter = PDFExporter(
                    self._current_report, chart_paths, recs,
                    genre_rec, output_dir='output'
                )
                pdf_path = exporter.generate()
                QMessageBox.information(
                    self, "PDF Exported",
                    f"Report saved to: {pdf_path}"
                )
            except Exception as e:
                QMessageBox.warning(self, "PDF Error", str(e))

    def _show_compare(self) -> None:
        """Navigate to comparative mode."""
        if self._current_respondent and self._current_report:
            self.compare_page.setup_comparison(
                self._current_respondent, self._current_report, self.df
            )
            self.stacked.setCurrentIndex(5)

    def _show_history(self) -> None:
        """Navigate to history page and refresh data."""
        self.history_page.refresh(self.history_manager)
        self.stacked.setCurrentIndex(4)

    def _start_over(self) -> None:
        """Reset and return to welcome page."""
        self.questionnaire_page.reset()
        self._current_respondent = None
        self._current_report = None
        self._report_generator = None
        self.stacked.setCurrentIndex(0)

    def _clear_history(self) -> None:
        """Clear all session history with confirmation."""
        reply = QMessageBox.question(
            self, "Clear History",
            "Are you sure you want to delete all session history?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.history_manager.clear_all()
            self.history_page.refresh(self.history_manager)
