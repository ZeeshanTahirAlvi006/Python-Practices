"""
recommender.py — MoodMap Recommendation Engine

Generates two types of output:
    1. Actionable behaviour change suggestions
    2. Genre swap recommendation

Both derived purely from dataset statistics.

SRS Coverage: FR-23, FR-24
"""

import numpy as np
import pandas as pd


class RecommendationEngine:
    """Generates evidence-based recommendations from dataset statistics.

    Attributes:
        respondent: User's questionnaire profile.
        predicted_scores (dict): {metric: float} from predict_mental_health().
        df (pd.DataFrame): Full cleaned dataset.
    """

    METRICS = ['Anxiety', 'Depression', 'Insomnia', 'OCD']
    MIN_COHORT_SIZE = 30

    def __init__(self, respondent, predicted_scores: dict,
                 df: pd.DataFrame) -> None:
        """Initialize with user profile, predictions, and dataset."""
        self.respondent = respondent
        self.predicted_scores = predicted_scores
        self.df = df
        self._genre_cohort = df[df['Fav genre'] == respondent.fav_genre]

    def get_behaviour_recommendations(self) -> list:
        """Generate up to 3 evidence-based behaviour change recommendations.

        Each recommendation is generated only if statistically supported
        by at least MIN_COHORT_SIZE respondents.

        Returns:
            list[str]: Up to 3 recommendation strings.
        """
        recommendations = []
        self._check_hours_reduction(recommendations)
        self._check_while_working(recommendations)
        self._check_instrumentalist(recommendations)
        return recommendations

    def _check_hours_reduction(self, recommendations: list) -> None:
        """Check 1: Recommend reducing hours if user listens above genre mean.

        Emits a recommendation if user listens >1 hr above genre mean
        and reducing would improve any metric by ≥0.3.
        """
        mean_hours = np.mean(self._genre_cohort['Hours per day'].values)
        if self.respondent.hours_per_day <= mean_hours + 1.0:
            return

        for m in self.METRICS:
            r = np.corrcoef(
                self.df['Hours per day'].values, self.df[m].values
            )[0, 1]
            improvement = (self.respondent.hours_per_day - mean_hours) * r
            if improvement >= 0.3:
                pct = round(
                    (improvement / max(self.predicted_scores[m], 0.1)) * 100
                )
                recommendations.append(
                    f"Users in your genre cohort who listen ~{mean_hours:.1f} "
                    f"hrs/day report {pct}% lower {m} on average."
                )
                break  # one hours-based recommendation max

    def _check_while_working(self, recommendations: list) -> None:
        """Check 2: Recommend avoiding music while working if beneficial.

        Compares Yes vs No cohorts for the user's highest-scoring metric.
        """
        if self.respondent.while_working != 'Yes':
            return

        highest = max(self.predicted_scores, key=self.predicted_scores.get)
        cohort_yes = self.df[self.df['While working'] == 'Yes'][highest]
        cohort_no = self.df[self.df['While working'] == 'No'][highest]

        if len(cohort_yes) < self.MIN_COHORT_SIZE:
            return
        if len(cohort_no) < self.MIN_COHORT_SIZE:
            return

        delta = np.mean(cohort_yes.values) - np.mean(cohort_no.values)
        if delta >= 0.5:
            recommendations.append(
                f"Avoiding music while working may reduce your {highest} "
                f"score by ~{delta:.1f} points based on cohort data."
            )

    def _check_instrumentalist(self, recommendations: list) -> None:
        """Check 3: Recommend playing an instrument if beneficial.

        If user doesn't play, check if instrumentalists show ≥0.4 lower
        scores on 2+ metrics.
        """
        if self.respondent.instrumentalist != 'No':
            return

        inst_cohort = self.df[self.df['Instrumentalist'] == 'Yes']
        non_inst = self.df[self.df['Instrumentalist'] == 'No']

        if len(inst_cohort) < self.MIN_COHORT_SIZE:
            return

        improved = self._find_improved_metrics(inst_cohort, non_inst)
        if len(improved) >= 2:
            recommendations.append(
                f"Respondents who play an instrument report lower "
                f"{improved[0]} and {improved[1]} on average."
            )

    def _find_improved_metrics(self, inst_cohort: pd.DataFrame,
                               non_inst: pd.DataFrame) -> list:
        """Find metrics where instrumentalists score ≥0.4 lower.

        Returns:
            list[str]: Metric names that show improvement.
        """
        improved = []
        for m in self.METRICS:
            diff = (np.mean(inst_cohort[m].values) -
                    np.mean(non_inst[m].values))
            if diff <= -0.4:
                improved.append(m)
        return improved

    def get_genre_recommendation(self) -> dict:
        """Find genre with lowest composite mental health score.

        Computes mean of (Anxiety + Depression + Insomnia + OCD) / 4
        for each genre and recommends the best one.

        Returns:
            dict: recommended_genre, recommended_composite,
                  user_genre, user_composite, delta.
        """
        genre_scores = self._compute_genre_composites()
        best_genre = min(genre_scores, key=genre_scores.get)
        user_composite = self._compute_user_composite()

        return {
            'recommended_genre': best_genre,
            'recommended_composite': round(genre_scores[best_genre], 2),
            'user_genre': self.respondent.fav_genre,
            'user_composite': round(user_composite, 2),
            'delta': round(user_composite - genre_scores[best_genre], 2)
        }

    def _compute_genre_composites(self) -> dict:
        """Compute composite score for each genre.

        Returns:
            dict: {genre: composite_score}.
        """
        genre_scores = {}
        for genre, group in self.df.groupby('Fav genre'):
            means = [np.mean(group[m].values) for m in self.METRICS]
            genre_scores[genre] = np.mean(means)
        return genre_scores

    def _compute_user_composite(self) -> float:
        """Compute composite score for the user.

        Returns:
            float: Mean of user's 4 predicted scores.
        """
        return np.mean([self.predicted_scores[m] for m in self.METRICS])
