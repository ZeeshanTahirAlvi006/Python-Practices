"""
moodmap.py — MoodMap Application Entry Point

Creates the QApplication instance, initializes the main window,
and enters the Qt event loop.

SRS Coverage: Entry point
"""

import sys
from PyQt5.QtWidgets import QApplication
from gui import MoodMapApp


def main() -> None:
    """Launch the PyQt5 MoodMap application."""
    app = QApplication(sys.argv)
    app.setApplicationName("MoodMap")
    window = MoodMapApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
