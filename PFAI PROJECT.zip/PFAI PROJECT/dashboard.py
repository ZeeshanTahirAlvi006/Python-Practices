"""
dashboard.py — MoodMap Dashboard & Chart Generation

Contains the ReportGenerator class and 6 chart-creation functions
with dark-themed matplotlib styling. All chart functions return
matplotlib Figure objects for embedding in PyQt5.

SRS Coverage: FR-16, FR-17, FR-18, FR-19, FR-20, FR-21, FR-26, FR-27
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # non-interactive backend for embedding
import matplotlib.pyplot as plt
from matplotlib.figure import Figure


# ---------------------------------------------------------------------------
# Global chart style (Spotify dark theme)
# ---------------------------------------------------------------------------

CHART_STYLE = {
    'figure.facecolor': '#181818',
    'axes.facecolor': '#282828',
    'axes.edgecolor': '#535353',
    'axes.labelcolor': '#FFFFFF',
    'text.color': '#FFFFFF',
    'xtick.color': '#B3B3B3',
    'ytick.color': '#B3B3B3',
    'grid.color': '#535353',
    'grid.alpha': 0.3,
    'font.size': 11,
}

# Chart-specific colors
METRIC_COLORS = {
    'Anxiety': '#1DB954',
    'Depression': '#1E90FF',
    'Insomnia': '#9B59B6',
    'OCD': '#E74C3C',
}

METRICS = ['Anxiety', 'Depression', 'Insomnia', 'OCD']


def _apply_chart_style() -> None:
    """Apply the global Spotify dark theme to matplotlib."""
    plt.rcParams.update(CHART_STYLE)


# ---------------------------------------------------------------------------
# Chart 1: Genre Bar Chart (FR-17)
# ---------------------------------------------------------------------------

def create_genre_bar_chart(df: pd.DataFrame) -> Figure:
    """Grouped bar chart: average mental health scores per genre.

    Args:
        df: Full cleaned dataset.

    Returns:
        Figure: Matplotlib Figure with the genre bar chart.
    """
    _apply_chart_style()
    genre_means = df.groupby('Fav genre')[METRICS].mean()
    fig, ax = plt.subplots(figsize=(14, 6))

    _plot_grouped_bars(ax, genre_means)
    _format_genre_bar_axes(ax, genre_means)

    fig.tight_layout()
    return fig


def _plot_grouped_bars(ax, genre_means: pd.DataFrame) -> None:
    """Plot 4 grouped bars per genre on the axes."""
    x = np.arange(len(genre_means))
    width = 0.18
    colors = [METRIC_COLORS[m] for m in METRICS]

    for i, metric in enumerate(METRICS):
        offset = (i - 1.5) * width
        ax.bar(x + offset, genre_means[metric].values,
               width, label=metric, color=colors[i], alpha=0.85)


def _format_genre_bar_axes(ax, genre_means: pd.DataFrame) -> None:
    """Format axes labels, ticks, legend for genre bar chart."""
    x = np.arange(len(genre_means))
    ax.set_xlabel('Genre', fontsize=12)
    ax.set_ylabel('Average Score (0-10)', fontsize=12)
    ax.set_title('Mental Health Scores by Genre', fontsize=16,
                 fontweight='bold', pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(genre_means.index, rotation=45, ha='right')
    ax.set_ylim(0, 10)
    ax.legend(loc='upper right', framealpha=0.8)
    ax.grid(axis='y', alpha=0.3)


# ---------------------------------------------------------------------------
# Chart 2: Age Line Chart (FR-18)
# ---------------------------------------------------------------------------

def create_age_line_chart(df: pd.DataFrame) -> Figure:
    """Dual-axis line chart: anxiety and hours/day across age brackets.

    Args:
        df: Full cleaned dataset.

    Returns:
        Figure: Matplotlib Figure with the age line chart.
    """
    _apply_chart_style()
    bracket_data = _compute_age_bracket_data(df)
    fig, ax1 = plt.subplots(figsize=(10, 6))
    ax2 = ax1.twinx()

    _plot_anxiety_line(ax1, bracket_data)
    _plot_hours_line(ax2, bracket_data)
    _format_age_line_axes(ax1, ax2, bracket_data)

    fig.tight_layout()
    return fig


def _compute_age_bracket_data(df: pd.DataFrame) -> pd.DataFrame:
    """Compute mean anxiety and hours per age bracket."""
    brackets = [(10, 17), (18, 24), (25, 34), (35, 49), (50, 64), (65, 89)]
    labels = ["10-17", "18-24", "25-34", "35-49", "50-64", "65-89"]
    data = []

    for (mn, mx), label in zip(brackets, labels):
        subset = df[(df['Age'] >= mn) & (df['Age'] <= mx)]
        if len(subset) > 0:
            data.append({
                'bracket': label,
                'Anxiety': np.mean(subset['Anxiety'].values),
                'Hours per day': np.mean(subset['Hours per day'].values),
            })

    return pd.DataFrame(data)


def _plot_anxiety_line(ax, data: pd.DataFrame) -> None:
    """Plot anxiety trend line on primary axis."""
    ax.plot(data['bracket'], data['Anxiety'], color='#1DB954',
            marker='o', linewidth=2.5, markersize=8, label='Avg Anxiety')


def _plot_hours_line(ax, data: pd.DataFrame) -> None:
    """Plot hours/day trend line on secondary axis."""
    ax.plot(data['bracket'], data['Hours per day'], color='#1E90FF',
            marker='s', linewidth=2.5, markersize=8,
            linestyle='--', label='Avg Hours/Day')


def _format_age_line_axes(ax1, ax2, data: pd.DataFrame) -> None:
    """Format dual-axis labels and legend for age line chart."""
    ax1.set_xlabel('Age Bracket', fontsize=12)
    ax1.set_ylabel('Average Anxiety Score', fontsize=12, color='#1DB954')
    ax2.set_ylabel('Average Hours/Day', fontsize=12, color='#1E90FF')
    ax1.set_title('Anxiety & Listening Hours by Age Group', fontsize=16,
                  fontweight='bold', pad=15)
    ax1.grid(alpha=0.3)
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right',
               framealpha=0.8)


# ---------------------------------------------------------------------------
# Chart 3: Anxiety Histogram (FR-19)
# ---------------------------------------------------------------------------

def create_anxiety_histogram(df: pd.DataFrame,
                             user_score: float) -> Figure:
    """Histogram of anxiety distribution with user's score marked.

    Args:
        df: Full cleaned dataset.
        user_score: User's predicted anxiety score.

    Returns:
        Figure: Matplotlib Figure with the histogram.
    """
    _apply_chart_style()
    fig, ax = plt.subplots(figsize=(10, 6))

    _plot_histogram_bars(ax, df)
    _plot_user_score_line(ax, user_score, df)
    _format_histogram_axes(ax)

    fig.tight_layout()
    return fig


def _plot_histogram_bars(ax, df: pd.DataFrame) -> None:
    """Plot histogram bars for anxiety distribution."""
    bins = np.arange(0, 11.5, 1)
    ax.hist(df['Anxiety'].values, bins=bins, color='#1DB954',
            alpha=0.7, edgecolor='#181818', linewidth=1.2)


def _plot_user_score_line(ax, user_score: float,
                          df: pd.DataFrame) -> None:
    """Plot vertical line at user's score with percentile annotation."""
    ax.axvline(x=user_score, color='#E74C3C', linestyle='--',
               linewidth=2.5, label=f'Your Score: {user_score:.1f}')
    pct = np.sum(df['Anxiety'].values <= user_score) / len(df) * 100
    ax.annotate(f'{pct:.0f}th percentile', xy=(user_score, ax.get_ylim()[1] * 0.85),
                fontsize=11, color='#E74C3C', fontweight='bold',
                ha='left', va='top',
                xytext=(user_score + 0.3, ax.get_ylim()[1] * 0.85))


def _format_histogram_axes(ax) -> None:
    """Format axes for the anxiety histogram."""
    ax.set_xlabel('Anxiety Score (0-10)', fontsize=12)
    ax.set_ylabel('Number of Respondents', fontsize=12)
    ax.set_title('Anxiety Score Distribution', fontsize=16,
                 fontweight='bold', pad=15)
    ax.legend(loc='upper right', framealpha=0.8)
    ax.grid(axis='y', alpha=0.3)


# ---------------------------------------------------------------------------
# Chart 4: Hours vs Depression Scatter (FR-20)
# ---------------------------------------------------------------------------

def create_scatter_plot(df: pd.DataFrame, user_hours: float,
                        user_depression: float) -> Figure:
    """Scatter plot of Hours/day vs Depression with trend line.

    Args:
        df: Full cleaned dataset.
        user_hours: User's reported hours per day.
        user_depression: User's predicted depression score.

    Returns:
        Figure: Matplotlib Figure with the scatter plot.
    """
    _apply_chart_style()
    fig, ax = plt.subplots(figsize=(10, 6))

    _plot_dataset_points(ax, df)
    _plot_trend_line(ax, df)
    _plot_user_point(ax, user_hours, user_depression)
    _format_scatter_axes(ax)

    fig.tight_layout()
    return fig


def _plot_dataset_points(ax, df: pd.DataFrame) -> None:
    """Plot all respondent data points."""
    ax.scatter(df['Hours per day'].values, df['Depression'].values,
               color='#FFFFFF', alpha=0.3, s=15, label='Respondents')


def _plot_trend_line(ax, df: pd.DataFrame) -> None:
    """Plot linear regression trend line. y = mx + b."""
    x = df['Hours per day'].values
    y = df['Depression'].values
    m, b = np.polyfit(x, y, 1)
    x_line = np.linspace(x.min(), x.max(), 100)
    ax.plot(x_line, m * x_line + b, color='#F39C12',
            linewidth=2, linestyle='--', alpha=0.8, label='Trend Line')


def _plot_user_point(ax, hours: float, depression: float) -> None:
    """Plot the user's predicted point as a highlighted star."""
    ax.scatter([hours], [depression], color='#1DB954', s=200,
               marker='*', zorder=5, label='You', edgecolors='#FFFFFF',
               linewidths=1.5)
    ax.annotate('You', (hours, depression), textcoords='offset points',
                xytext=(12, 12), fontsize=12, color='#1DB954',
                fontweight='bold')


def _format_scatter_axes(ax) -> None:
    """Format axes for the scatter plot."""
    ax.set_xlabel('Hours per Day', fontsize=12)
    ax.set_ylabel('Depression Score (0-10)', fontsize=12)
    ax.set_title('Listening Hours vs Depression', fontsize=16,
                 fontweight='bold', pad=15)
    ax.set_ylim(-0.5, 10.5)
    ax.legend(loc='upper right', framealpha=0.8)
    ax.grid(alpha=0.3)


# ---------------------------------------------------------------------------
# Chart 5: Correlation Heatmap (FR-27)
# ---------------------------------------------------------------------------

def create_correlation_heatmap(df: pd.DataFrame) -> Figure:
    """5×5 heatmap: correlations between Hours, BPM, and mental health metrics.

    Args:
        df: Full cleaned dataset.

    Returns:
        Figure: Matplotlib Figure with the heatmap.
    """
    _apply_chart_style()
    cols = ['Hours per day', 'BPM', 'Anxiety', 'Depression', 'Insomnia', 'OCD']
    corr_matrix = df[cols].corr().values
    labels = ['Hours/Day', 'BPM', 'Anxiety', 'Depression', 'Insomnia', 'OCD']

    fig, ax = plt.subplots(figsize=(8, 7))
    _render_heatmap(ax, corr_matrix, labels)
    _annotate_heatmap(ax, corr_matrix)

    fig.tight_layout()
    return fig


def _render_heatmap(ax, matrix: np.ndarray, labels: list) -> None:
    """Render the correlation matrix as a colored heatmap."""
    im = ax.imshow(matrix, cmap='RdYlGn_r', vmin=-1, vmax=1, aspect='auto')
    ax.set_xticks(np.arange(len(labels)))
    ax.set_yticks(np.arange(len(labels)))
    ax.set_xticklabels(labels, rotation=45, ha='right')
    ax.set_yticklabels(labels)
    ax.set_title('Correlation Heatmap', fontsize=16,
                 fontweight='bold', pad=15)
    ax.figure.colorbar(im, ax=ax, fraction=0.046, pad=0.04)


def _annotate_heatmap(ax, matrix: np.ndarray) -> None:
    """Add correlation values as text annotations on each cell."""
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            val = matrix[i, j]
            color = '#000000' if abs(val) > 0.5 else '#FFFFFF'
            ax.text(j, i, f'{val:.2f}', ha='center', va='center',
                    color=color, fontsize=10, fontweight='bold')


# ---------------------------------------------------------------------------
# Chart 6: Trend Chart (FR-26) — HistoryPage only
# ---------------------------------------------------------------------------

def create_trend_chart(trend_data: dict,
                       session_count: int) -> Figure:
    """Multi-line chart of predicted scores across sessions.

    Only rendered if session_count >= 2.

    Args:
        trend_data: {metric: [float]} from HistoryManager.get_trend_data().
        session_count: Number of stored sessions.

    Returns:
        Figure or None: Figure if >=2 sessions, else None.
    """
    if session_count < 2:
        return None

    _apply_chart_style()
    fig, ax = plt.subplots(figsize=(10, 6))
    sessions_x = list(range(1, session_count + 1))

    _plot_metric_lines(ax, trend_data, sessions_x)
    _plot_midpoint_reference(ax, sessions_x)
    _format_trend_axes(ax)

    fig.tight_layout()
    return fig


def _plot_metric_lines(ax, trend_data: dict,
                       sessions_x: list) -> None:
    """Plot a line for each mental health metric."""
    for metric in METRICS:
        values = trend_data.get(metric, [])
        if values:
            ax.plot(sessions_x, values, color=METRIC_COLORS[metric],
                    marker='o', linewidth=2.5, markersize=8,
                    label=metric)


def _plot_midpoint_reference(ax, sessions_x: list) -> None:
    """Plot dashed horizontal reference line at y=5.0."""
    ax.axhline(y=5.0, color='#535353', linestyle='--',
               linewidth=1, alpha=0.7)


def _format_trend_axes(ax) -> None:
    """Format axes for the trend chart."""
    ax.set_xlabel('Session Number', fontsize=12)
    ax.set_ylabel('Predicted Score (0-10)', fontsize=12)
    ax.set_title('Your MoodMap Score Trend', fontsize=16,
                 fontweight='bold', pad=15)
    ax.set_ylim(-0.5, 10.5)
    ax.legend(loc='upper right', framealpha=0.8)
    ax.grid(alpha=0.3)


# ---------------------------------------------------------------------------
# ReportGenerator class
# ---------------------------------------------------------------------------

class ReportGenerator:
    """Assembles all analysis results into a structured report.

    Creates matplotlib Figure objects for embedding in the GUI
    and handles exporting charts as PNGs.

    Attributes:
        respondent: User's profile data.
        genre_profile: Genre cohort analysis.
        metrics_objs: List of 4 MentalHealthMetric objects.
        age_analyzer: Age bracket analysis.
        corr_engine: Correlation results.
        df: Full cleaned dataset.
    """

    def __init__(self, respondent, genre_profile, metrics_objs,
                 age_analyzer, corr_engine, df: pd.DataFrame) -> None:
        """Store references to all analysis objects."""
        self.respondent = respondent
        self.genre_profile = genre_profile
        self.metrics_objs = metrics_objs
        self.age_analyzer = age_analyzer
        self.corr_engine = corr_engine
        self.df = df

    def generate_report(self) -> dict:
        """Assemble complete analysis report as a structured dict.

        Returns:
            dict: Full report with scores, comparisons, correlations, etc.
        """
        predicted = self._extract_predicted_scores()
        return {
            'user_summary': self.respondent.display_summary(),
            'predicted_scores': predicted,
            'severity_labels': self._extract_severity_labels(),
            'percentiles': self._extract_percentiles(),
            'cohort_comparison': self.genre_profile.compare_to_cohort(predicted),
            'age_bracket': self.age_analyzer.get_bracket_stats(
                self.respondent.age
            ),
            'correlations': self.corr_engine.correlations,
            'bpm_correlations': self.corr_engine.bpm_correlations,
            'strongest_correlation': self.corr_engine.get_strongest(),
            'strongest_bpm_correlation': self.corr_engine.get_strongest_bpm(),
            'genre_cohort_size': self.genre_profile.cohort_size,
        }

    def _extract_predicted_scores(self) -> dict:
        """Extract predicted scores from metric objects."""
        return {m.name: round(m.score, 2) for m in self.metrics_objs}

    def _extract_severity_labels(self) -> dict:
        """Extract severity labels from metric objects."""
        return {m.name: m.severity for m in self.metrics_objs}

    def _extract_percentiles(self) -> dict:
        """Extract percentiles from metric objects."""
        return {m.name: m.percentile for m in self.metrics_objs}

    def create_all_figures(self) -> list:
        """Create all 5 chart Figures for the results page.

        Returns:
            list[Figure]: [genre_bar, age_line, histogram, scatter, heatmap]
        """
        predicted = self._extract_predicted_scores()
        return [
            create_genre_bar_chart(self.df),
            create_age_line_chart(self.df),
            create_anxiety_histogram(self.df, predicted['Anxiety']),
            create_scatter_plot(
                self.df, self.respondent.hours_per_day,
                predicted['Depression']
            ),
            create_correlation_heatmap(self.df),
        ]

    def export_visualizations(self, output_dir: str = "output") -> list:
        """Save all charts as PNGs to the output directory.

        Args:
            output_dir: Directory to save PNGs.

        Returns:
            list[str]: File paths of saved PNGs.
        """
        os.makedirs(output_dir, exist_ok=True)
        figures = self.create_all_figures()
        filenames = [
            'genre_bar.png', 'age_line.png', 'anxiety_hist.png',
            'scatter_plot.png', 'correlation_heatmap.png',
        ]
        return self._save_figures(figures, filenames, output_dir)

    def _save_figures(self, figures: list, filenames: list,
                      output_dir: str) -> list:
        """Save a list of figures to disk.

        Returns:
            list[str]: Saved file paths.
        """
        paths = []
        for fig, name in zip(figures, filenames):
            path = os.path.join(output_dir, name)
            fig.savefig(path, dpi=150, bbox_inches='tight',
                        facecolor=fig.get_facecolor())
            plt.close(fig)
            paths.append(path)
        return paths
