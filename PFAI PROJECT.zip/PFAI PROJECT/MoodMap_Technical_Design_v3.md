# MoodMap — Technical Design Document

> **Music & Mental Health Profiler**
> PyQt5 Desktop Application | PFAI Course Project | June 2026
> **Revision 3** — New features added: Recommendation Engine, Genre Recommendation, Historical Storage (SQLite), Correlation Heatmap, Confidence Indicator, Comparative Mode, PDF Report Export, Demographic Heatmap, Dark/Light Theme Toggle, BPM Awareness, Onboarding Tooltips (FR-23 – FR-33)

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Tech Stack & Dependencies](#2-tech-stack--dependencies)
3. [File Structure](#3-file-structure)
4. [Data Flow Architecture](#4-data-flow-architecture)
5. [Module 1: data_loader.py](#5-module-1-data_loaderpy)
6. [Module 2: domain.py](#6-module-2-domainpy)
7. [Module 3: engine.py](#7-module-3-enginepy)
8. [Module 4: recommender.py](#8-module-4-recommenderpy)
9. [Module 5: history.py](#9-module-5-historypy)
10. [Module 6: dashboard.py](#10-module-6-dashboardpy)
11. [Module 7: pdf_export.py](#11-module-7-pdf_exportpy)
12. [Module 8: gui.py](#12-module-8-guipy)
13. [Module 9: moodmap.py](#13-module-9-moodmappy)
14. [Formulas & Mathematical Reference](#14-formulas--mathematical-reference)
15. [GUI Design Specification](#15-gui-design-specification)
16. [SRS Traceability Matrix](#16-srs-traceability-matrix)
17. [Verification Plan](#17-verification-plan)

---

## 1. Project Overview

MoodMap is a standalone Python desktop application that:

1. Loads the MxMH (Music × Mental Health) Kaggle survey dataset (736 rows, 33 columns)
2. Presents an interactive questionnaire via a PyQt5 GUI to collect user information
3. **Predicts** the user's mental health scores (Anxiety, Depression, Insomnia, OCD) using cohort-based statistical inference built with NumPy — no sklearn
4. Applies **behavioural modifier adjustments** derived from all 6 user inputs — including listening-while-working, instrumentalist status, and streaming service — to personalise the prediction
5. Computes percentile ranks, cohort comparisons, correlation analysis, and confidence indicators
6. **Recommends** actionable listening behaviour changes and lower-risk genre alternatives
7. **Stores session history** in a local SQLite database and displays trend charts across sessions
8. Supports a **Comparative Mode** to re-run prediction with a swapped input without repeating the questionnaire
9. Displays a rich results dashboard with **5 embedded matplotlib visualizations** (4 original + correlation heatmap)
10. Exports all charts and a full **PDF report** to the `/output` directory
11. Provides an **onboarding tooltip layer** with clinical definitions on first run
12. Supports **Dark/Light theme toggle**
13. Surfaces **BPM correlation insights** alongside the existing hours/day analysis

> [!IMPORTANT]
> The SRS specifies CLI (`questionary` + `rich`). This implementation replaces CLI with a full **PyQt5 GUI**. The `questionary` and `rich` libraries are not used. All interaction happens inside the PyQt5 window.

> [!IMPORTANT]
> Instead of asking users to self-report mental health scores, MoodMap **predicts** them using cohort statistics and correlation-based adjustment — entirely with NumPy/Pandas.

---

## 2. Tech Stack & Dependencies

| Library | Version | Purpose |
|---|---|---|
| Python | 3.9+ | Core language |
| Pandas | ≥1.5.0 | Dataset loading, cleaning, filtering, groupby operations |
| NumPy | ≥1.23.0 | Correlation, percentile, statistical computations |
| Matplotlib | ≥3.6.0 | 5 chart visualizations (embedded in PyQt5) |
| PyQt5 | ≥5.15.0 | Full GUI framework — all user interaction, theme toggle |
| sqlite3 | stdlib | Session history storage — no external dependency |
| fpdf2 | ≥2.7.0 | PDF report generation |

---

## 3. File Structure

```
PFAI PROJECT/
├── moodmap.py                 # Entry point — launches PyQt5 application
├── data_loader.py             # DataLoader class — CSV I/O, cleaning, validation
├── domain.py                  # Respondent, GenreProfile, MentalHealthMetric
├── engine.py                  # AgeGroupAnalyzer, CorrelationEngine, predict_mental_health()
├── recommender.py             # RecommendationEngine — behaviour + genre recommendations
├── history.py                 # HistoryManager — SQLite session storage and retrieval
├── dashboard.py               # ReportGenerator + 5 matplotlib chart functions
├── pdf_export.py              # PDFExporter — fpdf2-based full report generation
├── gui.py                     # PyQt5 GUI — MoodMapApp window, pages, theme toggle, tooltips
├── requirements.txt           # pip dependencies
├── mxmh_survey_results.csv    # MxMH Kaggle dataset (not modified)
├── moodmap_history.db         # SQLite database (auto-created on first run)
└── output/                    # Generated PNG charts and PDF reports saved here
```

---

## 4. Data Flow Architecture

```mermaid
flowchart TD
    A["moodmap.py<br/>Entry Point"] --> B["DataLoader<br/>(data_loader.py)"]
    B -->|"Clean DataFrame"| C["MoodMapApp GUI<br/>(gui.py)"]
    C -->|"User fills questionnaire"| D["Respondent<br/>(domain.py)"]
    D --> E["predict_mental_health()<br/>(engine.py)"]
    E -->|"Predicted scores"| F["MentalHealthMetric ×4<br/>(domain.py)"]
    D --> G["GenreProfile<br/>(domain.py)"]
    G -->|"Cohort stats"| H["ReportGenerator<br/>(dashboard.py)"]
    F --> H
    B --> I["AgeGroupAnalyzer<br/>(engine.py)"]
    B --> J["CorrelationEngine<br/>(engine.py)"]
    I -->|"Age bracket stats"| H
    J -->|"Correlation results"| H
    H -->|"Report dict + Figures"| C
    C -->|"Renders results dashboard"| K["User sees profile"]
    H -->|"Saves PNGs"| L["output/ directory"]
```

**Execution sequence:**
1. `moodmap.py` creates `QApplication` and `MoodMapApp`
2. `MoodMapApp.__init__()` calls `DataLoader.get_data()` to load/clean the dataset
3. User fills questionnaire → `Respondent` object created
4. `GenreProfile` constructed (inherits `Respondent`, pulls cohort stats)
5. `predict_mental_health()` computes predicted scores
6. 4 × `MentalHealthMetric` objects created with predicted scores
7. `AgeGroupAnalyzer` and `CorrelationEngine` run their analyses
8. `ReportGenerator` assembles everything → returns report dict + matplotlib Figures
9. GUI renders the results dashboard page with embedded charts

---

## 5. Module 1: `data_loader.py`

### Class: `DataLoader`

**Purpose:** Handles all CSV I/O, data cleaning, validation, and provides clean data to the rest of the application. This class ensures that the raw Kaggle dataset is transformed into a reliable, analysis-ready DataFrame.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `filepath` | `str` | Absolute or relative path to `mxmh_survey_results.csv` |
| `df` | `pd.DataFrame \| None` | The loaded and cleaned DataFrame; `None` before `load()` is called |
| `is_loaded` | `bool` | Flag indicating whether data has been successfully loaded and cleaned |

---

#### Methods

##### `__init__(self, filepath: str) -> None`

**Functionality:** Initializes the DataLoader with the path to the CSV file. Does not load data yet — that happens on `get_data()`.

```python
def __init__(self, filepath: str):
    """Initialize DataLoader with path to MxMH CSV dataset."""
    self.filepath = filepath
    self.df = None
    self.is_loaded = False
```

---

##### `load(self) -> pd.DataFrame`

**Functionality:** Reads the CSV file using `pd.read_csv()`. If the file is not found, raises a `FileNotFoundError` with a descriptive message. Stores result in `self.df`.

**SRS Coverage:** FR-01

```python
def load(self):
    """Load mxmh_survey_results.csv into a pandas DataFrame."""
    # Uses: pd.read_csv(self.filepath)
    # Raises: FileNotFoundError if CSV not found
    # Returns: pd.DataFrame (raw, uncleaned)
```

---

##### `clean(self) -> pd.DataFrame`

**Functionality:** Performs all data cleaning steps in sequence:

1. **Strip column names** — removes leading/trailing whitespace from all column headers using `df.columns = df.columns.str.strip()`
2. **Drop null mental health rows** — drops any row where `Anxiety`, `Depression`, `Insomnia`, or `OCD` is `NaN` using `df.dropna(subset=[...])`
3. **Impute BPM** — fills missing `BPM` values with the column median using `df['BPM'].fillna(df['BPM'].median())`

**SRS Coverage:** FR-02, FR-03, FR-04

```python
def clean(self):
    """Clean dataset: strip columns, drop null mental health rows, impute BPM."""
    # Step 1: self.df.columns = self.df.columns.str.strip()
    # Step 2: self.df.dropna(subset=['Anxiety', 'Depression', 'Insomnia', 'OCD'], inplace=True)
    # Step 3: self.df['BPM'].fillna(self.df['BPM'].median(), inplace=True)
    # Returns: pd.DataFrame (cleaned)
```

---

##### `validate(self) -> bool`

**Functionality:** Checks that the cleaned dataset has at least 500 rows. If not, raises a `ValueError` with a message indicating insufficient data.

**SRS Coverage:** FR-05

```python
def validate(self):
    """Validate cleaned dataset has minimum 500 rows."""
    # Formula: len(self.df) >= 500
    # Raises: ValueError if fewer than 500 rows
    # Returns: True if valid
```

---

##### `get_data(self) -> pd.DataFrame`

**Functionality:** Orchestrates the full pipeline: `load()` → `clean()` → `validate()`. Returns the cleaned DataFrame. Sets `self.is_loaded = True` on success. This is the only method external code should call.

```python
def get_data(self):
    """Load, clean, and validate dataset. Returns clean DataFrame."""
    # Calls: self.load() -> self.clean() -> self.validate()
    # Sets: self.is_loaded = True
    # Returns: pd.DataFrame
```

---

##### `get_unique_genres(self) -> list[str]`

**Functionality:** Returns a sorted list of all unique values in the `Fav genre` column. Used by the GUI to populate the genre dropdown. Must be called after `get_data()`.

**SRS Coverage:** FR-09

```python
def get_unique_genres(self):
    """Return sorted list of unique genres from the dataset."""
    # Returns: sorted(self.df['Fav genre'].dropna().unique().tolist())
```

**Expected output** (from MxMH dataset):
```
['Classical', 'Country', 'EDM', 'Folk', 'Gospel', 'Hip hop', 'Jazz',
 'K pop', 'Latin', 'Lofi', 'Metal', 'Pop', 'R&B', 'Rap', 'Rock', 'Video game music']
```

---

##### `get_unique_services(self) -> list[str]`

**Functionality:** Returns a sorted list of unique values in the `Primary streaming service` column. Used by GUI dropdown.

```python
def get_unique_services(self):
    """Return sorted list of unique streaming services from the dataset."""
    # Returns: sorted(self.df['Primary streaming service'].dropna().unique().tolist())
```

**Expected output:**
```
['Apple Music', 'I do not use a streaming service.', 'Other streaming service',
 'Pandora', 'Spotify', 'YouTube Music']
```

---

## 6. Module 2: `domain.py`

Contains the three domain model classes that represent the user profile and mental health data.

---

### Class: `Respondent`

**Purpose:** Stores all user-provided inputs collected during the questionnaire. This is the base data class representing a single user's profile. `GenreProfile` inherits from this class.

---

#### Attributes

| Attribute | Type | Description | Valid Range / Values |
|---|---|---|---|
| `age` | `int` | User's age | 10–89 |
| `fav_genre` | `str` | User's favorite music genre | One of 16 genres from dataset |
| `hours_per_day` | `float` | Hours spent listening to music daily | 0.0–24.0 |
| `while_working` | `str` | Whether user listens while working | `"Yes"` or `"No"` |
| `instrumentalist` | `str` | Whether user plays an instrument | `"Yes"` or `"No"` |
| `streaming_service` | `str` | User's primary streaming platform | One of 6 services from dataset |

---

#### Methods

##### `__init__(self, age, fav_genre, hours_per_day, while_working, instrumentalist, streaming_service)`

**Functionality:** Stores all 6 user inputs as instance attributes. Validates that age is within 10–89 range.

```python
def __init__(self, age, fav_genre, hours_per_day, while_working, instrumentalist, streaming_service):
    """Initialize Respondent with all questionnaire inputs."""
    self.age = age                           # int, 10-89
    self.fav_genre = fav_genre               # str
    self.hours_per_day = hours_per_day       # float, 0-24
    self.while_working = while_working       # str, "Yes"/"No"
    self.instrumentalist = instrumentalist   # str, "Yes"/"No"
    self.streaming_service = streaming_service  # str
```

---

##### `to_dict(self) -> dict`

**Functionality:** Returns a dictionary representation of all user attributes. Used internally for data assembly and display.

```python
def to_dict(self):
    """Return dict of all user attributes."""
    # Returns: {
    #   'Age': self.age,
    #   'Fav genre': self.fav_genre,
    #   'Hours per day': self.hours_per_day,
    #   'While working': self.while_working,
    #   'Instrumentalist': self.instrumentalist,
    #   'Primary streaming service': self.streaming_service
    # }
```

---

##### `display_summary(self) -> str`

**Functionality:** Returns a human-readable formatted string summarizing the user's inputs. Used in the confirmation screen before analysis.

```python
def display_summary(self):
    """Return formatted string summary of user profile."""
    # Returns multi-line string like:
    # "Age: 22
    #  Favorite Genre: Rock
    #  Hours/Day: 4.5
    #  Listens While Working: Yes
    #  Instrumentalist: No
    #  Streaming Service: Spotify"
```

---

### Class: `GenreProfile(Respondent)` — inherits Respondent

**Purpose:** Extends `Respondent` by adding genre cohort analysis. Filters the dataset by the user's favorite genre and computes cohort-level mental health statistics. Inheritance used to satisfy OOP grading requirement.

---

#### Additional Attributes (beyond inherited)

| Attribute | Type | Description |
|---|---|---|
| `df` | `pd.DataFrame` | Full cleaned dataset reference |
| `cohort` | `pd.DataFrame` | Filtered subset: rows matching user's `fav_genre` |
| `cohort_size` | `int` | Number of respondents in the genre cohort |

---

#### Methods

##### `__init__(self, respondent: Respondent, df: pd.DataFrame)`

**Functionality:** Calls `super().__init__()` passing all attributes from the given `Respondent` object. Then filters the dataset to rows where `Fav genre == self.fav_genre` and stores the cohort.

```python
def __init__(self, respondent, df):
    """Initialize GenreProfile by inheriting respondent data and filtering genre cohort."""
    super().__init__(
        age=respondent.age,
        fav_genre=respondent.fav_genre,
        hours_per_day=respondent.hours_per_day,
        while_working=respondent.while_working,
        instrumentalist=respondent.instrumentalist,
        streaming_service=respondent.streaming_service
    )
    self.df = df
    self.cohort = df[df['Fav genre'] == self.fav_genre]
    self.cohort_size = len(self.cohort)
```

---

##### `get_cohort_stats(self) -> dict`

**Functionality:** Computes the mean of Anxiety, Depression, Insomnia, and OCD for the genre cohort.

**Formula:**
$$\text{cohort\_mean}_m = \frac{1}{N_{\text{genre}}} \sum_{i=1}^{N_{\text{genre}}} x_{i,m}$$

where $m \in \{\text{Anxiety, Depression, Insomnia, OCD}\}$ and $N_{\text{genre}}$ is the cohort size.

```python
def get_cohort_stats(self):
    """Compute mean mental health scores for user's genre cohort."""
    # Uses: self.cohort[['Anxiety','Depression','Insomnia','OCD']].mean()
    # Returns: {
    #   'Anxiety': float,
    #   'Depression': float,
    #   'Insomnia': float,
    #   'OCD': float,
    #   'cohort_size': int
    # }
```

---

##### `compare_to_cohort(self, predicted_scores: dict) -> dict`

**Functionality:** Compares the user's predicted scores against the genre cohort averages. Returns a dict with user score, cohort average, and the difference for each metric.

**Formula:**
$$\Delta_m = \text{user\_score}_m - \text{cohort\_mean}_m$$

```python
def compare_to_cohort(self, predicted_scores):
    """Compare user's predicted scores to genre cohort averages."""
    # For each metric m:
    #   difference = predicted_scores[m] - cohort_stats[m]
    # Returns: {
    #   'Anxiety':    {'user': 6.2, 'cohort_avg': 5.8, 'difference': +0.4},
    #   'Depression': {'user': 4.1, 'cohort_avg': 5.2, 'difference': -1.1},
    #   ...
    # }
```

---

### Class: `MentalHealthMetric`

**Purpose:** Encapsulates a single mental health dimension (e.g., Anxiety). Holds the user's predicted score, computes their percentile rank against the full dataset, and assigns a severity label. Four instances are created — one per metric.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `name` | `str` | Metric name: `"Anxiety"`, `"Depression"`, `"Insomnia"`, or `"OCD"` |
| `score` | `float` | User's predicted score (0.0–10.0) |
| `dataset_values` | `np.ndarray` | All values for this metric from the full cleaned dataset |
| `percentile` | `float` | User's percentile rank (computed on init) |
| `severity` | `str` | Severity label: `"Low"`, `"Moderate"`, or `"High"` |
| `dataset_mean` | `float` | Mean of this metric across full dataset |
| `dataset_std` | `float` | Standard deviation of this metric across full dataset |

---

#### Methods

##### `__init__(self, name: str, score: float, dataset_values: np.ndarray)`

**Functionality:** Stores the metric name, predicted score, and full column data. Immediately calls `compute_percentile()` and `get_severity_label()` to populate `self.percentile` and `self.severity`.

```python
def __init__(self, name, score, dataset_values):
    """Initialize a mental health metric with score and dataset reference."""
    self.name = name
    self.score = score
    self.dataset_values = np.array(dataset_values)
    self.dataset_mean = np.mean(self.dataset_values)
    self.dataset_std = np.std(self.dataset_values)
    self.percentile = self.compute_percentile()
    self.severity = self.get_severity_label()
```

---

##### `compute_percentile(self) -> float`

**Functionality:** Computes what percentage of the dataset the user's score is greater than or equal to. Uses NumPy to count values.

**Formula:**
$$\text{percentile} = \frac{\text{count}(x_i \leq \text{user\_score})}{N_{\text{total}}} \times 100$$

where $N_{\text{total}}$ is the number of respondents in the full dataset.

```python
def compute_percentile(self):
    """Compute user's percentile rank for this metric."""
    # Uses: np.sum(self.dataset_values <= self.score) / len(self.dataset_values) * 100
    # Returns: float (0.0 to 100.0)
    # Example: 72.5 means "higher than 72.5% of respondents"
```

**SRS Coverage:** FR-11

---

##### `get_severity_label(self) -> str`

**Functionality:** Maps the user's score to a human-readable severity category with associated color coding.

**Classification:**

| Score Range | Label | Color (for GUI) |
|---|---|---|
| 0.0 – 3.0 | `"Low"` | `#1DB954` (green) |
| 3.1 – 6.0 | `"Moderate"` | `#F39C12` (amber) |
| 6.1 – 10.0 | `"High"` | `#E74C3C` (red) |

```python
def get_severity_label(self):
    """Return severity label based on score."""
    # if self.score <= 3.0: return "Low"
    # elif self.score <= 6.0: return "Moderate"
    # else: return "High"
```

---

## 7. Module 3: `engine.py`

Contains the analytical engine classes and the core prediction function.

---

### Class: `AgeGroupAnalyzer`

**Purpose:** Segments the dataset into predefined age brackets, identifies which bracket the user belongs to, and computes mental health statistics for that bracket.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `df` | `pd.DataFrame` | Full cleaned dataset |
| `brackets` | `list[tuple]` | List of `(min_age, max_age, label)` tuples defining age groups |
| `bracket_stats` | `dict` | Cached stats: `{label: {metric: mean_value}}` for all brackets |

---

#### Age Brackets Definition

| Bracket Label | Min Age | Max Age |
|---|---|---|
| `"10-17"` | 10 | 17 |
| `"18-24"` | 18 | 24 |
| `"25-34"` | 25 | 34 |
| `"35-49"` | 35 | 49 |
| `"50-64"` | 50 | 64 |
| `"65-89"` | 65 | 89 |

---

#### Methods

##### `__init__(self, df: pd.DataFrame)`

**Functionality:** Stores the dataset and defines the 6 age brackets. Pre-computes bracket stats for all brackets.

```python
def __init__(self, df):
    """Initialize with dataset and define age brackets."""
    self.df = df
    self.brackets = [
        (10, 17, "10-17"), (18, 24, "18-24"), (25, 34, "25-34"),
        (35, 49, "35-49"), (50, 64, "50-64"), (65, 89, "65-89")
    ]
    self.bracket_stats = self._compute_all_brackets()
```

---

##### `assign_bracket(self, age: int) -> str`

**Functionality:** Returns the label of the age bracket the user falls into.

```python
def assign_bracket(self, age):
    """Return age bracket label for the given age."""
    # Iterates self.brackets, returns label where min_age <= age <= max_age
    # Returns: str, e.g. "18-24"
```

**SRS Coverage:** FR-13

---

##### `get_bracket_stats(self, age: int) -> dict`

**Functionality:** Returns mean mental health scores for the user's age bracket.

**Formula:**
$$\text{bracket\_mean}_m = \frac{1}{N_{\text{bracket}}} \sum_{i=1}^{N_{\text{bracket}}} x_{i,m}$$

```python
def get_bracket_stats(self, age):
    """Return mean mental health scores for user's age bracket."""
    # Uses: assign_bracket(age) to find bracket
    # Filters: df[(df['Age'] >= min) & (df['Age'] <= max)]
    # Computes: mean of Anxiety, Depression, Insomnia, OCD
    # Returns: {
    #   'bracket': "18-24",
    #   'Anxiety': float,
    #   'Depression': float,
    #   'Insomnia': float,
    #   'OCD': float,
    #   'bracket_size': int
    # }
```

**SRS Coverage:** FR-13

---

##### `_compute_all_brackets(self) -> dict`

**Functionality:** Pre-computes mean mental health scores for every bracket. Internal helper called during `__init__`.

```python
def _compute_all_brackets(self):
    """Pre-compute stats for all age brackets."""
    # Returns: {"10-17": {"Anxiety": 6.1, ...}, "18-24": {...}, ...}
```

---

### Class: `CorrelationEngine`

**Purpose:** Computes Pearson correlation coefficients between listening hours per day and each of the 4 mental health metrics using NumPy. Identifies the strongest relationship.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `df` | `pd.DataFrame` | Full cleaned dataset |
| `correlations` | `dict` | Computed correlations: `{metric_name: r_value}` |
| `hours_column` | `str` | Column name: `"Hours per day"` |
| `metrics` | `list[str]` | `["Anxiety", "Depression", "Insomnia", "OCD"]` |

---

#### Methods

##### `__init__(self, df: pd.DataFrame)`

**Functionality:** Stores dataset, defines metric list, immediately computes correlations.

```python
def __init__(self, df):
    """Initialize with dataset and compute all correlations."""
    self.df = df
    self.hours_column = "Hours per day"
    self.metrics = ["Anxiety", "Depression", "Insomnia", "OCD"]
    self.correlations = self.compute_correlations()
```

---

##### `compute_correlations(self) -> dict`

**Functionality:** Computes Pearson correlation coefficient between `Hours per day` and each mental health metric using `np.corrcoef()`.

**Formula — Pearson Correlation Coefficient:**

$$r_{xy} = \frac{\sum_{i=1}^{n}(x_i - \bar{x})(y_i - \bar{y})}{\sqrt{\sum_{i=1}^{n}(x_i - \bar{x})^2} \cdot \sqrt{\sum_{i=1}^{n}(y_i - \bar{y})^2}}$$

where:
- $x$ = `Hours per day` values
- $y$ = mental health metric values (e.g., Anxiety)
- $\bar{x}, \bar{y}$ = means
- $r$ ranges from -1.0 to +1.0

```python
def compute_correlations(self):
    """Compute Pearson r between hours/day and each mental health metric."""
    # For each metric m in self.metrics:
    #   hours = self.df[self.hours_column].values
    #   scores = self.df[m].values
    #   r = np.corrcoef(hours, scores)[0, 1]  # extract r from 2x2 matrix
    # Returns: {'Anxiety': 0.042, 'Depression': 0.031, 'Insomnia': 0.068, 'OCD': -0.012}
```

**SRS Coverage:** FR-14

> [!NOTE]
> `np.corrcoef(x, y)` returns a 2×2 correlation matrix. The correlation coefficient `r` is at position `[0, 1]` (or `[1, 0]`).

---

##### `get_strongest(self) -> tuple`

**Functionality:** Returns the metric with the strongest (highest absolute value) correlation to listening hours.

**Formula:**
$$\text{strongest} = \arg\max_{m} |r_m|$$

```python
def get_strongest(self):
    """Return the metric most strongly correlated with listening hours."""
    # Uses: max(self.correlations, key=lambda m: abs(self.correlations[m]))
    # Returns: (metric_name: str, r_value: float)
    # Example: ("Insomnia", 0.068)
```

**SRS Coverage:** FR-14

---

### Function: `predict_mental_health(respondent, df)`

**Purpose:** The core "AI" prediction feature. Predicts a user's Anxiety, Depression, Insomnia, and OCD scores using cohort-based weighted averages, correlation-based hours adjustment, and dampened behavioural modifier deltas — one contribution from each of the 6 user inputs. Built entirely with NumPy and Pandas — no sklearn.

**This is a standalone module-level function, not a class method.**

---

#### Parameters

| Parameter | Type | Description |
|---|---|---|
| `respondent` | `Respondent` | The user's questionnaire responses |
| `df` | `pd.DataFrame` | Full cleaned dataset |

#### Returns

| Return | Type | Description |
|---|---|---|
| `predicted_scores` | `dict` | `{'Anxiety': float, 'Depression': float, 'Insomnia': float, 'OCD': float}` |

---

#### Algorithm — Step by Step

**Step 1: Filter genre cohort**
```python
genre_cohort = df[df['Fav genre'] == respondent.fav_genre]
```

**Step 2: Filter age bracket cohort**
```python
# Determine bracket boundaries (e.g., 18-24)
age_cohort = df[(df['Age'] >= bracket_min) & (df['Age'] <= bracket_max)]
```

**Step 3: Compute intersection cohort**
```python
intersection = genre_cohort[(genre_cohort['Age'] >= bracket_min) &
                             (genre_cohort['Age'] <= bracket_max)]
```

**Step 4: Compute weighted base score**

For each metric $m \in \{\text{Anxiety, Depression, Insomnia, OCD}\}$:

$$
\text{base\_score}_m =
\begin{cases}
0.60 \cdot \bar{x}_{m,\text{intersect}} + 0.25 \cdot \bar{x}_{m,\text{genre}} + 0.15 \cdot \bar{x}_{m,\text{age}} & \text{if } N_{\text{intersect}} \geq 10 \\
0.50 \cdot \bar{x}_{m,\text{genre}} + 0.50 \cdot \bar{x}_{m,\text{age}} & \text{if } N_{\text{intersect}} < 10
\end{cases}
$$

where:
- $\bar{x}_{m,\text{intersect}}$ = mean of metric $m$ in the intersection cohort
- $\bar{x}_{m,\text{genre}}$ = mean of metric $m$ in the genre cohort
- $\bar{x}_{m,\text{age}}$ = mean of metric $m$ in the age bracket cohort
- $N_{\text{intersect}}$ = number of rows in the intersection

**Step 5: Apply hours-per-day adjustment**

$$\text{hours\_deviation} = \text{user\_hours} - \bar{h}_{\text{genre}}$$

$$\text{adjustment}_m = \text{hours\_deviation} \times r_m$$

$$\text{score\_after\_hours}_m = \text{base\_score}_m + \text{adjustment}_m$$

where:
- $\bar{h}_{\text{genre}}$ = mean `Hours per day` in the genre cohort
- $r_m$ = Pearson correlation between `Hours per day` and metric $m$ (from `CorrelationEngine`)

**Step 6: Apply behavioural modifier adjustments**

The three remaining inputs — `while_working`, `instrumentalist`, and `streaming_service` — apply additive score deltas derived from dataset cohort differences. For each attribute, the dataset is filtered to respondents with the same value as the user, and the difference between that cohort's mean and the global mean is computed. This delta is then scaled by dampening factor $\alpha = 0.15$.

$$\delta^{B}_m = \alpha \cdot \left(\bar{x}_{m,\text{cohort}(B=v)} - \bar{x}_{m,\text{global}}\right)$$

$$\text{score\_after\_modifiers}_m = \text{score\_after\_hours}_m + \delta^{W}_m + \delta^{I}_m + \delta^{S}_m$$

| Symbol | Attribute | User value `v` |
|---|---|---|
| $\delta^{W}_m$ | `While working` | `respondent.while_working` |
| $\delta^{I}_m$ | `Instrumentalist` | `respondent.instrumentalist` |
| $\delta^{S}_m$ | `Primary streaming service` | `respondent.streaming_service` |

> [!NOTE]
> $\alpha = 0.15$ ensures the combined maximum shift from all three behavioural modifiers cannot exceed approximately ±1.0 on the 0–10 scale. This preserves the primacy of the cohort-weighted base score while making all 6 questionnaire inputs analytically meaningful.

> [!NOTE]
> A minimum cohort size guard of 5 is applied per attribute. If fewer than 5 respondents share the user's value (e.g. a very rare streaming service), that modifier's delta is set to 0.0 to avoid noise from statistically insignificant samples.

**Step 7: Clamp to valid range**

$$\text{final\_score}_m = \text{np.clip}(\text{score\_after\_modifiers}_m, 0.0, 10.0)$$

```python
def predict_mental_health(respondent, df):
    """
    Predict user's mental health scores using cohort statistics.

    Uses weighted cohort averages (genre x age intersection) with
    correlation-based adjustment for listening intensity, then applies
    dampened behavioural modifier deltas for while_working,
    instrumentalist, and streaming_service inputs.

    All 6 questionnaire fields contribute to the final prediction.
    """
    metrics = ['Anxiety', 'Depression', 'Insomnia', 'OCD']
    ALPHA = 0.15
    MIN_BEHAVIOURAL_COHORT = 5

    # Step 1: Filter genre cohort
    genre_cohort = df[df['Fav genre'] == respondent.fav_genre]

    # Step 2: Determine age bracket and filter
    # ... (find bracket_min, bracket_max from AgeGroupAnalyzer.brackets)
    age_cohort = df[(df['Age'] >= bracket_min) & (df['Age'] <= bracket_max)]

    # Step 3: Intersection cohort
    intersection = genre_cohort[
        (genre_cohort['Age'] >= bracket_min) &
        (genre_cohort['Age'] <= bracket_max)
    ]

    # Step 4: Weighted base score
    predicted = {}
    for m in metrics:
        if len(intersection) >= 10:
            base = (0.60 * np.mean(intersection[m].values) +
                    0.25 * np.mean(genre_cohort[m].values) +
                    0.15 * np.mean(age_cohort[m].values))
        else:
            base = (0.50 * np.mean(genre_cohort[m].values) +
                    0.50 * np.mean(age_cohort[m].values))
        predicted[m] = base

    # Step 5: Hours-per-day adjustment
    hours_dev = respondent.hours_per_day - np.mean(genre_cohort['Hours per day'].values)
    for m in metrics:
        r = np.corrcoef(df['Hours per day'].values, df[m].values)[0, 1]
        predicted[m] += hours_dev * r

    # Step 6: Behavioural modifier adjustments (all 3 remaining inputs)
    behavioural_attrs = {
        'While working': respondent.while_working,
        'Instrumentalist': respondent.instrumentalist,
        'Primary streaming service': respondent.streaming_service,
    }
    for col, val in behavioural_attrs.items():
        cohort_b = df[df[col] == val]
        if len(cohort_b) >= MIN_BEHAVIOURAL_COHORT:
            for m in metrics:
                global_mean = np.mean(df[m].values)
                cohort_mean = np.mean(cohort_b[m].values)
                predicted[m] += ALPHA * (cohort_mean - global_mean)

    # Step 7: Clamp to valid range
    for m in metrics:
        predicted[m] = float(np.clip(predicted[m], 0.0, 10.0))

    return predicted
```

> [!TIP]
> This approach is great for viva: "We used a weighted average of three cohorts — genre, age, and their intersection — then applied a correlation-based correction for listening intensity, and finally dampened behavioural deltas from the remaining three inputs. All 6 questionnaire fields contribute to the prediction. No machine learning library needed — pure NumPy statistics."

---

## 8. Module 4: `recommender.py`

Contains the `RecommendationEngine` class. Generates two types of output: actionable behaviour change suggestions and a genre swap recommendation — both derived purely from dataset statistics.

---

### Class: `RecommendationEngine`

**Purpose:** Given a user's predicted scores and their inputs, compute evidence-based recommendations by querying cohort statistics from the cleaned dataset.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `respondent` | `Respondent` | User's questionnaire profile |
| `predicted_scores` | `dict` | `{metric: float}` from `predict_mental_health()` |
| `df` | `pd.DataFrame` | Full cleaned dataset |

---

#### Methods

##### `get_behaviour_recommendations(self) -> list[str]`

**Purpose:** Produces up to 3 actionable text recommendations based on dataset patterns. Each recommendation is generated only if it is statistically supported by at least 30 respondents in the relevant cohort.

**Logic:**

1. **Hours reduction check** — If `respondent.hours_per_day > genre_cohort_mean_hours + 1.0`, compute predicted scores at `hours = genre_cohort_mean_hours`. If any metric improves by ≥0.3, emit: `"Users in your genre cohort who listen ~{X} hrs/day report {Y}% lower Anxiety on average."`

2. **While-working check** — Compare `while_working=Yes` cohort mean vs `while_working=No` cohort mean for the user's highest-scoring metric. If switching reduces that metric by ≥0.5, emit: `"Avoiding music while working may reduce your {metric} score by approximately {delta:.1f} points based on cohort data."`

3. **Instrumentalist check** — If `respondent.instrumentalist == "No"` and the instrumentalist cohort shows ≥0.4 lower scores on 2+ metrics, emit: `"Respondents who play an instrument report lower {metric1} and {metric2} on average."`

```python
def get_behaviour_recommendations(self) -> list[str]:
    """Generate up to 3 evidence-based behaviour change recommendations."""
    recommendations = []
    metrics = ['Anxiety', 'Depression', 'Insomnia', 'OCD']
    genre_cohort = self.df[self.df['Fav genre'] == self.respondent.fav_genre]

    # Check 1: Hours reduction
    mean_hours = np.mean(genre_cohort['Hours per day'].values)
    if self.respondent.hours_per_day > mean_hours + 1.0:
        # Re-run prediction mentally with reduced hours (delta only)
        for m in metrics:
            r = np.corrcoef(self.df['Hours per day'].values, self.df[m].values)[0, 1]
            improvement = (self.respondent.hours_per_day - mean_hours) * r
            if improvement >= 0.3:
                pct = round((improvement / max(self.predicted_scores[m], 0.1)) * 100)
                recommendations.append(
                    f"Users in your genre cohort who listen ~{mean_hours:.1f} hrs/day "
                    f"report {pct}% lower {m} on average."
                )
                break  # one hours-based recommendation max

    # Check 2: While-working toggle
    highest_metric = max(self.predicted_scores, key=self.predicted_scores.get)
    cohort_yes = self.df[self.df['While working'] == 'Yes'][highest_metric]
    cohort_no  = self.df[self.df['While working'] == 'No'][highest_metric]
    if (len(cohort_yes) >= 30 and len(cohort_no) >= 30 and
            self.respondent.while_working == 'Yes'):
        delta = np.mean(cohort_yes.values) - np.mean(cohort_no.values)
        if delta >= 0.5:
            recommendations.append(
                f"Avoiding music while working may reduce your {highest_metric} "
                f"score by ~{delta:.1f} points based on cohort data."
            )

    # Check 3: Instrumentalist
    if self.respondent.instrumentalist == 'No':
        inst_cohort = self.df[self.df['Instrumentalist'] == 'Yes']
        non_inst    = self.df[self.df['Instrumentalist'] == 'No']
        if len(inst_cohort) >= 30:
            improved = [m for m in metrics
                        if np.mean(inst_cohort[m].values) - np.mean(non_inst[m].values) <= -0.4]
            if len(improved) >= 2:
                recommendations.append(
                    f"Respondents who play an instrument report lower "
                    f"{improved[0]} and {improved[1]} on average."
                )

    return recommendations
```

---

##### `get_genre_recommendation(self) -> dict`

**Purpose:** Finds the genre with the lowest composite mental health score and returns a comparison to the user's current genre.

**Logic:**
1. For each of the 16 genres, compute the mean of `(Anxiety + Depression + Insomnia + OCD) / 4` across all respondents with that genre.
2. Sort ascending. The top result is the `recommended_genre`.
3. Return a dict with the recommended genre, its composite score, the user's current genre composite, and the delta.

```python
def get_genre_recommendation(self) -> dict:
    """Find genre with lowest composite mental health score."""
    metrics = ['Anxiety', 'Depression', 'Insomnia', 'OCD']
    genre_scores = {}
    for genre, group in self.df.groupby('Fav genre'):
        genre_scores[genre] = np.mean([np.mean(group[m].values) for m in metrics])

    best_genre = min(genre_scores, key=genre_scores.get)
    user_composite = np.mean([self.predicted_scores[m] for m in metrics])

    return {
        'recommended_genre': best_genre,
        'recommended_composite': round(genre_scores[best_genre], 2),
        'user_genre': self.respondent.fav_genre,
        'user_composite': round(user_composite, 2),
        'delta': round(user_composite - genre_scores[best_genre], 2)
    }
```

**SRS Coverage:** FR-23, FR-24

---

## 9. Module 5: `history.py`

Contains the `HistoryManager` class. Manages a local SQLite database (`moodmap_history.db`) that persists user sessions across application runs.

---

### Class: `HistoryManager`

**Purpose:** Save, retrieve, and delete MoodMap prediction sessions. Enables trend analysis across multiple sessions.

---

#### Database Schema

```sql
CREATE TABLE IF NOT EXISTS sessions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT NOT NULL,
    age         INTEGER,
    genre       TEXT,
    hours       REAL,
    while_working TEXT,
    instrumentalist TEXT,
    streaming   TEXT,
    anxiety     REAL,
    depression  REAL,
    insomnia    REAL,
    ocd         REAL,
    anxiety_pct INTEGER,
    depression_pct INTEGER,
    insomnia_pct INTEGER,
    ocd_pct     INTEGER
);
```

---

#### Methods

##### `__init__(self, db_path: str = 'moodmap_history.db') -> None`
Connects to (or creates) the SQLite database. Calls `_create_table()` to ensure schema exists.

##### `save_session(self, respondent, predicted_scores, percentiles) -> int`
Inserts one row into `sessions`. Returns the new `session_id`.

##### `get_all_sessions(self) -> list[dict]`
Returns all rows as a list of dicts, ordered by `timestamp DESC`.

##### `get_trend_data(self) -> dict`
Returns `{metric: [float]}` lists for all sessions in chronological order — used by the trend chart in `dashboard.py`.

##### `get_session_count(self) -> int`
Returns total number of stored sessions.

##### `delete_session(self, session_id: int) -> None`
Deletes a single session row by ID.

##### `clear_all(self) -> None`
Drops all rows. Prompts confirmation via GUI before calling.

```python
import sqlite3
from datetime import datetime

class HistoryManager:
    """Manages persistent session storage using SQLite."""

    def __init__(self, db_path: str = 'moodmap_history.db'):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._create_table()

    def _create_table(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                age INTEGER, genre TEXT, hours REAL,
                while_working TEXT, instrumentalist TEXT, streaming TEXT,
                anxiety REAL, depression REAL, insomnia REAL, ocd REAL,
                anxiety_pct INTEGER, depression_pct INTEGER,
                insomnia_pct INTEGER, ocd_pct INTEGER
            )
        """)
        self.conn.commit()

    def save_session(self, respondent, predicted_scores, percentiles) -> int:
        cursor = self.conn.execute("""
            INSERT INTO sessions VALUES
            (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            datetime.now().isoformat(),
            respondent.age, respondent.fav_genre, respondent.hours_per_day,
            respondent.while_working, respondent.instrumentalist,
            respondent.streaming_service,
            predicted_scores['Anxiety'], predicted_scores['Depression'],
            predicted_scores['Insomnia'], predicted_scores['OCD'],
            percentiles['Anxiety'], percentiles['Depression'],
            percentiles['Insomnia'], percentiles['OCD']
        ))
        self.conn.commit()
        return cursor.lastrowid

    def get_trend_data(self) -> dict:
        rows = self.conn.execute(
            "SELECT anxiety, depression, insomnia, ocd FROM sessions ORDER BY timestamp ASC"
        ).fetchall()
        return {
            'Anxiety':    [r['anxiety']    for r in rows],
            'Depression': [r['depression'] for r in rows],
            'Insomnia':   [r['insomnia']   for r in rows],
            'OCD':        [r['ocd']        for r in rows],
        }
```

**SRS Coverage:** FR-25, FR-26

---

## 10. Module 6: `dashboard.py`

Contains the `ReportGenerator` class and 6 chart-creation functions with dark-themed matplotlib styling. Also includes the `create_correlation_heatmap()` and `create_trend_chart()` functions for new features.

---

### Class: `ReportGenerator`

**Purpose:** Assembles all analysis results into a single structured report and creates matplotlib Figure objects for embedding in the GUI. Also handles exporting charts as PNGs.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `respondent` | `Respondent` | User's profile data |
| `genre_profile` | `GenreProfile` | Genre cohort analysis |
| `metrics` | `list[MentalHealthMetric]` | 4 metric objects with predicted scores |
| `age_analyzer` | `AgeGroupAnalyzer` | Age bracket analysis |
| `corr_engine` | `CorrelationEngine` | Correlation results |
| `df` | `pd.DataFrame` | Full cleaned dataset |

---

#### Methods

##### `__init__(self, respondent, genre_profile, metrics, age_analyzer, corr_engine, df)`

**Functionality:** Stores references to all analysis objects.

---

##### `generate_report(self) -> dict`

**Functionality:** Assembles all analysis results into a single dictionary for the GUI to consume.

```python
def generate_report(self):
    """Assemble complete analysis report as a structured dict."""
    # Returns: {
    #   'user_summary': respondent.display_summary(),
    #   'predicted_scores': {name: score for each metric},
    #   'severity_labels': {name: severity for each metric},
    #   'percentiles': {name: percentile for each metric},
    #   'cohort_comparison': genre_profile.compare_to_cohort(predicted),
    #   'age_bracket': age_analyzer.get_bracket_stats(respondent.age),
    #   'correlations': corr_engine.correlations,
    #   'strongest_correlation': corr_engine.get_strongest(),
    #   'genre_cohort_size': genre_profile.cohort_size,
    #   'behavioural_modifiers': {
    #       'while_working': respondent.while_working,
    #       'instrumentalist': respondent.instrumentalist,
    #       'streaming_service': respondent.streaming_service,
    #       'deltas': {metric: {'while_working': float, 'instrumentalist': float, 'streaming': float}}
    #   }
    # }
```

**SRS Coverage:** FR-16

---

##### `export_visualizations(self, output_dir: str) -> list[str]`

**Functionality:** Calls all 4 chart functions, saves each as a PNG to the output directory using `figure.savefig()`. Creates the output directory if it doesn't exist.

```python
def export_visualizations(self, output_dir="output"):
    """Save all 4 charts as PNGs to the output directory."""
    # Creates: output_dir if not exists (os.makedirs)
    # Saves: genre_bar.png, age_line.png, anxiety_hist.png, scatter_plot.png
    # Returns: list of file paths
```

**SRS Coverage:** FR-21

---

### Chart Functions

All chart functions return a `matplotlib.figure.Figure` object (NOT `plt.show()`). This is critical — we embed these in PyQt5 using `FigureCanvasQTAgg`.

**Global Dark Theme** applied to all charts:

```python
CHART_STYLE = {
    'figure.facecolor': '#181818',
    'axes.facecolor': '#282828',
    'axes.edgecolor': '#535353',
    'axes.labelcolor': '#FFFFFF',
    'text.color': '#FFFFFF',
    'xtick.color': '#B3B3B3',
    'ytick.color': '#B3B3B3',
    'grid.color': '#535353',
    'grid.alpha': 0.3,
    'font.size': 11,
}
```

---

##### `create_genre_bar_chart(df: pd.DataFrame) -> Figure`

**Functionality:** Grouped bar chart showing average Anxiety, Depression, Insomnia, OCD scores for each genre.

**Data preparation:**
```python
genre_means = df.groupby('Fav genre')[['Anxiety','Depression','Insomnia','OCD']].mean()
```

**Visual spec:**
- X-axis: Genre names (rotated 45°)
- Y-axis: Average score (0–10)
- 4 bars per genre, each colored differently
- Color palette: `#1DB954` (Anxiety), `#1E90FF` (Depression), `#9B59B6` (Insomnia), `#E74C3C` (OCD)
- Legend in upper-right

**SRS Coverage:** FR-17

---

##### `create_age_line_chart(df: pd.DataFrame) -> Figure`

**Functionality:** Line chart showing how average anxiety changes across age groups, with a secondary line for hours per day.

**Data preparation:**
```python
# Create age brackets, compute mean anxiety and mean hours/day per bracket
age_groups = df.groupby('age_bracket').agg({'Anxiety': 'mean', 'Hours per day': 'mean'})
```

**Visual spec:**
- X-axis: Age brackets (10-17, 18-24, 25-34, 35-49, 50-64, 65-89)
- Y-axis (left): Average anxiety score
- Y-axis (right): Average hours/day (dual axis)
- Two lines with markers — green for anxiety, blue for hours
- Grid lines for readability

**SRS Coverage:** FR-18

---

##### `create_anxiety_histogram(df: pd.DataFrame, user_score: float) -> Figure`

**Functionality:** Histogram of anxiety score distribution across all respondents, with the user's predicted score marked as a vertical line.

**Data preparation:**
```python
anxiety_values = df['Anxiety'].values
# Bins: 0, 1, 2, ..., 10 (11 bins)
```

**Visual spec:**
- X-axis: Anxiety score (0–10)
- Y-axis: Frequency (count of respondents)
- Bars: semi-transparent green (`#1DB954`, alpha=0.7)
- User's score: bright red vertical dashed line with label "Your Score: X.X"
- Annotated with user percentile text

**SRS Coverage:** FR-19

---

##### `create_scatter_plot(df: pd.DataFrame, user_hours: float, user_depression: float) -> Figure`

**Functionality:** Scatter plot of Hours per day vs Depression score for all respondents, with the user's predicted point highlighted.

**Data preparation:**
```python
x = df['Hours per day'].values
y = df['Depression'].values
```

**Visual spec:**
- X-axis: Hours per day
- Y-axis: Depression score (0–10)
- Dataset points: small, semi-transparent white dots (`alpha=0.4`)
- User's point: large star marker, bright green (`#1DB954`), with annotation "You"
- Optional: trend line using `np.polyfit(x, y, 1)` for linear regression visualization

**Trend line formula:**
$$y = mx + b \quad \text{where } [m, b] = \text{np.polyfit}(x, y, 1)$$

**SRS Coverage:** FR-20

---

##### `create_correlation_heatmap(df: pd.DataFrame) -> Figure`

**Functionality:** A 5×5 heatmap showing Pearson correlations between `Hours per day`, `Anxiety`, `Depression`, `Insomnia`, and `OCD`.

**Data preparation:**
```python
cols = ['Hours per day', 'Anxiety', 'Depression', 'Insomnia', 'OCD']
corr_matrix = df[cols].corr()  # returns 5×5 DataFrame
```

**Visual spec:**
- Rendered with `matplotlib.imshow()` — no seaborn dependency
- Color map: `RdYlGn_r` (red = strong positive correlation, green = negative)
- Cell annotations: correlation value as `{r:.2f}` centered in each cell
- Diagonal cells (self-correlation = 1.0) rendered distinctly (darker shade)
- X and Y axis labels: column names, rotated 45° on X

**SRS Coverage:** FR-27

---

##### `create_trend_chart(trend_data: dict, session_count: int) -> Figure`

**Functionality:** Multi-line chart showing the user's predicted scores across all stored sessions. Only rendered if `session_count >= 2`. If fewer than 2 sessions exist, this function returns `None` and the GUI shows a "Run more sessions to see your trend" placeholder.

**Data preparation:**
```python
# trend_data from HistoryManager.get_trend_data()
# {'Anxiety': [6.2, 5.8, 5.1], 'Depression': [...], ...}
sessions_x = list(range(1, session_count + 1))
```

**Visual spec:**
- X-axis: Session number (1, 2, 3, ...)
- Y-axis: Predicted score (0–10)
- 4 lines, one per metric, with metric-specific colors
- Markers at each data point
- Dashed horizontal reference line at y=5.0 (midpoint)
- Title: "Your MoodMap Score Trend"

**SRS Coverage:** FR-26

---

##### `export_visualizations(self, output_dir: str) -> list[str]`

**Functionality:** Calls all chart functions, saves each as PNG to the output directory.

```python
def export_visualizations(self, output_dir="output"):
    """Save all charts as PNGs to the output directory."""
    # Creates: output_dir if not exists (os.makedirs)
    # Saves: genre_bar.png, age_line.png, anxiety_hist.png,
    #        scatter_plot.png, correlation_heatmap.png
    # trend_chart.png saved only if session_count >= 2
    # Returns: list of file paths
```

**SRS Coverage:** FR-21

---

## 11. Module 7: `pdf_export.py`

Contains the `PDFExporter` class. Generates a single-file PDF report that packages the user's scores, cohort comparison, recommendations, and all charts.

---

### Class: `PDFExporter`

**Purpose:** Produce a professionally formatted PDF using `fpdf2`. The PDF is saved to `/output/moodmap_report_{timestamp}.pdf`.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `report` | `dict` | The report dict from `ReportGenerator.generate_report()` |
| `chart_paths` | `list[str]` | File paths of exported PNG charts |
| `recommendations` | `list[str]` | From `RecommendationEngine.get_behaviour_recommendations()` |
| `genre_rec` | `dict` | From `RecommendationEngine.get_genre_recommendation()` |
| `output_dir` | `str` | Directory to save the PDF |

---

#### Methods

##### `generate(self) -> str`

**Functionality:** Builds and saves the full PDF. Returns the output file path.

**PDF structure:**
1. **Cover page** — Title "MoodMap Report", timestamp, user inputs summary
2. **Predicted Scores page** — 4 score cards with severity labels and percentiles
3. **Cohort Comparison table** — Your score vs genre mean vs age mean with delta
4. **Confidence Indicators** — Cohort sizes for genre, age, and intersection cohorts
5. **Recommendations section** — Behaviour recommendations + genre recommendation
6. **Charts section** — Each PNG embedded full-width, one per page
7. **About section** — One paragraph explaining the statistical methodology

```python
from fpdf import FPDF
from datetime import datetime

class PDFExporter:
    """Generate PDF report using fpdf2."""

    def __init__(self, report, chart_paths, recommendations, genre_rec, output_dir="output"):
        self.report = report
        self.chart_paths = chart_paths
        self.recommendations = recommendations
        self.genre_rec = genre_rec
        self.output_dir = output_dir

    def generate(self) -> str:
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)

        # Cover page
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 24)
        pdf.cell(0, 20, "MoodMap — Mental Health Profile", ln=True, align='C')
        pdf.set_font("Helvetica", "", 12)
        pdf.cell(0, 10, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True, align='C')

        # Scores section
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 12, "Predicted Scores", ln=True)
        for metric, score in self.report['predicted_scores'].items():
            severity = self.report['severity_labels'][metric]
            pct = self.report['percentiles'][metric]
            pdf.set_font("Helvetica", "", 12)
            pdf.cell(0, 8, f"{metric}: {score:.1f}  |  {severity}  |  {pct}th percentile", ln=True)

        # Recommendations section
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 12, "Recommendations", ln=True)
        for rec in self.recommendations:
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 7, f"- {rec}")

        # Charts — one per page
        for chart_path in self.chart_paths:
            pdf.add_page()
            pdf.image(chart_path, x=10, y=20, w=190)

        filename = f"moodmap_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        out_path = f"{self.output_dir}/{filename}"
        pdf.output(out_path)
        return out_path
```

**SRS Coverage:** FR-28

---

---

## 12. Module 8: `gui.py`

The largest module. Implements the full PyQt5 GUI with 6 pages, Spotify-dark theming, theme toggle, onboarding tooltips, and comparative mode.

---

### Class: `MoodMapApp(QMainWindow)`

**Purpose:** The main application window. Contains a `QStackedWidget` that holds 6 pages and manages navigation between them.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `df` | `pd.DataFrame` | Cleaned dataset (loaded on init) |
| `data_loader` | `DataLoader` | DataLoader instance |
| `history_manager` | `HistoryManager` | SQLite session manager |
| `is_dark_theme` | `bool` | Current theme state (default: `True`) |
| `stacked_widget` | `QStackedWidget` | Manages all pages |
| `welcome_page` | `WelcomePage` | Page 0: Landing screen |
| `questionnaire_page` | `QuestionnairePage` | Page 1: User input collection |
| `loading_page` | `LoadingPage` | Page 2: Analysis animation |
| `results_page` | `ResultsPage` | Page 3: Dashboard with charts + recommendations |
| `history_page` | `HistoryPage` | Page 4: Session history + trend chart |
| `compare_page` | `ComparePage` | Page 5: Comparative mode |

---

#### Methods

##### `__init__(self)`

**Functionality:**
1. Sets window title: `"MoodMap — Music & Mental Health Profiler"`
2. Sets window size: `1200 × 800` pixels
3. Applies global dark-mode stylesheet (QSS); stores light-mode QSS for toggle
4. Creates `DataLoader`, loads dataset
5. Creates `HistoryManager`, connects to `moodmap_history.db`
6. Creates all 6 pages and adds them to `QStackedWidget`
7. Connects page navigation signals
8. Runs `OnboardingTooltipManager` on first launch (checks a flag in the DB)

---

##### `toggle_theme(self)`

**Functionality:** Switches between dark and light QSS stylesheets. Updates `self.is_dark_theme`. The theme toggle button is always visible in the top-right corner of the window, outside the `QStackedWidget`.

```python
def toggle_theme(self):
    """Switch between dark and light themes."""
    if self.is_dark_theme:
        self.setStyleSheet(LIGHT_QSS)
    else:
        self.setStyleSheet(DARK_QSS)
    self.is_dark_theme = not self.is_dark_theme
```

**SRS Coverage:** FR-32

---

##### `launch_comparative_mode(self, base_respondent)`

**Functionality:** Pre-populates `ComparePage` with the current respondent's answers minus one field (user chooses which to swap). Navigates to `ComparePage` without resetting the original results.

**SRS Coverage:** FR-29

---

### New Pages

##### `HistoryPage`

**Purpose:** Displays a scrollable table of all past sessions and embeds the `create_trend_chart()` figure. Includes a "Clear History" button (with confirmation dialog) and per-row "Delete" buttons.

**SRS Coverage:** FR-25, FR-26

---

##### `ComparePage`

**Purpose:** Shows the questionnaire pre-filled with the current session's answers. User changes exactly one field and hits "Compare." The page splits into a two-column view showing original prediction (left) vs new prediction (right) with delta indicators (↑↓ arrows, red/green coloring).

**SRS Coverage:** FR-29

---

### Onboarding Tooltip Manager

##### `OnboardingTooltipManager`

**Purpose:** On first application launch, displays a non-blocking tooltip overlay on each questionnaire field explaining what the input means clinically:

| Field | Tooltip text |
|---|---|
| Age | "Used to group you with respondents in the same life stage." |
| Fav genre | "Your primary music genre. Affects cohort composition most strongly." |
| Hours/day | "Self-reported average daily listening time." |
| While working | "Whether you play music during focused work or study." |
| Instrumentalist | "Whether you play a musical instrument regularly." |
| Streaming service | "Your primary platform — used as a behavioural modifier." |

First-launch detection: a `settings` table in SQLite stores `{key: 'onboarding_shown', value: '1'}` after first run.

**SRS Coverage:** FR-33

---

##### `apply_stylesheet(self)`

**Functionality:** Applies the Spotify-dark QSS stylesheet to the entire application. See [GUI Design Specification](#12-gui-design-specification) for full stylesheet.

---

##### `navigate_to(self, page_index: int)`

**Functionality:** Transitions the `QStackedWidget` to the specified page index with a fade or slide animation.

---

##### `run_analysis(self, respondent: Respondent)`

**Functionality:** Called when questionnaire is complete. Orchestrates the full analysis pipeline:

1. Creates `GenreProfile` from respondent + dataset
2. Calls `predict_mental_health()` to get predicted scores
3. Creates 4 × `MentalHealthMetric` objects
4. Creates `AgeGroupAnalyzer` and `CorrelationEngine`
5. Creates `ReportGenerator` and calls `generate_report()`
6. Creates 4 matplotlib Figures
7. Passes everything to `ResultsPage` for rendering
8. Navigates to results page

---

### Class: `WelcomePage(QWidget)`

**Purpose:** The landing screen. Shows branding and a "Get Started" button.

#### Widgets

| Widget | Type | Description |
|---|---|---|
| Title label | `QLabel` | "MoodMap" — large, bold, gradient-green text |
| Subtitle label | `QLabel` | "Music & Mental Health Profiler" |
| Tagline label | `QLabel` | "Discover how your music shapes your mind" |
| Start button | `QPushButton` | "Get Started →" — green accent, hover animation |
| Version label | `QLabel` | "v1.0 · PFAI Project · UMT 2026" — bottom footer |

#### Methods

##### `__init__(self, parent)`

**Functionality:** Builds the welcome layout with centered vertical alignment. All text is center-aligned. Button emits signal to navigate to questionnaire page.

---

### Class: `QuestionnairePage(QWidget)`

**Purpose:** Collects user inputs one question at a time with navigation controls, a progress bar, and input validation.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `questions` | `list[dict]` | List of question configurations |
| `current_index` | `int` | Index of the currently displayed question (0–5) |
| `answers` | `dict` | Collected answers: `{field_name: value}` |
| `progress_bar` | `QProgressBar` | Shows completion percentage |
| `question_stack` | `QStackedWidget` | Holds individual question widgets |
| `back_btn` | `QPushButton` | Back navigation |
| `next_btn` | `QPushButton` | Next / Submit navigation |

---

#### Question Definitions

| Index | Field | Widget | Options / Range | Validation |
|---|---|---|---|---|
| 0 | Age | `QSpinBox` | 10–89 | Built-in range constraint |
| 1 | Fav genre | `QComboBox` | 16 genres from dataset | Must select one |
| 2 | Hours per day | `QSlider` + `QLabel` | 0–24 (step 0.5) | None needed |
| 3 | While working | Two `QPushButton` toggles | Yes / No | Must select one |
| 4 | Instrumentalist | Two `QPushButton` toggles | Yes / No | Must select one |
| 5 | Streaming service | `QComboBox` | 6 services from dataset | Must select one |
| 6 | Summary | Read-only `QLabel` | Shows all answers | Confirm or go back |

---

#### Methods

##### `__init__(self, genres: list, services: list, parent)`

**Functionality:** Builds all 7 sub-pages (6 questions + 1 summary). Stores the genre and service lists from `DataLoader`. Initializes progress bar at 0%.

---

##### `show_question(self, index: int)`

**Functionality:** Displays the question at the given index. Updates progress bar:

$$\text{progress} = \frac{\text{index}}{\text{total\_questions}} \times 100$$

Updates the Next button text to "Submit" on the summary page.

---

##### `go_next(self)`

**Functionality:** Saves the current answer, validates it, advances to the next question. On the summary page, emits a signal with the completed `Respondent` object.

---

##### `go_back(self)`

**Functionality:** Returns to the previous question. Disables the Back button when at index 0.

---

##### `collect_respondent(self) -> Respondent`

**Functionality:** Creates and returns a `Respondent` object from all collected answers.

```python
def collect_respondent(self):
    """Build Respondent from collected answers."""
    return Respondent(
        age=self.answers['age'],
        fav_genre=self.answers['fav_genre'],
        hours_per_day=self.answers['hours_per_day'],
        while_working=self.answers['while_working'],
        instrumentalist=self.answers['instrumentalist'],
        streaming_service=self.answers['streaming_service']
    )
```

---

### Class: `LoadingPage(QWidget)`

**Purpose:** Displays an animated loading screen while analysis runs. Shows progress status messages.

#### Widgets

| Widget | Type | Description |
|---|---|---|
| Spinner | `QLabel` + `QMovie` or custom paint | Animated loading indicator |
| Status label | `QLabel` | Rotating status messages |
| Progress bar | `QProgressBar` | Visual progress indicator |

#### Status Messages (cycled with QTimer)

```python
messages = [
    "Loading your music profile...",
    "Analyzing your genre cohort...",
    "Computing correlations...",
    "Crunching the numbers...",
    "Building your mental health profile...",
    "Almost there..."
]
```

---

### Class: `ResultsPage(QWidget)`

**Purpose:** The main results dashboard. Displays predicted scores, percentiles, cohort comparisons, confidence indicators, recommendations, BPM correlation insight, and 5 embedded matplotlib charts.

---

#### Attributes

| Attribute | Type | Description |
|---|---|---|
| `report` | `dict` | Full report from `ReportGenerator.generate_report()` |
| `figures` | `list[Figure]` | Matplotlib Figure objects (up to 5) |
| `canvases` | `list[FigureCanvasQTAgg]` | Canvas widgets for chart embedding |
| `scroll_area` | `QScrollArea` | Makes the page scrollable |

---

#### Layout Structure

```
┌─────────────────────────────────────────────────────┐
│  🎵 Your MoodMap Profile                            │
├─────────────────────────────────────────────────────┤
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────┐ │
│  │ Anxiety  │ │Depression│ │ Insomnia │ │  OCD   │ │
│  │  6.2     │ │  4.1     │ │  3.8     │ │  2.5   │ │
│  │  HIGH    │ │ MODERATE │ │ MODERATE │ │  LOW   │ │
│  │  72nd %  │ │  48th %  │ │  45th %  │ │ 30th % │ │
│  └──────────┘ └──────────┘ └──────────┘ └────────┘ │
├─────────────────────────────────────────────────────┤
│  📊 Cohort Comparison  (Based on 142 respondents) ← │
│                           confidence indicator       │
│  ┌─────────────────────────────────────────┐        │
│  │ Metric │ You │ Genre Avg │ Age Avg │ Δ  │        │
│  └─────────────────────────────────────────┘        │
├─────────────────────────────────────────────────────┤
│  💡 Recommendations                                  │
│  • Reducing daily hours may lower Anxiety by ~15%   │
│  • Best match genre: Classical (composite 3.8)      │
├─────────────────────────────────────────────────────┤
│  🔗 Insights                                         │
│  Hours ↔ Insomnia  r = 0.068 (strongest)            │
│  BPM ↔ Anxiety     r = 0.041                        │
├─────────────────────────────────────────────────────┤
│  ┌────────────────┐ ┌────────────────┐              │
│  │ Genre Bar Chart│ │ Age Line Chart │              │
│  └────────────────┘ └────────────────┘              │
│  ┌────────────────┐ ┌────────────────┐              │
│  │ Histogram      │ │ Scatter Plot   │              │
│  └────────────────┘ └────────────────┘              │
│  ┌────────────────────────────────────┐              │
│  │ Correlation Heatmap                │              │
│  └────────────────────────────────────┘              │
├─────────────────────────────────────────────────────┤
│  [📥 Export PNG] [📄 Export PDF] [🔀 Compare]       │
│  [📈 View History]               [🔄 Start Over]    │
└─────────────────────────────────────────────────────┘
```

---

#### Methods

##### `__init__(self, parent)`

**Functionality:** Builds the scrollable layout with placeholder areas for score cards, comparison table, insight text, and 4 chart canvases. Initially empty — populated when `display_results()` is called.

---

##### `display_results(self, report: dict, figures: list[Figure])`

**Functionality:** Populates all widgets with data from the report dict:

1. Creates 4 score cards with color-coded severity
2. Fills cohort comparison table
3. Writes correlation insight text
4. Embeds 4 matplotlib Figures using `FigureCanvasQTAgg`

```python
def display_results(self, report, figures):
    """Populate the results dashboard with analysis data."""
    # For each metric: create score card widget
    # For comparison: fill QTableWidget
    # For charts: create FigureCanvasQTAgg(figure) and add to grid layout
```

---

##### `export_charts(self)`

**Functionality:** Calls `ReportGenerator.export_visualizations()` to save PNGs. Shows a success dialog with the output path.

---

##### `start_over(self)`

**Functionality:** Emits signal to reset the questionnaire and navigate back to the welcome page.

---

## 10. Module 6: `moodmap.py`

#### [NEW] [moodmap.py](file:///c:/Users/lenovo/OneDrive/Desktop/Python/PFAI%20PROJECT/moodmap.py)

**Purpose:** Minimal entry point. Creates the Qt application and launches the main window.

```python
"""
MoodMap — Music & Mental Health Profiler
Entry point for the PyQt5 desktop application.
"""
import sys
from PyQt5.QtWidgets import QApplication
from gui import MoodMapApp


def main():
    """Launch the MoodMap application."""
    app = QApplication(sys.argv)
    app.setApplicationName("MoodMap")
    window = MoodMapApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
```

---

## 11. Formulas & Mathematical Reference

All formulas used in MoodMap, collected in one place:

### 11.1 Percentile Rank (FR-11)

$$\text{percentile}(s) = \frac{\text{count}(x_i \leq s)}{N} \times 100$$

- $s$ = user's predicted score for a metric
- $x_i$ = individual respondent scores from the dataset
- $N$ = total number of respondents
- **Implementation:** `np.sum(dataset_values <= score) / len(dataset_values) * 100`

---

### 11.2 Pearson Correlation Coefficient (FR-14)

$$r_{xy} = \frac{\sum_{i=1}^{n}(x_i - \bar{x})(y_i - \bar{y})}{\sqrt{\sum_{i=1}^{n}(x_i - \bar{x})^2 \cdot \sum_{i=1}^{n}(y_i - \bar{y})^2}}$$

- $x$ = `Hours per day`
- $y$ = mental health metric (Anxiety, Depression, Insomnia, or OCD)
- **Implementation:** `np.corrcoef(x, y)[0, 1]`
- **Range:** -1.0 (perfect negative) to +1.0 (perfect positive)

---

### 11.3 Cohort-Weighted Prediction

**Base score** for each metric $m$:

$$
\text{base}_m =
\begin{cases}
0.60 \cdot \bar{x}_{m}^{\cap} + 0.25 \cdot \bar{x}_{m}^{G} + 0.15 \cdot \bar{x}_{m}^{A} & \text{if } |\text{intersection}| \geq 10 \\[6pt]
0.50 \cdot \bar{x}_{m}^{G} + 0.50 \cdot \bar{x}_{m}^{A} & \text{if } |\text{intersection}| < 10
\end{cases}
$$

| Symbol | Meaning |
|---|---|
| $\bar{x}_{m}^{\cap}$ | Mean of metric $m$ in the **intersection** cohort (same genre AND age bracket) |
| $\bar{x}_{m}^{G}$ | Mean of metric $m$ in the **genre** cohort |
| $\bar{x}_{m}^{A}$ | Mean of metric $m$ in the **age bracket** cohort |

**Hours adjustment:**

$$\text{predicted}_m = \text{base}_m + (\text{hours}_{\text{user}} - \bar{h}^{G}) \times r_m$$

| Symbol | Meaning |
|---|---|
| $\text{hours}_{\text{user}}$ | User's reported hours per day |
| $\bar{h}^{G}$ | Mean hours/day in the genre cohort |
| $r_m$ | Pearson correlation between hours/day and metric $m$ |

**Clamping:**

$$\text{final}_m = \max(0, \min(10, \text{predicted}_m))$$

- **Implementation:** `np.clip(predicted, 0.0, 10.0)`

---

### 11.4 Severity Classification

$$
\text{severity}(s) =
\begin{cases}
\text{"Low"} & \text{if } 0.0 \leq s \leq 3.0 \\
\text{"Moderate"} & \text{if } 3.0 < s \leq 6.0 \\
\text{"High"} & \text{if } 6.0 < s \leq 10.0
\end{cases}
$$

---

### 11.5 Cohort Mean

$$\bar{x}_{m,C} = \frac{1}{|C|} \sum_{i \in C} x_{i,m}$$

- $C$ = cohort (genre, age bracket, or intersection)
- **Implementation:** `np.mean(cohort[metric].values)`

---

### 11.6 Linear Trend Line (Scatter Plot)

$$y = mx + b \quad \text{where } [m, b] = \text{np.polyfit}(x, y, 1)$$

- Used in the scatter plot (FR-20) to show the overall trend between hours/day and depression

---

### 11.7 Behavioural Modifier Delta (FR-22)

$$\delta^{B}_m = \alpha \cdot \left(\bar{x}_{m,\text{cohort}(B=v)} - \bar{x}_{m,\text{global}}\right)$$

where:
- $B \in \{\text{While working, Instrumentalist, Primary streaming service}\}$
- $v$ = the user's value for attribute $B$
- $\bar{x}_{m,\text{cohort}(B=v)}$ = mean of metric $m$ among respondents with the same value $v$
- $\bar{x}_{m,\text{global}}$ = mean of metric $m$ across the full dataset
- $\alpha = 0.15$ = dampening factor
- Applied only when $|\text{cohort}(B=v)| \geq 5$; otherwise $\delta^{B}_m = 0.0$

**Full prediction pipeline summary:**

$$\text{final}_m = \text{clip}\left(\underbrace{\text{base}_m}_{\text{Steps 1-4}} + \underbrace{h_{\text{dev}} \cdot r_m}_{\text{Step 5}} + \underbrace{\delta^{W}_m + \delta^{I}_m + \delta^{S}_m}_{\text{Step 6}},\ 0.0,\ 10.0\right)$$

- **Implementation:** See `predict_mental_health()` in `engine.py`, Steps 1–7

---

## 12. GUI Design Specification

### 12.1 Color System

| Token | Hex | Usage |
|---|---|---|
| `--bg-primary` | `#121212` | Main window background |
| `--bg-secondary` | `#181818` | Card/panel backgrounds |
| `--bg-tertiary` | `#282828` | Input fields, elevated surfaces |
| `--bg-hover` | `#333333` | Hover state for interactive elements |
| `--accent` | `#1DB954` | Primary accent — buttons, progress, highlights |
| `--accent-hover` | `#1ED760` | Accent hover state |
| `--text-primary` | `#FFFFFF` | Main text |
| `--text-secondary` | `#B3B3B3` | Subtitles, captions, secondary info |
| `--text-muted` | `#727272` | Disabled text, placeholders |
| `--severity-low` | `#1DB954` | Low severity (green) |
| `--severity-moderate` | `#F39C12` | Moderate severity (amber) |
| `--severity-high` | `#E74C3C` | High severity (red) |
| `--border` | `#535353` | Subtle borders |
| `--chart-anxiety` | `#1DB954` | Chart color: Anxiety |
| `--chart-depression` | `#1E90FF` | Chart color: Depression |
| `--chart-insomnia` | `#9B59B6` | Chart color: Insomnia |
| `--chart-ocd` | `#E74C3C` | Chart color: OCD |

---

### 12.2 Typography

| Element | Font | Size | Weight | Color |
|---|---|---|---|---|
| App title | Segoe UI | 36px | Bold | `#1DB954` |
| Page heading | Segoe UI | 24px | Bold | `#FFFFFF` |
| Section heading | Segoe UI | 18px | SemiBold | `#FFFFFF` |
| Body text | Segoe UI | 14px | Regular | `#FFFFFF` |
| Secondary text | Segoe UI | 14px | Regular | `#B3B3B3` |
| Caption | Segoe UI | 12px | Regular | `#727272` |
| Score number | Segoe UI | 42px | Bold | Severity color |
| Button text | Segoe UI | 14px | SemiBold | `#000000` (on accent) |

---

### 12.3 Component Styling

| Component | Background | Border | Border Radius | Padding |
|---|---|---|---|---|
| Score card | `#181818` | none | 16px | 24px |
| Input field / combo | `#282828` | 1px `#535353` | 8px | 8px 12px |
| Primary button | `#1DB954` | none | 24px | 12px 32px |
| Secondary button | `transparent` | 1px `#535353` | 24px | 12px 32px |
| Progress bar track | `#535353` | none | 4px | — |
| Progress bar fill | `#1DB954` | none | 4px | — |
| Question card | `#181818` | none | 16px | 32px |
| Chart container | `#181818` | none | 12px | 16px |

---

### 12.4 QSS Stylesheet (Core Excerpt)

```css
QMainWindow {
    background-color: #121212;
}

QLabel {
    color: #FFFFFF;
    font-family: "Segoe UI";
}

QPushButton#primary {
    background-color: #1DB954;
    color: #000000;
    border: none;
    border-radius: 24px;
    padding: 12px 32px;
    font-size: 14px;
    font-weight: 600;
    font-family: "Segoe UI";
}

QPushButton#primary:hover {
    background-color: #1ED760;
}

QPushButton#secondary {
    background-color: transparent;
    color: #FFFFFF;
    border: 1px solid #535353;
    border-radius: 24px;
    padding: 12px 32px;
    font-size: 14px;
    font-family: "Segoe UI";
}

QPushButton#secondary:hover {
    background-color: #333333;
}

QComboBox {
    background-color: #282828;
    color: #FFFFFF;
    border: 1px solid #535353;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 14px;
    font-family: "Segoe UI";
}

QSpinBox {
    background-color: #282828;
    color: #FFFFFF;
    border: 1px solid #535353;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 14px;
    font-family: "Segoe UI";
}

QSlider::groove:horizontal {
    height: 6px;
    background: #535353;
    border-radius: 3px;
}

QSlider::handle:horizontal {
    background: #1DB954;
    width: 18px;
    height: 18px;
    border-radius: 9px;
    margin: -6px 0;
}

QSlider::sub-page:horizontal {
    background: #1DB954;
    border-radius: 3px;
}

QProgressBar {
    background-color: #535353;
    border: none;
    border-radius: 4px;
    height: 6px;
    text-align: center;
}

QProgressBar::chunk {
    background-color: #1DB954;
    border-radius: 4px;
}

QScrollArea {
    background-color: #121212;
    border: none;
}
```

---

## 13. SRS Traceability Matrix

| SRS ID | Requirement | Module | Class/Function | Status |
|---|---|---|---|---|
| FR-01 | Load CSV | `data_loader.py` | `DataLoader.load()` | Planned |
| FR-02 | Drop null mental health rows | `data_loader.py` | `DataLoader.clean()` | Planned |
| FR-03 | Impute BPM median | `data_loader.py` | `DataLoader.clean()` | Planned |
| FR-04 | Normalize column names | `data_loader.py` | `DataLoader.clean()` | Planned |
| FR-05 | Validate ≥500 rows | `data_loader.py` | `DataLoader.validate()` | Planned |
| FR-06 | One question at a time | `gui.py` | `QuestionnairePage` | Planned |
| FR-07 | Collect 6 inputs (all used in prediction) | `gui.py` | `QuestionnairePage` | Planned |
| FR-08 | Validate age 10–89 | `gui.py` | `QSpinBox` range | Planned |
| FR-09 | Genre options from dataset | `gui.py` + `data_loader.py` | `get_unique_genres()` | Planned |
| FR-10 | Confirm inputs before processing | `gui.py` | `QuestionnairePage` summary | Planned |
| FR-11 | Percentile rank computation | `domain.py` | `MentalHealthMetric.compute_percentile()` | Planned |
| FR-12 | Genre cohort averages | `domain.py` | `GenreProfile.get_cohort_stats()` | Planned |
| FR-13 | Age bracket segmentation | `engine.py` | `AgeGroupAnalyzer` | Planned |
| FR-14 | NumPy Pearson correlation | `engine.py` | `CorrelationEngine.compute_correlations()` | Planned |
| FR-15 | Genre with lowest composite | `dashboard.py` | `ReportGenerator.generate_report()` | Planned |
| FR-16 | Profile summary output | `gui.py` | `ResultsPage.display_results()` | Planned |
| FR-17 | Bar chart: genre scores | `dashboard.py` | `create_genre_bar_chart()` | Planned |
| FR-18 | Line chart: hours vs anxiety | `dashboard.py` | `create_age_line_chart()` | Planned |
| FR-19 | Histogram: anxiety distribution | `dashboard.py` | `create_anxiety_histogram()` | Planned |
| FR-20 | Scatter: hours vs depression | `dashboard.py` | `create_scatter_plot()` | Planned |
| FR-21 | Save PNGs to /output | `dashboard.py` | `ReportGenerator.export_visualizations()` | Planned |
| FR-22 | Behavioural modifier adjustments | `engine.py` | `predict_mental_health()` Step 6 | Planned |
| FR-23 | Behaviour change recommendations | `recommender.py` | `RecommendationEngine.get_behaviour_recommendations()` | Planned |
| FR-24 | Genre swap recommendation | `recommender.py` | `RecommendationEngine.get_genre_recommendation()` | Planned |
| FR-25 | Save session to SQLite history | `history.py` | `HistoryManager.save_session()` | Planned |
| FR-26 | Session trend chart | `dashboard.py` + `history.py` | `create_trend_chart()` + `HistoryManager.get_trend_data()` | Planned |
| FR-27 | Correlation heatmap (5×5) | `dashboard.py` | `create_correlation_heatmap()` | Planned |
| FR-28 | PDF report export | `pdf_export.py` | `PDFExporter.generate()` | Planned |
| FR-29 | Comparative mode (swap one input) | `gui.py` | `ComparePage` + `MoodMapApp.launch_comparative_mode()` | Planned |
| FR-30 | Confidence indicator (cohort size) | `gui.py` + `domain.py` | `ResultsPage` + `GenreProfile.cohort_size` | Planned |
| FR-31 | BPM correlation insight | `engine.py` + `gui.py` | `CorrelationEngine` + `ResultsPage` | Planned |
| FR-32 | Dark/Light theme toggle | `gui.py` | `MoodMapApp.toggle_theme()` | Planned |
| FR-33 | Onboarding tooltips (first launch) | `gui.py` + `history.py` | `OnboardingTooltipManager` | Planned |

---

## 14. Verification Plan

### Automated
```bash
python moodmap.py
```
- Verify the GUI window opens at 1200×800
- Confirm dataset loads (status in console or GUI)
- Walk through all 6 questions + summary confirmation
- Verify all 5 charts render in the results dashboard
- Verify recommendations panel shows ≥1 recommendation
- Verify confidence indicator shows cohort size
- Verify BPM correlation line appears in insights
- Click "Export PNG" → confirm 5 PNGs in `/output`
- Click "Export PDF" → confirm PDF in `/output` with scores + charts
- Click "Compare" → verify ComparePage pre-fills answers; change one field; verify side-by-side delta view
- Click "View History" → verify HistoryPage shows session table; trend chart visible after 2+ sessions
- Click theme toggle → confirm light/dark switch
- Restart app → confirm HistoryPage still shows previous session

### Edge Cases
| Test | Expected Behavior |
|---|---|
| Age = 10 (minimum) | Accepted, placed in "10-17" bracket |
| Age = 89 (maximum) | Accepted, placed in "65-89" bracket |
| Hours/Day = 0 | Accepted, negative hours deviation |
| Hours/Day = 24 | Accepted, large positive deviation |
| Rare genre with small intersection cohort | Falls back to 50/50 genre+age weighting |
| Dataset file missing | Error dialog shown, app doesn't crash |
| Dataset has <500 rows after cleaning | Error dialog shown |
| `while_working = "Yes"` vs `"No"` | Different delta; max shift ≤ ±ALPHA×(cohort_diff) |
| `instrumentalist = "Yes"` vs `"No"` | Different delta applied |
| Rare streaming service with <5 respondents | Modifier delta = 0.0, no crash |
| All behavioural modifiers combined | Scores stay within [0, 10] via clamp |
| First launch | Onboarding tooltips appear on questionnaire fields |
| Second launch | Onboarding tooltips do NOT appear |
| History DB missing | `HistoryManager.__init__` creates it fresh, no crash |
| Trend chart with 1 session | "Run more sessions" placeholder shown, no crash |
| Trend chart with 2+ sessions | Multi-line chart renders correctly |
| Comparative mode — same answers | All deltas = 0.0, no crash |
| PDF export — output/ doesn't exist | Directory auto-created, PDF saved |
| Recommendation engine — user already at genre minimum | No genre recommendation shown (delta ≈ 0) |

### Edge Cases
| Test | Expected Behavior |
|---|---|
| Age = 10 (minimum) | Accepted, placed in "10-17" bracket |
| Age = 89 (maximum) | Accepted, placed in "65-89" bracket |
| Hours/Day = 0 | Accepted, negative hours deviation in prediction |
| Hours/Day = 24 | Accepted, large positive deviation |
| Rare genre with small cohort | Falls back to 50/50 genre+age weighting |
| Dataset file missing | Error dialog shown, app doesn't crash |
| Dataset has <500 rows after cleaning | Error dialog shown |
| `while_working = "Yes"` vs `"No"` | Different delta applied per metric; scores shift by at most ±ALPHA×(cohort_diff) |
| `instrumentalist = "Yes"` vs `"No"` | Different delta applied; instrumentalist cohort typically shows lower anxiety in MxMH data |
| Rare streaming service with <5 respondents | Modifier delta set to 0.0 (guard fires), no crash |
| All behavioural modifiers combined | Sum of three deltas does not push score outside [0, 10] due to Step 7 clamp |

### OOP Checklist
- [ ] `GenreProfile` inherits `Respondent` — verified with `isinstance()`
- [ ] All classes in separate modules
- [ ] Every method has a docstring
- [ ] No function exceeds 40 lines
- [ ] Encapsulation: no direct attribute mutation from outside classes
