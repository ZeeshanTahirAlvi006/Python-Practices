"""
history.py — MoodMap Session History Manager (CSV-based)

Manages session persistence using CSV file handling instead of SQLite.
Stores prediction sessions in moodmap_history.csv and app settings
in moodmap_settings.csv.

SRS Coverage: FR-25, FR-26
"""

import csv
import os
from datetime import datetime


class HistoryManager:
    """Manages persistent session storage using CSV file handling.

    Sessions are stored in a CSV file with one row per session.
    Settings (e.g. onboarding flag) stored in a separate CSV.

    Attributes:
        history_path (str): Path to the sessions CSV file.
        settings_path (str): Path to the settings CSV file.
    """

    HISTORY_FIELDS = [
        'id', 'timestamp', 'age', 'genre', 'hours',
        'while_working', 'instrumentalist', 'streaming',
        'anxiety', 'depression', 'insomnia', 'ocd',
        'anxiety_pct', 'depression_pct', 'insomnia_pct', 'ocd_pct'
    ]

    def __init__(self, history_path: str = 'moodmap_history.csv',
                 settings_path: str = 'moodmap_settings.csv') -> None:
        """Initialize HistoryManager with paths to CSV files.

        Creates the CSV files with headers if they don't exist.
        """
        self.history_path = history_path
        self.settings_path = settings_path
        self._ensure_history_file()
        self._ensure_settings_file()

    def _ensure_history_file(self) -> None:
        """Create history CSV with header if it doesn't exist."""
        if not os.path.exists(self.history_path):
            self._write_csv_header(self.history_path, self.HISTORY_FIELDS)

    def _ensure_settings_file(self) -> None:
        """Create settings CSV with header if it doesn't exist."""
        if not os.path.exists(self.settings_path):
            self._write_csv_header(self.settings_path, ['key', 'value'])

    def _write_csv_header(self, path: str, fields: list) -> None:
        """Write header row to a new CSV file."""
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()

    def save_session(self, respondent, predicted_scores: dict,
                     percentiles: dict) -> int:
        """Save a prediction session to the history CSV.

        Args:
            respondent: Respondent object with user inputs.
            predicted_scores: {metric: predicted_value}.
            percentiles: {metric: percentile_value}.

        Returns:
            int: The new session ID.
        """
        session_id = self.get_session_count() + 1
        row = self._build_session_row(
            session_id, respondent, predicted_scores, percentiles
        )
        self._append_row(row)
        return session_id

    def _build_session_row(self, session_id: int, respondent,
                           predicted_scores: dict,
                           percentiles: dict) -> dict:
        """Build a CSV row dict from session data."""
        return {
            'id': session_id,
            'timestamp': datetime.now().isoformat(),
            'age': respondent.age,
            'genre': respondent.fav_genre,
            'hours': respondent.hours_per_day,
            'while_working': respondent.while_working,
            'instrumentalist': respondent.instrumentalist,
            'streaming': respondent.streaming_service,
            'anxiety': round(predicted_scores['Anxiety'], 2),
            'depression': round(predicted_scores['Depression'], 2),
            'insomnia': round(predicted_scores['Insomnia'], 2),
            'ocd': round(predicted_scores['OCD'], 2),
            'anxiety_pct': int(percentiles['Anxiety']),
            'depression_pct': int(percentiles['Depression']),
            'insomnia_pct': int(percentiles['Insomnia']),
            'ocd_pct': int(percentiles['OCD']),
        }

    def _append_row(self, row: dict) -> None:
        """Append a single row to the history CSV."""
        with open(self.history_path, 'a', newline='',
                  encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=self.HISTORY_FIELDS)
            writer.writerow(row)

    def get_all_sessions(self) -> list:
        """Return all sessions as a list of dicts, newest first.

        Returns:
            list[dict]: All session rows.
        """
        sessions = self._read_all_rows()
        sessions.reverse()  # newest first
        return sessions

    def _read_all_rows(self) -> list:
        """Read all data rows from the history CSV.

        Returns:
            list[dict]: All rows in chronological order.
        """
        rows = []
        with open(self.history_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(row)
        return rows

    def get_trend_data(self) -> dict:
        """Return metric lists for all sessions in chronological order.

        Used by the trend chart in dashboard.py.

        Returns:
            dict: {metric: [float]} for Anxiety, Depression, etc.
        """
        rows = self._read_all_rows()
        return {
            'Anxiety': [float(r['anxiety']) for r in rows],
            'Depression': [float(r['depression']) for r in rows],
            'Insomnia': [float(r['insomnia']) for r in rows],
            'OCD': [float(r['ocd']) for r in rows],
        }

    def get_session_count(self) -> int:
        """Return total number of stored sessions.

        Returns:
            int: Number of session rows in the CSV.
        """
        return len(self._read_all_rows())

    def delete_session(self, session_id: int) -> None:
        """Delete a single session by ID.

        Rewrites the CSV without the matching row.

        Args:
            session_id: ID of the session to delete.
        """
        rows = self._read_all_rows()
        filtered = [r for r in rows if str(r['id']) != str(session_id)]
        self._rewrite_history(filtered)

    def clear_all(self) -> None:
        """Delete all session data. Rewrites CSV with header only."""
        self._rewrite_history([])

    def _rewrite_history(self, rows: list) -> None:
        """Rewrite the entire history CSV with the given rows.

        Args:
            rows: List of row dicts to write.
        """
        with open(self.history_path, 'w', newline='',
                  encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=self.HISTORY_FIELDS)
            writer.writeheader()
            writer.writerows(rows)

    # --- Settings management ---

    def get_setting(self, key: str) -> str:
        """Get a setting value by key.

        Args:
            key: Setting key name.

        Returns:
            str: Setting value, or empty string if not found.
        """
        with open(self.settings_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row['key'] == key:
                    return row['value']
        return ''

    def set_setting(self, key: str, value: str) -> None:
        """Set a setting value. Updates existing key or appends new.

        Args:
            key: Setting key name.
            value: Setting value to store.
        """
        settings = self._read_all_settings()
        settings[key] = value
        self._rewrite_settings(settings)

    def _read_all_settings(self) -> dict:
        """Read all settings as a dict."""
        settings = {}
        with open(self.settings_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                settings[row['key']] = row['value']
        return settings

    def _rewrite_settings(self, settings: dict) -> None:
        """Rewrite the settings CSV with all key-value pairs."""
        with open(self.settings_path, 'w', newline='',
                  encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['key', 'value'])
            writer.writeheader()
            for key, value in settings.items():
                writer.writerow({'key': key, 'value': value})
