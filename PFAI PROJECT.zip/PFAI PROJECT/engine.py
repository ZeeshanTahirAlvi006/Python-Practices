"""
engine.py — MoodMap Analytical Engine

Contains the analytical engine classes and the core prediction function:
    - AgeGroupAnalyzer: Segments dataset into age brackets
    - CorrelationEngine: Pearson correlations (Hours + BPM vs metrics)
    - predict_mental_health(): Core prediction pipeline (Steps 1-7)

SRS Coverage: FR-13, FR-14, FR-22, FR-31
"""

import numpy as np
import pandas as pd


class AgeGroupAnalyzer:
    """Segments the dataset into predefined age brackets.

    Identifies which bracket the user belongs to and computes
    mental health statistics for that bracket.

    Attributes:
        df (pd.DataFrame): Full cleaned dataset.
        brackets (list[tuple]): Age group definitions (min, max, label).
        bracket_stats (dict): Pre-computed stats for all brackets.
    """

    METRICS = ['Anxiety', 'Depression', 'Insomnia', 'OCD']
    BRACKET_DEFS = [
        (10, 17, "10-17"),
        (18, 24, "18-24"),
        (25, 34, "25-34"),
        (35, 49, "35-49"),
        (50, 64, "50-64"),
        (65, 89, "65-89"),
    ]

    def __init__(self, df: pd.DataFrame) -> None:
        """Initialize with dataset and define age brackets."""
        self.df = df
        self.brackets = self.BRACKET_DEFS
        self.bracket_stats = self._compute_all_brackets()

    def assign_bracket(self, age: int) -> str:
        """Return age bracket label for the given age.

        Args:
            age: User's age (10-89).

        Returns:
            str: Bracket label, e.g. '18-24'.
        """
        for min_age, max_age, label in self.brackets:
            if min_age <= age <= max_age:
                return label
        return "18-24"  # fallback

    def get_bracket_stats(self, age: int) -> dict:
        """Return mean mental health scores for user's age bracket.

        Args:
            age: User's age.

        Returns:
            dict: Bracket label, mean metrics, and bracket size.
        """
        label = self.assign_bracket(age)
        stats = self.bracket_stats.get(label, {}).copy()
        stats['bracket'] = label
        return stats

    def get_bracket_boundaries(self, age: int) -> tuple:
        """Return (min_age, max_age) for the user's bracket.

        Args:
            age: User's age.

        Returns:
            tuple: (min_age, max_age).
        """
        for min_age, max_age, _ in self.brackets:
            if min_age <= age <= max_age:
                return min_age, max_age
        return 18, 24  # fallback

    def _compute_all_brackets(self) -> dict:
        """Pre-compute stats for all age brackets.

        Returns:
            dict: {label: {metric: mean_value, 'bracket_size': int}}.
        """
        all_stats = {}
        for min_age, max_age, label in self.brackets:
            bracket_df = self._filter_bracket(min_age, max_age)
            all_stats[label] = self._compute_bracket_means(bracket_df)
        return all_stats

    def _filter_bracket(self, min_age: int, max_age: int) -> pd.DataFrame:
        """Filter dataset to rows within the specified age range."""
        return self.df[
            (self.df['Age'] >= min_age) & (self.df['Age'] <= max_age)
        ]

    def _compute_bracket_means(self, bracket_df: pd.DataFrame) -> dict:
        """Compute mean mental health scores for a bracket DataFrame."""
        stats = {}
        for metric in self.METRICS:
            if len(bracket_df) > 0:
                stats[metric] = float(np.mean(bracket_df[metric].values))
            else:
                stats[metric] = 0.0
        stats['bracket_size'] = len(bracket_df)
        return stats


class CorrelationEngine:
    """Computes Pearson correlations between listening attributes and mental health.

    Handles both Hours per day and BPM correlations.

    Attributes:
        df (pd.DataFrame): Full cleaned dataset.
        correlations (dict): Hours↔metrics correlations.
        bpm_correlations (dict): BPM↔metrics correlations.
    """

    METRICS = ['Anxiety', 'Depression', 'Insomnia', 'OCD']

    def __init__(self, df: pd.DataFrame) -> None:
        """Initialize with dataset and compute all correlations."""
        self.df = df
        self.hours_column = "Hours per day"
        self.bpm_column = "BPM"
        self.correlations = self._compute_hours_correlations()
        self.bpm_correlations = self._compute_bpm_correlations()

    def _compute_hours_correlations(self) -> dict:
        """Compute Pearson r between Hours/day and each metric.

        Formula: r_xy = np.corrcoef(x, y)[0, 1]

        Returns:
            dict: {metric: r_value} for hours correlations.
        """
        return self._compute_correlations_for_column(self.hours_column)

    def _compute_bpm_correlations(self) -> dict:
        """Compute Pearson r between BPM and each metric.

        Returns:
            dict: {metric: r_value} for BPM correlations.
        """
        return self._compute_correlations_for_column(self.bpm_column)

    def _compute_correlations_for_column(self, column: str) -> dict:
        """Compute Pearson r between a given column and each metric.

        Guards against zero-variance columns: if either the predictor
        or a metric has zero standard deviation, r is set to 0.0 to
        avoid NaN propagation from np.corrcoef.

        Args:
            column: Column name to correlate against metrics.

        Returns:
            dict: {metric: float} correlation values.
        """
        results = {}
        col_values = self.df[column].values
        # FIX 3: Guard against zero-variance predictor column
        if np.std(col_values) == 0:
            return {m: 0.0 for m in self.METRICS}

        for metric in self.METRICS:
            metric_values = self.df[metric].values
            # FIX 3: Guard against zero-variance metric column
            if np.std(metric_values) == 0:
                results[metric] = 0.0
                continue
            r = np.corrcoef(col_values, metric_values)[0, 1]
            results[metric] = round(float(r), 4)
        return results

    def get_strongest(self) -> tuple:
        """Return the metric most strongly correlated with listening hours.

        Formula: strongest = argmax_m |r_m|

        Returns:
            tuple: (metric_name, r_value).
        """
        return self._find_strongest(self.correlations)

    def get_strongest_bpm(self) -> tuple:
        """Return the metric most strongly correlated with BPM.

        Returns:
            tuple: (metric_name, r_value).
        """
        return self._find_strongest(self.bpm_correlations)

    def _find_strongest(self, corr_dict: dict) -> tuple:
        """Find the metric with highest absolute correlation.

        Args:
            corr_dict: {metric: r_value} dict.

        Returns:
            tuple: (metric_name, r_value).
        """
        strongest = max(corr_dict, key=lambda m: abs(corr_dict[m]))
        return strongest, corr_dict[strongest]


# ---------------------------------------------------------------------------
# Core prediction function (module-level, not a class method)
# ---------------------------------------------------------------------------

def predict_mental_health(respondent, df: pd.DataFrame,
                          correlation_engine: CorrelationEngine = None) -> dict:
    """Predict user's mental health scores using cohort statistics.

    Uses weighted cohort averages (genre × age intersection) with
    correlation-based adjustment for listening intensity, then applies
    dampened behavioural modifier deltas for while_working,
    instrumentalist, and streaming_service inputs.

    All 6 questionnaire fields contribute to the final prediction.
    No machine learning library needed — pure NumPy statistics.

    Args:
        respondent: Respondent object with user's questionnaire answers.
        df: Full cleaned DataFrame.
        correlation_engine: Optional pre-built CorrelationEngine. If
            provided, its cached hours correlations are reused instead
            of recomputing them (avoids redundant work and keeps
            correlation logic in one place). A new engine is created
            internally if not supplied.

    Returns:
        dict: {'Anxiety': float, 'Depression': float,
               'Insomnia': float, 'OCD': float}
    """
    metrics = ['Anxiety', 'Depression', 'Insomnia', 'OCD']

    # FIX 1: Build or reuse CorrelationEngine so hours correlations are
    # never recomputed inside the loop — single source of truth.
    if correlation_engine is None:
        correlation_engine = CorrelationEngine(df)

    # Steps 1-3: Filter cohorts
    genre_cohort, age_cohort, intersection = _filter_cohorts(
        respondent, df
    )

    # Step 4: Compute weighted base scores
    predicted = _compute_weighted_base(
        metrics, genre_cohort, age_cohort, intersection, df
    )

    # Step 5: Apply hours-per-day adjustment
    predicted = _apply_hours_adjustment(
        predicted, metrics, respondent, genre_cohort,
        correlation_engine.correlations
    )

    # Step 6: Apply behavioural modifier deltas
    predicted = _apply_behavioural_modifiers(
        predicted, metrics, respondent, df
    )

    # Step 7: Clamp to [0, 10]
    predicted = _clamp_scores(predicted, metrics)

    return predicted


def _filter_cohorts(respondent, df: pd.DataFrame) -> tuple:
    """Steps 1-3: Filter genre, age, and intersection cohorts.

    Returns:
        tuple: (genre_cohort, age_cohort, intersection) DataFrames.
    """
    # Step 1: Genre cohort
    genre_cohort = df[df['Fav genre'] == respondent.fav_genre]

    # Step 2: Age bracket cohort
    age_analyzer = AgeGroupAnalyzer(df)
    bracket_min, bracket_max = age_analyzer.get_bracket_boundaries(
        respondent.age
    )
    age_cohort = df[
        (df['Age'] >= bracket_min) & (df['Age'] <= bracket_max)
    ]

    # Step 3: Intersection
    intersection = genre_cohort[
        (genre_cohort['Age'] >= bracket_min) &
        (genre_cohort['Age'] <= bracket_max)
    ]

    return genre_cohort, age_cohort, intersection


def _compute_weighted_base(metrics: list, genre_cohort: pd.DataFrame,
                           age_cohort: pd.DataFrame,
                           intersection: pd.DataFrame,
                           df: pd.DataFrame) -> dict:
    """Step 4: Compute weighted base score for each metric.

    Uses 60/25/15 weighting if intersection ≥ 10,
    otherwise falls back to 50/50 genre+age weighting.

    FIX 2: Empty genre_cohort is guarded — falls back to the global
    dataset mean rather than propagating NaN silently.

    Args:
        df: Full dataset used as global fallback when cohorts are empty.

    Returns:
        dict: {metric: base_score}.
    """
    predicted = {}
    use_intersection = len(intersection) >= 10

    for m in metrics:
        # FIX 2: Fall back to global mean if genre cohort is empty
        if len(genre_cohort) > 0:
            genre_mean = np.mean(genre_cohort[m].values)
        else:
            genre_mean = np.mean(df[m].values)

        age_mean = np.mean(age_cohort[m].values)  # age_cohort always non-empty

        if use_intersection:
            intersection_mean = np.mean(intersection[m].values)
            base = (0.60 * intersection_mean +
                    0.25 * genre_mean +
                    0.15 * age_mean)
        else:
            base = (0.50 * genre_mean +
                    0.50 * age_mean)

        predicted[m] = base

    return predicted


def _apply_hours_adjustment(predicted: dict, metrics: list,
                            respondent, genre_cohort: pd.DataFrame,
                            hours_correlations: dict) -> dict:
    """Step 5: Adjust scores based on hours-per-day deviation.

    Formula: adjustment_m = (user_hours - genre_mean_hours) × r_m

    FIX 1: Accepts pre-computed hours_correlations dict from
    CorrelationEngine instead of recomputing np.corrcoef inside the
    loop on every call.

    Args:
        hours_correlations: Cached {metric: r_value} from CorrelationEngine.

    Returns:
        dict: Updated predicted scores.
    """
    # FIX 2: Guard against empty genre_cohort for hours mean
    if len(genre_cohort) > 0:
        genre_mean_hours = np.mean(genre_cohort['Hours per day'].values)
    else:
        genre_mean_hours = respondent.hours_per_day  # zero deviation fallback

    hours_dev = respondent.hours_per_day - genre_mean_hours

    for m in metrics:
        r = hours_correlations.get(m, 0.0)
        predicted[m] += hours_dev * r

    return predicted


def _apply_behavioural_modifiers(predicted: dict, metrics: list,
                                 respondent,
                                 df: pd.DataFrame) -> dict:
    """Step 6: Apply dampened behavioural modifier deltas.

    For each of while_working, instrumentalist, streaming_service:
    delta = ALPHA × (cohort_mean - global_mean)

    Only applied if cohort size ≥ MIN_COHORT.

    Returns:
        dict: Updated predicted scores.
    """
    ALPHA = 0.15
    MIN_COHORT = 5

    behavioural_attrs = {
        'While working': respondent.while_working,
        'Instrumentalist': respondent.instrumentalist,
        'Primary streaming service': respondent.streaming_service,
    }

    for col, val in behavioural_attrs.items():
        cohort_b = df[df[col] == val]
        if len(cohort_b) >= MIN_COHORT:
            predicted = _apply_single_modifier(
                predicted, metrics, cohort_b, df, ALPHA
            )

    return predicted


def _apply_single_modifier(predicted: dict, metrics: list,
                           cohort_b: pd.DataFrame,
                           df: pd.DataFrame, alpha: float) -> dict:
    """Apply a single behavioural modifier delta.

    Args:
        cohort_b: Subset of df matching the user's attribute value.
        alpha: Dampening factor.

    Returns:
        dict: Updated predicted scores.
    """
    for m in metrics:
        global_mean = np.mean(df[m].values)
        cohort_mean = np.mean(cohort_b[m].values)
        predicted[m] += alpha * (cohort_mean - global_mean)
    return predicted


def _clamp_scores(predicted: dict, metrics: list) -> dict:
    """Step 7: Clamp all scores to [0.0, 10.0].

    Returns:
        dict: Clamped predicted scores.
    """
    for m in metrics:
        predicted[m] = float(np.clip(predicted[m], 0.0, 10.0))
    return predicted