"""
data_loader.py — MoodMap Data Loading & Cleaning Module

Handles CSV I/O, data cleaning, validation, and provides
clean data to the rest of the application.

SRS Coverage: FR-01, FR-02, FR-03, FR-04, FR-05, FR-09
"""

import pandas as pd


class DataLoader:
    """Loads, cleans, and validates the MxMH survey dataset."""

    def __init__(self, filepath: str) -> None:
        """Initialize DataLoader with path to MxMH CSV dataset."""
        self.filepath = filepath
        self.df = None
        self.is_loaded = False

    def load(self) -> pd.DataFrame:
        """Load mxmh_survey_results.csv into a pandas DataFrame.

        Returns:
            pd.DataFrame: Raw, uncleaned dataset.

        Raises:
            FileNotFoundError: If the CSV file is not found at self.filepath.
        """
        try:
            self.df = pd.read_csv(self.filepath)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"Dataset not found at '{self.filepath}'. "
                "Please ensure 'mxmh_survey_results.csv' is in the project directory."
            )
        return self.df

    def clean(self) -> pd.DataFrame:
        """Clean dataset: strip columns, drop null mental health rows, impute BPM.

        Steps:
            1. Strip whitespace from column names
            2. Drop rows with null Anxiety, Depression, Insomnia, or OCD
            3. Fill missing BPM values with column median

        Returns:
            pd.DataFrame: Cleaned dataset.
        """
        self._strip_column_names()
        self._drop_null_mental_health_rows()
        self._impute_bpm_median()
        return self.df

    def _strip_column_names(self) -> None:
        """Remove leading/trailing whitespace from all column headers."""
        self.df.columns = self.df.columns.str.strip()

    def _drop_null_mental_health_rows(self) -> None:
        """Drop any row where a mental health score is NaN."""
        mental_health_cols = ['Anxiety', 'Depression', 'Insomnia', 'OCD']
        self.df.dropna(subset=mental_health_cols, inplace=True)

    def _impute_bpm_median(self) -> None:
        """Fill missing BPM values with the column median."""
        median_bpm = self.df['BPM'].median()
        self.df['BPM'] = self.df['BPM'].fillna(median_bpm)

    def validate(self) -> bool:
        """Validate cleaned dataset has minimum 500 rows.

        Returns:
            True if the dataset passes validation.

        Raises:
            ValueError: If fewer than 500 rows remain after cleaning.
        """
        row_count = len(self.df)
        if row_count < 500:
            raise ValueError(
                f"Dataset has only {row_count} rows after cleaning. "
                "Minimum 500 rows required for reliable analysis."
            )
        return True

    def get_data(self) -> pd.DataFrame:
        """Load, clean, and validate dataset. Returns clean DataFrame.

        This is the only method external code should call.

        Returns:
            pd.DataFrame: Fully cleaned and validated dataset.
        """
        self.load()
        self.clean()
        self.validate()
        self.is_loaded = True
        return self.df

    def get_unique_genres(self) -> list:
        """Return sorted list of unique genres from the dataset.

        Returns:
            list[str]: Sorted genre names (e.g., ['Classical', 'Country', ...]).
        """
        return sorted(self.df['Fav genre'].dropna().unique().tolist())

    def get_unique_services(self) -> list:
        """Return sorted list of unique streaming services from the dataset.

        Returns:
            list[str]: Sorted service names (e.g., ['Apple Music', 'Spotify', ...]).
        """
        return sorted(
            self.df['Primary streaming service'].dropna().unique().tolist()
        )
