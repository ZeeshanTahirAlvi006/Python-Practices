"""
pdf_export.py — MoodMap PDF Report Generator

Generates a multi-page PDF report containing scores, cohort comparisons,
recommendations, and embedded matplotlib charts.
Uses fpdf2 with Segoe UI font styling (fallback to Helvetica if unavailable).

SRS Coverage: FR-28
"""

import os
from datetime import datetime
from fpdf import FPDF


class PDFExporter:
    """Generate professional PDF report from MoodMap analysis results."""

    def __init__(self, report: dict, chart_paths: list, recommendations: list,
                 genre_rec: dict, output_dir: str = "output") -> None:
        """Initialize exporter with analysis outputs and file configuration."""
        self.report = report
        self.chart_paths = chart_paths
        self.recommendations = recommendations
        self.genre_rec = genre_rec
        self.output_dir = output_dir
        self.font_family = "Helvetica"

    def generate(self) -> str:
        """Orchestrate PDF compilation and save output file.

        Returns:
            str: Absolute or relative path to the generated PDF.
        """
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        self._setup_fonts(pdf)

        self._add_cover_page(pdf)
        self._add_scores_page(pdf)
        self._add_recommendations_page(pdf)
        self._add_charts_pages(pdf)
        self._add_about_page(pdf)

        os.makedirs(self.output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"moodmap_report_{timestamp}.pdf"
        out_path = os.path.join(self.output_dir, filename)
        pdf.output(out_path)
        return out_path

    def _setup_fonts(self, pdf: FPDF) -> None:
        """Register Segoe UI font or fallback to Helvetica if missing."""
        segoe_path = r"C:\Windows\Fonts\segoeui.ttf"
        segoe_bold_path = r"C:\Windows\Fonts\segoeuib.ttf"
        segoe_italic_path = r"C:\Windows\Fonts\segoeuii.ttf"

        if os.path.exists(segoe_path):
            try:
                pdf.add_font("SegoeUI", "", segoe_path)
                self.font_family = "SegoeUI"
                if os.path.exists(segoe_bold_path):
                    pdf.add_font("SegoeUI", "B", segoe_bold_path)
                if os.path.exists(segoe_italic_path):
                    pdf.add_font("SegoeUI", "I", segoe_italic_path)
            except Exception:
                self.font_family = "Helvetica"
        else:
            self.font_family = "Helvetica"

    def _add_cover_page(self, pdf: FPDF) -> None:
        """Generate cover page with branding and metadata."""
        pdf.add_page()
        # Theme accent header bar
        pdf.set_fill_color(29, 185, 84)  # Spotify green
        pdf.rect(0, 0, 210, 20, "F")

        pdf.ln(30)
        pdf.set_font(self.font_family, "B", 28)
        pdf.set_text_color(29, 185, 84)
        pdf.cell(0, 15, "MoodMap Report", ln=True, align="C")

        pdf.set_font(self.font_family, "", 16)
        pdf.set_text_color(80, 80, 80)
        pdf.cell(0, 10, "Music & Mental Health Profiler", ln=True, align="C")

        pdf.ln(20)
        self._draw_user_summary_box(pdf)

        pdf.ln(40)
        pdf.set_font(self.font_family, "I", 10)
        pdf.set_text_color(120, 120, 120)
        gen_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        pdf.cell(0, 10, f"Report generated on: {gen_time}", ln=True, align="C")
        pdf.cell(0, 10, "UMT Course Project 2026", ln=True, align="C")

    def _draw_user_summary_box(self, pdf: FPDF) -> None:
        """Draw details box containing respondent user details."""
        pdf.set_fill_color(245, 245, 245)
        pdf.rect(20, 80, 170, 75, "F")
        pdf.set_xy(25, 85)

        pdf.set_font(self.font_family, "B", 14)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 8, "Respondent Profile Summary", ln=True)
        pdf.line(25, 94, 185, 94)
        pdf.ln(4)

        pdf.set_font(self.font_family, "", 12)
        summary = self.report.get("user_summary", "")
        for line in summary.split("\n"):
            pdf.set_x(25)
            pdf.cell(0, 7, line, ln=True)

    def _add_scores_page(self, pdf: FPDF) -> None:
        """Create predicted scores list and cohort comparison page."""
        pdf.add_page()
        pdf.set_font(self.font_family, "B", 18)
        pdf.set_text_color(29, 185, 84)
        pdf.cell(0, 12, "Mental Health Score Predictions", ln=True)
        pdf.line(10, 22, 200, 22)
        pdf.ln(6)

        self._draw_score_cards(pdf)
        self._draw_comparison_table(pdf)
        self._draw_confidence_indicators(pdf)

    def _draw_score_cards(self, pdf: FPDF) -> None:
        """Render 4 predicted score cards side-by-side or stacked."""
        scores = self.report.get("predicted_scores", {})
        severities = self.report.get("severity_labels", {})
        percentiles = self.report.get("percentiles", {})

        pdf.set_font(self.font_family, "B", 11)
        pdf.set_text_color(0, 0, 0)

        # Draw a row of cells for each metric
        for metric, score in scores.items():
            sev = severities.get(metric, "Low")
            pct = percentiles.get(metric, 0.0)

            pdf.set_font(self.font_family, "B", 12)
            pdf.cell(45, 8, f"{metric}:", ln=False)

            # Set text color based on severity
            self._set_severity_text_color(pdf, sev)
            pdf.set_font(self.font_family, "B", 12)
            pdf.cell(20, 8, f"{score:.1f}", ln=False)
            pdf.cell(35, 8, f"({sev.upper()})", ln=False)

            pdf.set_text_color(100, 100, 100)
            pdf.set_font(self.font_family, "", 11)
            pdf.cell(60, 8, f"Percentile: {pct:.0f}th", ln=True)

        pdf.ln(8)

    def _set_severity_text_color(self, pdf: FPDF, severity: str) -> None:
        """Set PDF print color based on severity string."""
        if severity == "High":
            pdf.set_text_color(231, 76, 60)  # Red
        elif severity == "Moderate":
            pdf.set_text_color(243, 156, 18)  # Orange
        else:
            pdf.set_text_color(29, 185, 84)  # Green

    def _draw_comparison_table(self, pdf: FPDF) -> None:
        """Draw table matching cohort comparison data."""
        pdf.set_font(self.font_family, "B", 14)
        pdf.set_text_color(29, 185, 84)
        pdf.cell(0, 10, "Genre Cohort Comparison Table", ln=True)
        pdf.ln(2)

        # Headers
        pdf.set_font(self.font_family, "B", 11)
        pdf.set_text_color(255, 255, 255)
        pdf.set_fill_color(50, 50, 50)
        pdf.cell(50, 8, "Metric", border=1, fill=True)
        pdf.cell(40, 8, "Your Score", border=1, fill=True)
        pdf.cell(50, 8, "Genre Avg", border=1, fill=True)
        pdf.cell(40, 8, "Difference", border=1, fill=True, ln=True)

        # Content
        comparison = self.report.get("cohort_comparison", {})
        pdf.set_font(self.font_family, "", 10)
        pdf.set_text_color(0, 0, 0)
        for metric, data in comparison.items():
            user = data.get("user", 0.0)
            avg = data.get("cohort_avg", 0.0)
            diff = data.get("difference", 0.0)

            pdf.cell(50, 8, metric, border=1)
            pdf.cell(40, 8, f"{user:.2f}", border=1)
            pdf.cell(50, 8, f"{avg:.2f}", border=1)

            # Highlight differences
            diff_arrow = "+" if diff > 0 else ""
            if diff > 0:
                pdf.set_text_color(231, 76, 60)
            elif diff < 0:
                pdf.set_text_color(29, 185, 84)
            pdf.cell(40, 8, f"{diff_arrow}{diff:.2f}", border=1, ln=True)
            pdf.set_text_color(0, 0, 0)

        pdf.ln(8)

    def _draw_confidence_indicators(self, pdf: FPDF) -> None:
        """Render cohort size confidence indications."""
        pdf.set_font(self.font_family, "B", 14)
        pdf.set_text_color(29, 185, 84)
        pdf.cell(0, 10, "Statistical Confidence & Cohort", ln=True)
        pdf.ln(2)

        cohort_size = self.report.get("genre_cohort_size", 0)
        pdf.set_font(self.font_family, "", 11)
        pdf.set_text_color(50, 50, 50)

        confidence = "Low"
        if cohort_size >= 30:
            confidence = "High (Optimal)"
        elif cohort_size >= 10:
            confidence = "Medium (Sufficient)"

        pdf.cell(0, 6, f"Genre Cohort Size: {cohort_size} respondents", ln=True)
        pdf.cell(0, 6, f"Confidence Level: {confidence}", ln=True)

    def _add_recommendations_page(self, pdf: FPDF) -> None:
        """Render recommendations page."""
        pdf.add_page()
        pdf.set_font(self.font_family, "B", 18)
        pdf.set_text_color(29, 185, 84)
        pdf.cell(0, 12, "Actionable Listening Recommendations", ln=True)
        pdf.line(10, 22, 200, 22)
        pdf.ln(6)

        self._draw_recs_section(pdf)
        self._draw_insights_section(pdf)

    def _draw_recs_section(self, pdf: FPDF) -> None:
        """Draw list of recommended actions and genre swap."""
        pdf.set_font(self.font_family, "B", 14)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 8, "Behaviour Modifications:", ln=True)
        pdf.ln(2)

        pdf.set_font(self.font_family, "", 11)
        if self.recommendations:
            for rec in self.recommendations:
                pdf.multi_cell(0, 6, f"•  {rec}")
                pdf.ln(2)
        else:
            pdf.cell(0, 6, "•  Your patterns fall in default ranges.", ln=True)
            pdf.ln(2)

        # Genre Swap Recommendation
        g_rec = self.genre_rec
        if g_rec and g_rec.get("delta", 0.0) > 0.2:
            pdf.ln(4)
            pdf.set_font(self.font_family, "B", 13)
            pdf.cell(0, 8, "Alternative Genre Suggestion:", ln=True)
            pdf.set_font(self.font_family, "", 11)
            rec_genre = g_rec.get("recommended_genre")
            user_comp = g_rec.get("user_composite", 0.0)
            rec_comp = g_rec.get("recommended_composite", 0.0)
            delta = g_rec.get("delta", 0.0)

            msg = (
                f"Based on dataset trends, transitioning to listening to {rec_genre} "
                f"may be beneficial. Listeners of {rec_genre} report lower composite "
                f"scores of {rec_comp:.1f} compared to your favorite genre average "
                f"of {user_comp:.1f} (a difference of {delta:.1f} points)."
            )
            pdf.multi_cell(0, 6, msg)
        pdf.ln(6)

    def _draw_insights_section(self, pdf: FPDF) -> None:
        """Draw hours and BPM correlation insights."""
        pdf.set_font(self.font_family, "B", 14)
        pdf.cell(0, 8, "Correlation & BPM Insights:", ln=True)
        pdf.ln(2)

        pdf.set_font(self.font_family, "", 11)
        strongest_hrs = self.report.get("strongest_correlation")
        if strongest_hrs:
            msg = (
                f"Across the full dataset, listening hours is most strongly correlated "
                f"with {strongest_hrs[0]} (r = {strongest_hrs[1]:.3f})."
            )
            pdf.multi_cell(0, 6, f"•  Hours Insight: {msg}")
            pdf.ln(2)

        strongest_bpm = self.report.get("strongest_bpm_correlation")
        if strongest_bpm:
            msg = (
                f"Similarly, music tempo (BPM) exhibits its strongest correlation "
                f"with {strongest_bpm[0]} (r = {strongest_bpm[1]:.3f})."
            )
            pdf.multi_cell(0, 6, f"•  BPM Insight: {msg}")

    def _add_charts_pages(self, pdf: FPDF) -> None:
        """Append matplotlib visualization pages to PDF."""
        for path in self.chart_paths:
            if not os.path.exists(path):
                continue
            pdf.add_page()
            pdf.set_font(self.font_family, "B", 16)
            pdf.set_text_color(29, 185, 84)

            # Format chart title based on file name
            basename = os.path.basename(path)
            title = self._get_chart_title_from_filename(basename)

            pdf.cell(0, 10, title, ln=True)
            pdf.line(10, 20, 200, 20)
            pdf.ln(10)

            # Center image on page
            pdf.image(path, x=15, y=30, w=180)

    def _get_chart_title_from_filename(self, filename: str) -> str:
        """Return human-readable title from chart filename."""
        titles = {
            "genre_bar.png": "Mental Health Scores by Genre",
            "age_line.png": "Scores & Listening Hours by Age Group",
            "anxiety_hist.png": "Anxiety Score Distribution Histogram",
            "scatter_plot.png": "Listening Hours vs Depression Correlation",
            "correlation_heatmap.png": "Attribute Correlation Heatmap Matrix",
        }
        return titles.get(filename, "Visual Insight Analysis")

    def _add_about_page(self, pdf: FPDF) -> None:
        """Generate methodology and clinical disclaimer page."""
        pdf.add_page()
        pdf.set_font(self.font_family, "B", 16)
        pdf.set_text_color(29, 185, 84)
        pdf.cell(0, 12, "About this Profile Report", ln=True)
        pdf.line(10, 22, 200, 22)
        pdf.ln(8)

        pdf.set_font(self.font_family, "B", 12)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 8, "Statistical Methodology", ln=True)
        pdf.set_font(self.font_family, "", 10)
        pdf.set_text_color(50, 50, 50)

        methodology_text = (
            "MoodMap predictions are based on statistical inference computed over the "
            "MxMH Kaggle dataset containing 736 survey responses. Cohort filtering locates "
            "individuals who share similar demographics (Age Bracket) and music habits "
            "(Favorite Genre). The base prediction is computed as a weighted average "
            "composed of 60% intersection cohort, 25% genre average, and 15% age bracket "
            "average. This base score is dynamically adjusted using Pearson correlation coefficients "
            "for listening hours and specific behavioural modifiers (such as listening while "
            "working, instrumentalist status, and streaming services)."
        )
        pdf.multi_cell(0, 6, methodology_text)
        pdf.ln(6)

        pdf.set_font(self.font_family, "B", 12)
        pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 8, "Clinical Disclaimer", ln=True)
        pdf.set_font(self.font_family, "I", 10)
        pdf.set_text_color(100, 100, 100)

        disclaimer_text = (
            "The predictions, scores, and recommendations provided in this report are for "
            "educational and statistical comparison purposes only. MoodMap does not provide "
            "clinical diagnoses, medical advice, or psychiatric treatment. If you or someone "
            "you know is experiencing distress or mental health struggles, please consult a "
            "licensed mental health professional or qualified healthcare practitioner."
        )
        pdf.multi_cell(0, 6, disclaimer_text)
