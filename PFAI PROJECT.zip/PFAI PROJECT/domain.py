"""
domain.py — MoodMap Domain Model Classes

Contains the three domain model classes that represent the user
profile and mental health data:
    - Respondent: Stores all user-provided questionnaire inputs
    - GenreProfile: Extends Respondent with genre cohort analysis
    - MentalHealthMetric: Encapsulates a single mental health dimension

SRS Coverage: FR-11, FR-12
"""

import numpy as np
import pandas as pd


class Respondent:
    """Stores all user-provided inputs collected during the questionnaire.

    This is the base data class representing a single user's profile.
    GenreProfile inherits from this class to satisfy OOP requirements.

    Attributes:
        age (int): User's age, 10-89.
        fav_genre (str): User's favorite music genre.
        hours_per_day (float): Hours spent listening to music daily, 0-24.
        while_working (str): Whether user listens while working ('Yes'/'No').
        instrumentalist (str): Whether user plays an instrument ('Yes'/'No').
        streaming_service (str): User's primary streaming platform.
    """

    def __init__(self, age: int, fav_genre: str, hours_per_day: float,
                 while_working: str, instrumentalist: str,
                 streaming_service: str) -> None:
        """Initialize Respondent with all questionnaire inputs."""
        self.age = age
        self.fav_genre = fav_genre
        self.hours_per_day = hours_per_day
        self.while_working = while_working
        self.instrumentalist = instrumentalist
        self.streaming_service = streaming_service

    def to_dict(self) -> dict:
        """Return dict of all user attributes.

        Returns:
            dict: Keys match dataset column names for easy comparison.
        """
        return {
            'Age': self.age,
            'Fav genre': self.fav_genre,
            'Hours per day': self.hours_per_day,
            'While working': self.while_working,
            'Instrumentalist': self.instrumentalist,
            'Primary streaming service': self.streaming_service
        }

    def display_summary(self) -> str:
        """Return formatted string summary of user profile.

        Returns:
            str: Multi-line human-readable summary.
        """
        lines = [
            f"Age: {self.age}",
            f"Favorite Genre: {self.fav_genre}",
            f"Hours/Day: {self.hours_per_day}",
            f"Listens While Working: {self.while_working}",
            f"Instrumentalist: {self.instrumentalist}",
            f"Streaming Service: {self.streaming_service}",
        ]
        return "\n".join(lines)


class GenreProfile(Respondent):
    """Extends Respondent with genre cohort analysis.

    Filters the dataset by the user's favorite genre and computes
    cohort-level mental health statistics. Inherits from Respondent
    to satisfy the OOP inheritance requirement.

    Attributes:
        df (pd.DataFrame): Full cleaned dataset reference.
        cohort (pd.DataFrame): Subset matching user's fav_genre.
        cohort_size (int): Number of respondents in the genre cohort.
    """

    METRICS = ['Anxiety', 'Depression', 'Insomnia', 'OCD']

    def __init__(self, respondent: Respondent, df: pd.DataFrame) -> None:
        """Initialize GenreProfile by inheriting respondent data and filtering genre cohort."""
        super().__init__(
            age=respondent.age,
            fav_genre=respondent.fav_genre,
            hours_per_day=respondent.hours_per_day,
            while_working=respondent.while_working,
            instrumentalist=respondent.instrumentalist,
            streaming_service=respondent.streaming_service
        )
        self.df = df
        self.cohort = df[df['Fav genre'] == self.fav_genre]
        self.cohort_size = len(self.cohort)

    def get_cohort_stats(self) -> dict:
        """Compute mean mental health scores for user's genre cohort.

        Formula: cohort_mean_m = (1/N_genre) * sum(x_i_m)

        Returns:
            dict: Mean scores for each metric plus cohort_size.
        """
        stats = self.cohort[self.METRICS].mean().to_dict()
        stats['cohort_size'] = self.cohort_size
        return stats

    def compare_to_cohort(self, predicted_scores: dict) -> dict:
        """Compare user's predicted scores to genre cohort averages.

        Formula: delta_m = user_score_m - cohort_mean_m

        Args:
            predicted_scores: Dict of {metric: predicted_value}.

        Returns:
            dict: Per-metric comparison with user, cohort_avg, and difference.
        """
        cohort_stats = self.get_cohort_stats()
        comparison = {}
        for metric in self.METRICS:
            user_val = predicted_scores[metric]
            cohort_avg = cohort_stats[metric]
            comparison[metric] = {
                'user': round(user_val, 2),
                'cohort_avg': round(cohort_avg, 2),
                'difference': round(user_val - cohort_avg, 2)
            }
        return comparison


class MentalHealthMetric:
    """Encapsulates a single mental health dimension.

    Holds the user's predicted score, computes their percentile rank
    against the full dataset, and assigns a severity label.
    Four instances are created — one per metric.

    Attributes:
        name (str): Metric name ('Anxiety', 'Depression', etc.).
        score (float): User's predicted score (0.0-10.0).
        dataset_values (np.ndarray): All values for this metric from dataset.
        percentile (float): User's percentile rank (0-100).
        severity (str): 'Low', 'Moderate', or 'High'.
        dataset_mean (float): Mean across full dataset.
        dataset_std (float): Std dev across full dataset.
    """

    # Severity thresholds and their associated colors
    SEVERITY_THRESHOLDS = [
        (3.0, "Low", "#1DB954"),
        (6.0, "Moderate", "#F39C12"),
        (10.0, "High", "#E74C3C"),
    ]

    def __init__(self, name: str, score: float,
                 dataset_values: np.ndarray) -> None:
        """Initialize a mental health metric with score and dataset reference."""
        self.name = name
        self.score = score
        self.dataset_values = np.array(dataset_values)
        self.dataset_mean = float(np.mean(self.dataset_values))
        self.dataset_std = float(np.std(self.dataset_values))
        self.percentile = self.compute_percentile()
        self.severity = self.get_severity_label()

    def compute_percentile(self) -> float:
        """Compute user's percentile rank for this metric.

        Formula: percentile = count(x_i <= score) / N * 100

        Returns:
            float: Percentile rank (0.0 to 100.0).
        """
        count_below = np.sum(self.dataset_values <= self.score)
        total = len(self.dataset_values)
        return round(float(count_below / total * 100), 1)

    def get_severity_label(self) -> str:
        """Return severity label based on score.

        Classification:
            0.0 - 3.0  → 'Low'    (green)
            3.1 - 6.0  → 'Moderate' (amber)
            6.1 - 10.0 → 'High'   (red)

        Returns:
            str: Severity label.
        """
        for threshold, label, _ in self.SEVERITY_THRESHOLDS:
            if self.score <= threshold:
                return label
        return "High"

    def get_severity_color(self) -> str:
        """Return the hex color associated with the current severity.

        Returns:
            str: Hex color code (e.g., '#1DB954').
        """
        for threshold, _, color in self.SEVERITY_THRESHOLDS:
            if self.score <= threshold:
                return color
        return "#E74C3C"
